// Service prices, minimums, maximums, completion times and notes are no longer
// hardcoded here. They come from the backend (/api/services and /api/orders/quote).

const serviceNames = {
  instagram: "Instagram",
  tiktok: "TikTok",
  facebook: "Facebook",
  youtube: "YouTube",
  telegram: "Telegram",
  whatsapp: "WhatsApp",
  twitter: "X (Twitter)"
};

const serviceSubtitles = {
  instagram: "Instagram growth service.",
  tiktok: "TikTok growth service.",
  facebook: "Facebook growth service.",
  youtube: "YouTube growth service.",
  telegram: "Telegram growth service.",
  whatsapp: "WhatsApp growth service.",
  twitter: "X (Twitter) growth service."
};

const menuToggle = document.querySelector("#menu-toggle");
const menuClose = document.querySelector("#menu-close");
const menuPanel = document.querySelector("#menu-panel");
const menuBackdrop = document.querySelector("#menu-backdrop");
const menuItems = document.querySelectorAll("[data-menu-item]");

const moreButton = document.querySelector("#more-button");
const quickOrder = document.querySelector("#quick-order");
const homeMessage = document.querySelector("#home-message");

const welcomeTitle = document.querySelector("#welcome-title");
const walletBalance = document.querySelector(".wallet-summary strong");

const serviceCards = document.querySelectorAll("[data-service]");
const moreServiceOption = document.querySelector("#x-service-option");

const moreSheetLayer = document.querySelector("#more-sheet-layer");
const moreSheetBackdrop = document.querySelector("#more-sheet-backdrop");
const moreSheetClose = document.querySelector("#more-sheet-close");

const serviceSheetLayer = document.querySelector("#service-sheet-layer");
const serviceSheetBackdrop = document.querySelector(
  "#service-sheet-backdrop"
);
const serviceSheetClose = document.querySelector("#service-sheet-close");

const serviceSheetTitle = document.querySelector("#service-sheet-title");
const serviceSheetSubtitle = document.querySelector(
  "#service-sheet-subtitle"
);

const serviceForm = document.querySelector("#service-form");
const serviceTypeSelect = document.querySelector("#service-type");
const accountLink = document.querySelector("#account-link");
const quantity = document.querySelector("#quantity");
const quantityHint = document.querySelector("#quantity-hint");
const priceOutput = document.querySelector("#price-output");
const completionTime = document.querySelector("#completion-time");
const notesList = document.querySelector("#service-notes");
const serviceMessage = document.querySelector("#service-message");

let activeService = "instagram";
let activeServiceItem = null;
let servicesByPlatform = {};
let servicesLoadFailed = false;
let quoteRequestId = 0;
let quoteTimer = null;
let isSubmitting = false;

// ---------- backend helpers ----------

async function api(path, options = {}) {
  const response = await fetch(path, {
    credentials: "same-origin",
    ...options,
    headers: {
      ...(options.body ? { "Content-Type": "application/json" } : {}),
      ...options.headers
    }
  });
  const data = await response.json().catch(() => ({}));

  return { ok: response.ok, status: response.status, data };
}

function redirectToLogin() {
  window.location.href = "./login.html";
}

function formatPrice(amount) {
  return `₦${amount.toLocaleString("en-NG", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })}`;
}

// The backend works in kobo (1 naira = 100 kobo).
function formatKobo(kobo) {
  return formatPrice(kobo / 100);
}

function setWallet(balanceKobo) {
  walletBalance.textContent = formatKobo(balanceKobo);
}

async function loadUser() {
  const { ok, status, data } = await api("/api/me");

  if (status === 401) {
    redirectToLogin();
    return false;
  }

  if (!ok) {
    throw new Error("Could not load account.");
  }

  welcomeTitle.textContent = data.user.fullName;
  setWallet(data.wallet.balanceKobo);

  return true;
}

async function loadServices() {
  const { ok, data } = await api("/api/services");

  if (!ok) {
    throw new Error("Could not load services.");
  }

  servicesByPlatform = {};

  data.services.forEach((service) => {
    if (!servicesByPlatform[service.platform]) {
      servicesByPlatform[service.platform] = [];
    }

    servicesByPlatform[service.platform].push(service);
  });
}

// Resolves to true when the user is signed in and the page is ready to use.
const appReady = (async () => {
  welcomeTitle.textContent = "…";
  walletBalance.textContent = "₦…";

  try {
    if (!(await loadUser())) {
      return false;
    }
  } catch {
    homeMessage.textContent = "Could not load your account. Please refresh.";
    return false;
  }

  try {
    await loadServices();
  } catch {
    servicesLoadFailed = true;
    homeMessage.textContent = "Services could not be loaded. Please refresh.";
  }

  return true;
})();

// ---------- menu and sheets ----------

function setMenuOpen(isOpen) {
  menuPanel.classList.toggle("is-open", isOpen);
  menuBackdrop.classList.toggle("is-visible", isOpen);

  menuPanel.setAttribute("aria-hidden", String(!isOpen));
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute(
    "aria-label",
    isOpen ? "Close menu" : "Open menu"
  );
}

function setSheetOpen(layer, isOpen) {
  layer.classList.toggle("is-open", isOpen);
  layer.setAttribute("aria-hidden", String(!isOpen));

  document.body.classList.toggle(
    "is-locked",
    moreSheetLayer.classList.contains("is-open") ||
      serviceSheetLayer.classList.contains("is-open")
  );
}

function closeSheets() {
  setSheetOpen(moreSheetLayer, false);
  setSheetOpen(serviceSheetLayer, false);
}

function clearErrors() {
  document.querySelectorAll(".sheet-error").forEach((error) => {
    error.textContent = "";
  });

  accountLink.classList.remove("is-invalid");
  quantity.classList.remove("is-invalid");
}

function setServiceMessage(text, isError = false) {
  serviceMessage.textContent = text;
  serviceMessage.style.color = isError ? "var(--error)" : "";
}

function showFieldError(input, errorKey, text) {
  input.classList.add("is-invalid");

  document.querySelector(
    `[data-error-for="${errorKey}"]`
  ).textContent = text;
}

function quantityRangeText(service) {
  return `Use a quantity between ${service.minQuantity.toLocaleString(
    "en-US"
  )} and ${service.maxQuantity.toLocaleString("en-US")}.`;
}

function isValidQuantity(service, amount) {
  return (
    Boolean(service) &&
    Number.isInteger(amount) &&
    amount >= service.minQuantity &&
    amount <= service.maxQuantity
  );
}

// ---------- price (always calculated by the backend) ----------

function showPrice(text, hasValue = false) {
  priceOutput.textContent = text;
  priceOutput.classList.toggle("has-value", hasValue);
}

async function fetchQuote(serviceId, amount, requestId) {
  try {
    const { ok, status, data } = await api("/api/orders/quote", {
      method: "POST",
      body: JSON.stringify({ serviceId, quantity: amount })
    });

    if (requestId !== quoteRequestId) {
      return;
    }

    if (status === 401) {
      redirectToLogin();
      return;
    }

    if (!ok) {
      showPrice("Price unavailable");
      return;
    }

    showPrice(formatKobo(data.quote.chargeKobo), true);
  } catch {
    if (requestId === quoteRequestId) {
      showPrice("Price unavailable");
    }
  }
}

function updatePrice() {
  clearTimeout(quoteTimer);
  quoteRequestId += 1;

  const rawQuantity = quantity.value.trim();
  const amount = Number(rawQuantity);

  if (!rawQuantity || !isValidQuantity(activeServiceItem, amount)) {
    showPrice("Enter quantity");
    return;
  }

  const requestId = quoteRequestId;
  const serviceId = activeServiceItem.id;

  showPrice("Calculating…");
  quoteTimer = setTimeout(() => fetchQuote(serviceId, amount, requestId), 250);
}

// ---------- service sheet ----------

function applySelectedService() {
  const selectedId = Number(serviceTypeSelect.value);
  const services = servicesByPlatform[activeService] || [];

  activeServiceItem =
    services.find((service) => service.id === selectedId) || null;

  const service = activeServiceItem;

  completionTime.textContent =
    (service && service.averageCompletionTime) || "—";

  quantityHint.textContent = service
    ? `Minimum ${service.minQuantity.toLocaleString(
        "en-US"
      )} · Maximum ${service.maxQuantity.toLocaleString("en-US")}`
    : "";

  notesList.replaceChildren(
    ...((service && service.notes) || []).map((note) => {
      const item = document.createElement("li");
      item.textContent = note;
      return item;
    })
  );

  updatePrice();
}

function populateService(serviceKey) {
  activeService = serviceKey;

  serviceSheetTitle.textContent = serviceNames[serviceKey];
  serviceSheetSubtitle.textContent = serviceSubtitles[serviceKey];

  serviceTypeSelect.replaceChildren(
    ...(servicesByPlatform[serviceKey] || []).map((service) => {
      const option = document.createElement("option");
      option.value = String(service.id);
      option.textContent = service.name;
      return option;
    })
  );

  accountLink.value = "";
  quantity.value = "";
  setServiceMessage("");

  clearErrors();
  applySelectedService();
}

function openMoreSheet() {
  setSheetOpen(moreSheetLayer, true);
}

async function openServiceSheet(serviceKey) {
  if (!(await appReady)) {
    return;
  }

  if (!(servicesByPlatform[serviceKey] || []).length) {
    setSheetOpen(moreSheetLayer, false);

    homeMessage.textContent = servicesLoadFailed
      ? "Services could not be loaded. Please refresh."
      : `${serviceNames[serviceKey]} services are not available right now.`;

    return;
  }

  homeMessage.textContent = "";
  populateService(serviceKey);

  setSheetOpen(moreSheetLayer, false);
  setSheetOpen(serviceSheetLayer, true);
}

async function logout() {
  try {
    const { ok } = await api("/api/logout", { method: "POST" });

    if (ok) {
      redirectToLogin();
      return;
    }
  } catch {
    // handled below
  }

  homeMessage.textContent = "Could not log out. Please try again.";
}

menuToggle.addEventListener("click", () => {
  setMenuOpen(!menuPanel.classList.contains("is-open"));
});

menuClose.addEventListener("click", () => {
  setMenuOpen(false);
});

menuBackdrop.addEventListener("click", () => {
  setMenuOpen(false);
});

menuItems.forEach((item) => {
  item.addEventListener("click", () => {
    const selectedItem = item.dataset.menuItem;

    menuItems.forEach((menuItem) => {
      menuItem.classList.toggle("is-active", menuItem === item);
    });

    setMenuOpen(false);

    if (selectedItem === "Logout") {
      logout();
      return;
    }

    const menuPages = {
      Orders: "./orders.html",
      Wallet: "./wallet.html",
      Account: "./account.html",
      Support: "./support.html",
      Terms: "./terms.html"
    };

    if (selectedItem in menuPages) {
      window.location.href = menuPages[selectedItem];
      return;
    }
  });
});

serviceCards.forEach((card) => {
  card.addEventListener("click", () => {
    openServiceSheet(card.dataset.service);
  });
});

moreButton.addEventListener("click", openMoreSheet);

moreSheetBackdrop.addEventListener("click", closeSheets);
moreSheetClose.addEventListener("click", closeSheets);
serviceSheetBackdrop.addEventListener("click", closeSheets);
serviceSheetClose.addEventListener("click", closeSheets);

moreServiceOption.addEventListener("click", () => {
  openServiceSheet("twitter");
});

quickOrder.addEventListener("click", () => {
  openServiceSheet("instagram");
});

serviceTypeSelect.addEventListener("change", applySelectedService);

quantity.addEventListener("input", updatePrice);

accountLink.addEventListener("input", () => {
  accountLink.classList.remove("is-invalid");

  document.querySelector(
    '[data-error-for="account-link"]'
  ).textContent = "";
});

serviceForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  if (isSubmitting) {
    return;
  }

  clearErrors();
  setServiceMessage("");

  const service = activeServiceItem;
  const rawQuantity = quantity.value.trim();
  const amount = Number(rawQuantity);
  let isValid = true;

  if (!accountLink.value.trim()) {
    showFieldError(
      accountLink,
      "account-link",
      "Enter an account link or username."
    );

    isValid = false;
  }

  if (!rawQuantity || !isValidQuantity(service, amount)) {
    showFieldError(
      quantity,
      "quantity",
      service ? quantityRangeText(service) : "Choose a service type."
    );

    isValid = false;
  }

  if (!isValid) {
    return;
  }

  isSubmitting = true;

  try {
    const { ok, status, data } = await api("/api/orders", {
      method: "POST",
      body: JSON.stringify({
        serviceId: service.id,
        quantity: amount,
        link: accountLink.value.trim()
      })
    });

    if (status === 401) {
      redirectToLogin();
      return;
    }

    if (ok) {
      setWallet(data.wallet.balanceKobo);
      setServiceMessage(`Order #${data.order.id} placed successfully.`);

      accountLink.value = "";
      quantity.value = "";
      updatePrice();
    } else if (data.field === "link") {
      showFieldError(accountLink, "account-link", data.error);
    } else if (data.field === "quantity") {
      showFieldError(quantity, "quantity", data.error);
    } else {
      setServiceMessage(data.error || "Could not place your order.", true);
    }
  } catch {
    setServiceMessage("Network error. Please try again.", true);
  } finally {
    isSubmitting = false;
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    closeSheets();
    setMenuOpen(false);
  }
});
