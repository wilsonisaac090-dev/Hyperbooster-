/* HYPERBOOSTER customer support links.
 *
 * The admin saves the official support WhatsApp number (and, optionally, an email) in
 * Admin Panel > Settings > Support Settings. The server shares ONLY those two values at /api/support.
 * This file turns them into "Report a problem" / "Contact support" links.
 *
 *  - WhatsApp links open https://wa.me/<number>?text=<message>. The message is typed into the chat for the
 *    customer, who reads it and presses send themselves. Nothing is ever sent automatically.
 *  - The number must be digits only, with a country code (the server checks it when the admin saves it, and it is
 *    checked again here, so a damaged value can never produce a strange link).
 *  - The message is plain text built from the customer's own order, then encoded with encodeURIComponent, so no
 *    character in it can change the link. Links are built with DOM nodes, never HTML strings.
 */
(function (root) {
  "use strict";

  var WHATSAPP_NUMBER = /^[1-9][0-9]{7,14}$/;
  var EMAIL = /^[a-z0-9._%+-]{1,64}@[a-z0-9-]+(?:\.[a-z0-9-]+)*\.[a-z]{2,}$/i;
  // control characters, zero-width and direction-changing characters
  var UNSAFE = /[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u2064\ufeff]/g;
  var MAX_MESSAGE = 900;

  function clean(value, max) {
    return String(value === null || value === undefined ? "" : value)
      .replace(UNSAFE, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, max);
  }

  function isValidWhatsAppNumber(value) {
    return typeof value === "string" && WHATSAPP_NUMBER.test(value);
  }

  function isValidEmail(value) {
    return typeof value === "string" && value.length <= 254 && EMAIL.test(value);
  }

  function isValidOrder(order) {
    return Boolean(order) && Number.isSafeInteger(order.id) && order.id > 0;
  }

  var INTRO = {
    problem: "I want to report a problem with my order.",
    contact: "I have a question about my order.",
    help: "I need help with my order."
  };

  var PROMPT = {
    problem: "What went wrong: (please describe the problem here)",
    contact: "My question: (please type it here)",
    help: "How can you help: (please describe it here)"
  };

  // The message the customer will see in WhatsApp (or their email app) before sending.
  function orderMessage(order, kind) {
    if (!isValidOrder(order) || !INTRO[kind]) {
      return null;
    }

    var lines = ["Hello HYPERBOOSTER Support,", INTRO[kind], "", "Order reference: #" + order.id];
    var service = clean(order.serviceName, 80);
    if (service) {
      lines.push("Service: " + service);
    }
    if (Number.isSafeInteger(order.quantity) && order.quantity > 0) {
      lines.push("Quantity: " + order.quantity.toLocaleString("en-US"));
    }
    var status = clean(String(order.status || "").replace(/_/g, " "), 30);
    if (status) {
      lines.push("Status: " + status);
    }
    lines.push("", PROMPT[kind]);
    return lines.join("\n").slice(0, MAX_MESSAGE);
  }

  function generalMessage() {
    return ["Hello HYPERBOOSTER Support,", "I need help with:", "", "(please describe what you need)"].join("\n");
  }

  function whatsappUrl(number, message) {
    if (!isValidWhatsAppNumber(number) || typeof message !== "string" || !message) {
      return null;
    }
    return "https://wa.me/" + number + "?text=" + encodeURIComponent(message.slice(0, MAX_MESSAGE));
  }

  function mailtoUrl(email, subject, body) {
    if (!isValidEmail(email)) {
      return null;
    }
    return (
      "mailto:" + email +
      "?subject=" + encodeURIComponent(clean(subject, 120)) +
      "&body=" + encodeURIComponent(String(body || "").slice(0, MAX_MESSAGE).replace(/\n/g, "\r\n"))
    );
  }

  function emptySupport() {
    return { whatsapp: null, email: null };
  }

  // Reads the public support details. Any problem (offline, server error, odd values) means "not set up":
  // the buttons are simply hidden, and the rest of the page keeps working.
  function loadSupport() {
    return fetch("/api/support", { credentials: "same-origin" })
      .then(function (response) {
        return response.ok ? response.json() : emptySupport();
      })
      .then(function (data) {
        return {
          whatsapp: data && isValidWhatsAppNumber(data.whatsapp) ? data.whatsapp : null,
          email: data && isValidEmail(data.email) ? data.email : null
        };
      })
      .catch(emptySupport);
  }

  function makeLink(doc, className, text, href, label) {
    var anchor = doc.createElement("a");
    anchor.className = className;
    anchor.textContent = text;
    anchor.href = href;
    anchor.target = "_blank";
    anchor.rel = "noopener noreferrer";
    if (label) {
      anchor.setAttribute("aria-label", label);
    }
    return anchor;
  }

  // Buttons for one order: "Report a problem" and "Contact support". WhatsApp when the admin set a number;
  // email only as the alternative (or as the main route when no WhatsApp number is set). null = nothing to show.
  function buildOrderActions(order, support, doc) {
    doc = doc || root.document;
    if (!isValidOrder(order) || !support || (!isValidWhatsAppNumber(support.whatsapp) && !isValidEmail(support.email))) {
      return null;
    }

    var box = doc.createElement("div");
    box.className = "support-actions";
    var ref = "order " + order.id;
    var useWhatsApp = isValidWhatsAppNumber(support.whatsapp);

    [["problem", "Report a problem", "support-btn support-btn-problem"], ["contact", "Contact support", "support-btn support-btn-contact"]].forEach(function (b) {
      var message = orderMessage(order, b[0]);
      var href = useWhatsApp
        ? whatsappUrl(support.whatsapp, message)
        : mailtoUrl(support.email, "Order #" + order.id + (b[0] === "problem" ? ": problem report" : ": question"), message);
      box.append(makeLink(doc, b[2], b[1], href, b[1] + " for " + ref + (useWhatsApp ? " on WhatsApp" : " by email")));
    });

    if (useWhatsApp && isValidEmail(support.email)) {
      box.append(
        makeLink(doc, "support-alt", "Email instead", mailtoUrl(support.email, "Order #" + order.id + ": support request", orderMessage(order, "help")), "Email support about " + ref + " instead")
      );
    }

    return box;
  }

  // For the Support page: no order, just a general message.
  function buildGeneralActions(support, doc) {
    doc = doc || root.document;
    if (!support || (!isValidWhatsAppNumber(support.whatsapp) && !isValidEmail(support.email))) {
      return null;
    }

    var box = doc.createElement("div");
    box.className = "support-actions";
    if (isValidWhatsAppNumber(support.whatsapp)) {
      box.append(makeLink(doc, "support-btn support-btn-problem", "Chat with us on WhatsApp", whatsappUrl(support.whatsapp, generalMessage()), "Chat with support on WhatsApp"));
    }
    if (isValidEmail(support.email)) {
      var main = !isValidWhatsAppNumber(support.whatsapp);
      box.append(makeLink(doc, main ? "support-btn support-btn-problem" : "support-alt", main ? "Email us" : "Email instead", mailtoUrl(support.email, "Support request", generalMessage()), "Email support"));
    }
    return box;
  }

  var api = {
    isValidWhatsAppNumber: isValidWhatsAppNumber,
    isValidEmail: isValidEmail,
    orderMessage: orderMessage,
    generalMessage: generalMessage,
    whatsappUrl: whatsappUrl,
    mailtoUrl: mailtoUrl,
    loadSupport: loadSupport,
    buildOrderActions: buildOrderActions,
    buildGeneralActions: buildGeneralActions
  };

  root.HBSupport = api;
  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
})(typeof window !== "undefined" ? window : globalThis);
