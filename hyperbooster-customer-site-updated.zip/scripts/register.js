const form = document.querySelector("#register-form");
const message = document.querySelector("#form-message");

// Maps field names returned by the server to the input ids on this page.
const serverFieldToInputId = {
  fullName: "full-name",
  email: "email",
  password: "password"
};

function setError(id, text) {
  const input = document.querySelector(`#${id}`);
  const error = document.querySelector(`[data-error-for="${id}"]`);

  input.classList.toggle("is-invalid", Boolean(text));
  input.setAttribute("aria-invalid", text ? "true" : "false");
  error.textContent = text;
}

let submitting = false;

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (submitting) return;
  message.textContent = "";

  const fullName = document.querySelector("#full-name");
  const email = document.querySelector("#email");
  const password = document.querySelector("#password");
  const confirmPassword = document.querySelector("#confirm-password");

  let valid = true;

  setError("full-name", "");
  setError("email", "");
  setError("password", "");
  setError("confirm-password", "");

  if (!fullName.value.trim()) {
    setError("full-name", "Please enter your full name.");
    valid = false;
  }

  if (!email.validity.valid) {
    setError("email", "Please enter a valid email address.");
    valid = false;
  }

  if (password.value.length < 8) {
    setError("password", "Use at least 8 characters.");
    valid = false;
  }

  if (confirmPassword.value !== password.value) {
    setError("confirm-password", "Passwords do not match.");
    valid = false;
  }

  if (valid) {
    submitting = true;

    try {
      const response = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({
          fullName: fullName.value.trim(),
          email: email.value.trim(),
          password: password.value
        })
      });
      const data = await response.json().catch(() => ({}));

      if (response.ok) {
        window.location.href = "/";
        return;
      }

      const inputId = serverFieldToInputId[data.field];
      if (inputId) {
        setError(inputId, data.error);
      } else {
        message.textContent = data.error || "Could not create your account. Please try again.";
      }
    } catch {
      message.textContent = "Network error. Please try again.";
    }

    submitting = false;
  }
});
