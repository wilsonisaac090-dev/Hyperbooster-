const form = document.querySelector("#deposit-form");
const amountInput = document.querySelector("#amount");
const continueButton = document.querySelector("#continue-button");
const message = document.querySelector("#form-message");
const balanceFigure = document.querySelector("#balance-figure");
const minDepositHint = document.querySelector("#min-deposit-hint");

const statusPanel = document.querySelector("#status-panel");
const statusTitle = document.querySelector("#status-title");
const statusDetail = document.querySelector("#status-detail");

let submitting = false;

function formatNaira(kobo) {
  return `₦${(kobo / 100).toLocaleString("en-NG", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })}`;
}

// "5,000" / "5000.50" -> whole kobo, using only integer/string arithmetic (never a float multiply),
// the same rule the rest of HYPERBOOSTER's money handling follows.
function parseNairaToKobo(text) {
  const cleaned = String(text || "").trim().replace(/,/g, "");
  if (!/^\d+(\.\d{1,2})?$/.test(cleaned)) return null;
  const [whole, frac = ""] = cleaned.split(".");
  return Number(whole) * 100 + Number(frac.padEnd(2, "0"));
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    credentials: "same-origin",
    ...options,
    headers: {
      ...(options.body ? { "Content-Type": "application/json" } : {}),
      ...options.headers
    }
  });
  const data = await response.json().catch(() => ({}));
  return { ok: response.ok, status: response.status, data };
}

function redirectToLogin() {
  window.location.href = "./login.html";
}

function setError(text) {
  document.querySelector('[data-error-for="amount"]').textContent = text || "";
  amountInput.classList.toggle("is-invalid", Boolean(text));
}

function showStatus(kind, title, detail) {
  statusPanel.className = `status-panel is-visible is-${kind}`;
  statusTitle.textContent = title;
  statusDetail.textContent = detail || "";
}

async function loadWallet() {
  const { ok, status, data } = await api("/api/wallet");
  if (status === 401) {
    redirectToLogin();
    return null;
  }
  if (!ok) {
    balanceFigure.textContent = "₦—";
    return null;
  }
  balanceFigure.textContent = formatNaira(data.balanceKobo);
  return data;
}

// If we're back from Kora, the URL carries ?reference=... — check its status and show the result.
async function checkReturnFromKora() {
  const params = new URLSearchParams(window.location.search);
  const reference = params.get("reference");
  if (!reference) return;

  form.hidden = true;
  showStatus("pending", "Checking your payment…", "");

  const { status, data } = await api(`/api/deposits/${encodeURIComponent(reference)}`);

  if (status === 401) {
    redirectToLogin();
    return;
  }
  if (status === 404) {
    showStatus("failed", "We couldn't find that payment.", "If money left your account, contact support with this reference: " + reference);
    return;
  }
  if (status !== 200) {
    showStatus("pending", "Still checking…", "Please refresh this page in a moment.");
    return;
  }

  balanceFigure.textContent = formatNaira(data.wallet.balanceKobo);
  const amount = formatNaira(data.deposit.verifiedAmountKobo ?? data.deposit.amountKobo);

  if (data.deposit.status === "successful") {
    showStatus("success", "Payment successful", `${amount} was added to your wallet.`);
  } else if (data.deposit.status === "pending" || data.deposit.status === "processing") {
    showStatus("pending", "Payment still processing", "This can take a minute. Refresh this page to check again.");
  } else {
    showStatus("failed", "Payment not completed", "Your wallet was not charged. You can try again below.");
    form.hidden = false;
  }
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (submitting) return;

  message.textContent = "";
  setError("");

  const kobo = parseNairaToKobo(amountInput.value);
  if (kobo === null || kobo <= 0) {
    setError("Enter a valid amount, e.g. 5000 or 5000.50.");
    return;
  }

  submitting = true;
  continueButton.disabled = true;
  message.textContent = "Starting payment…";

  try {
    const { ok, status, data } = await api("/api/deposits", {
      method: "POST",
      body: JSON.stringify({ amountKobo: kobo })
    });

    if (status === 401) {
      redirectToLogin();
      return;
    }

    if (ok) {
      window.location.href = data.checkoutUrl;
      return;
    }

    if (data.field === "amountKobo") {
      setError(data.error);
    } else {
      message.textContent = data.error || "Could not start the payment. Please try again.";
    }
  } catch {
    message.textContent = "Network error. Please try again.";
  }

  submitting = false;
  continueButton.disabled = false;
});

(async () => {
  const wallet = await loadWallet();
  if (!wallet) return;

  try {
    const { ok, data } = await api("/api/settings");
    if (ok) {
      minDepositHint.textContent = `Minimum deposit: ${formatNaira(data.minDepositKobo)}.`;
    }
  } catch {
    // hint is optional; the server still enforces and explains the real minimum on submit
  }

  await checkReturnFromKora();
})();
