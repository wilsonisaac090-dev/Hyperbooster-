async function api(path) {
  const response = await fetch(path, { credentials: "same-origin" });
  return { ok: response.ok, status: response.status };
}

function redirectToLogin() {
  window.location.href = "./login.html";
}

(async () => {
  const me = await api("/api/me");
  if (me.status === 401) {
    redirectToLogin();
    return;
  }

  const body = document.querySelector("#terms-body");
  body.innerHTML = "";

  const copy = document.createElement("div");
  copy.className = "static-copy";
  copy.innerHTML = `
    <h2>Using HYPERBOOSTER</h2>
    <p>By placing an order you agree to provide accurate account details and to use our services for accounts you own or are authorized to manage.</p>
    <h2>Wallet and payments</h2>
    <p>Wallet funds are added only after a payment is verified. Orders are charged from your wallet balance at the time of purchase.</p>
    <h2>Orders</h2>
    <p>Delivery times shown for each service are estimates. Refunds, where applicable, are credited back to your wallet.</p>
    <h2>Changes</h2>
    <p>These terms may be updated from time to time. Continued use of HYPERBOOSTER after a change means you accept the update.</p>
  `;
  body.append(copy);
})();
