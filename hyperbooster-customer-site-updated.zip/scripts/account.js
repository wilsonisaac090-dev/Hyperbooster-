async function api(path) {
  const response = await fetch(path, { credentials: "same-origin" });
  const data = await response.json().catch(() => ({}));
  return { ok: response.ok, status: response.status, data };
}

function redirectToLogin() {
  window.location.href = "./login.html";
}

function formatNaira(kobo) {
  return `₦${(kobo / 100).toLocaleString("en-NG", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })}`;
}

function row(label, value) {
  const wrap = document.createElement("div");
  wrap.className = "info-row";
  const left = document.createElement("span");
  left.textContent = label;
  const right = document.createElement("span");
  right.textContent = value;
  wrap.append(left, right);
  return wrap;
}

(async () => {
  const me = await api("/api/me");
  if (me.status === 401) {
    redirectToLogin();
    return;
  }

  const body = document.querySelector("#account-body");

  if (!me.ok) {
    body.replaceChildren();
    const error = document.createElement("p");
    error.className = "empty-state";
    error.textContent = "Could not load your account. Please refresh.";
    body.append(error);
    return;
  }

  const { user, wallet } = me.data;

  body.replaceChildren();
  body.append(
    row("Full name", user.fullName),
    row("Email", user.email),
    row("Wallet balance", formatNaira(wallet.balanceKobo)),
    row("Account type", user.role === "admin" ? "Administrator" : "Customer")
  );
})();
