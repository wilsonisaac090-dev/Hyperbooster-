const form = document.querySelector("#login-form");
const message = document.querySelector("#form-message");

function setError(id, text) {
  const input = document.querySelector(`#${id}`);
  const error = document.querySelector(`[data-error-for="${id}"]`);

  input.classList.toggle("is-invalid", Boolean(text));
  input.setAttribute("aria-invalid", text ? "true" : "false");
  error.textContent = text;
}

let submitting = false;

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (submitting) return;
  message.textContent = "";

  const email = document.querySelector("#email");
  const password = document.querySelector("#password");

  let valid = true;

  setError("email", "");
  setError("password", "");

  if (!email.validity.valid) {
    setError("email", "Please enter a valid email address.");
    valid = false;
  }

  if (!password.value.trim()) {
    setError("password", "Please enter your password.");
    valid = false;
  }

  if (valid) {
    submitting = true;

    try {
      const response = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({
          email: email.value.trim(),
          password: password.value
        })
      });
      const data = await response.json().catch(() => ({}));

      if (response.ok) {
        window.location.href = "/";
        return;
      }

      message.textContent = data.error || "Sign-in failed. Please try again.";
    } catch {
      message.textContent = "Network error. Please try again.";
    }

    submitting = false;
  }
});
