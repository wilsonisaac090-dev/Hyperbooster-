async function api(path) {
  const response = await fetch(path, { credentials: "same-origin" });
  const data = await response.json().catch(() => ({}));
  return { ok: response.ok, status: response.status, data };
}

function redirectToLogin() {
  window.location.href = "./login.html";
}

function formatNaira(kobo) {
  return `₦${(kobo / 100).toLocaleString("en-NG", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })}`;
}

function formatDate(iso) {
  const date = new Date(iso);
  return Number.isNaN(date.getTime())
    ? ""
    : date.toLocaleDateString("en-NG", { day: "numeric", month: "short", year: "numeric" });
}

function renderOrders(orders, support) {
  const body = document.querySelector("#orders-body");

  if (!orders.length) {
    body.replaceChildren();
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = "You haven't placed any orders yet.";
    body.append(empty);
    return;
  }

  body.replaceChildren();
  orders.forEach((order) => {
    const item = document.createElement("article");
    item.className = "order-item";

    const top = document.createElement("div");
    top.className = "order-top";

    const left = document.createElement("div");
    const name = document.createElement("p");
    name.className = "order-name";
    name.textContent = order.serviceName;
    const sub = document.createElement("p");
    sub.className = "order-sub";
    sub.textContent = `${order.quantity.toLocaleString("en-US")} · ${order.link}`;
    left.append(name, sub);

    const amount = document.createElement("p");
    amount.className = "order-amount";
    amount.textContent = formatNaira(order.chargeKobo);

    top.append(left, amount);

    const status = document.createElement("span");
    status.className = `order-status st-${order.status}`;
    status.textContent = order.status.replace("_", " ");

    const date = document.createElement("p");
    date.className = "order-sub";
    date.style.marginTop = "8px";
    date.textContent = formatDate(order.createdAt);

    item.append(top, status, date);

    // "Report a problem" / "Contact support" for this order (hidden when the admin has not set up support yet)
    const actions = window.HBSupport ? window.HBSupport.buildOrderActions(order, support) : null;
    if (actions) {
      item.append(actions);
    }

    body.append(item);
  });
}

(async () => {
  const me = await api("/api/me");
  if (me.status === 401) {
    redirectToLogin();
    return;
  }

  const orders = await api("/api/orders?limit=50");
  if (orders.status === 401) {
    redirectToLogin();
    return;
  }

  if (!orders.ok) {
    const body = document.querySelector("#orders-body");
    body.replaceChildren();
    const error = document.createElement("p");
    error.className = "empty-state";
    error.textContent = "Could not load your orders. Please refresh.";
    body.append(error);
    return;
  }

  const support = window.HBSupport ? await window.HBSupport.loadSupport() : null;
  renderOrders(orders.data.orders, support);
})();
