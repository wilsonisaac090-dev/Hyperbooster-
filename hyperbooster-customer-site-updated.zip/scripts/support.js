async function api(path) {
  const response = await fetch(path, { credentials: "same-origin" });
  return { ok: response.ok, status: response.status };
}

function redirectToLogin() {
  window.location.href = "./login.html";
}

(async () => {
  const me = await api("/api/me");
  if (me.status === 401) {
    redirectToLogin();
    return;
  }

  const body = document.querySelector("#support-body");
  body.replaceChildren();

  // The support details are saved by the admin (Admin Panel > Settings > Support Settings), never hard-coded here.
  const support = window.HBSupport ? await window.HBSupport.loadSupport() : null;
  const actions = window.HBSupport ? window.HBSupport.buildGeneralActions(support) : null;

  const copy = document.createElement("div");
  copy.className = "static-copy";

  const add = (tag, text) => {
    const el = document.createElement(tag);
    el.textContent = text;
    copy.append(el);
    return el;
  };

  add("h2", "Need help with an order?");
  add("p", "Check the Orders page first \u2014 most questions about status or timing are answered there. To report a problem with a specific order, use the Report a problem button on that order.");

  add("h2", "Contact us");
  if (actions) {
    add("p", "Tap below to message us. Your message is already typed for you: read it, add your details, and press send yourself. Please include your order number if you have one.");
    copy.append(actions);
  } else {
    add("p", "Support contact details are not available right now. Please check back soon.");
  }

  add("h2", "Wallet or payment issues");
  add("p", "If a deposit didn't reflect in your wallet, wait a few minutes and check the Wallet page again before contacting support \u2014 most payments confirm automatically.");

  body.append(copy);
})();
