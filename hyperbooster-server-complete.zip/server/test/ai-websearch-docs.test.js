'use strict';
// Pins EL's web search to Groq's official Browser Search documentation:
//   https://console.groq.com/docs/tool-use/built-in-tools/browser-search   (read 2026-10-09)
// The documented facts these tests hold the code to:
//   - POST https://api.groq.com/openai/v1/chat/completions with  tools: [{ "type": "browser_search" }]  and  tool_choice: "required"
//   - supported models: openai/gpt-oss-20b, openai/gpt-oss-120b, openai/gpt-oss-safeguard-20b
//   - "Browser search is not compatible with structured outputs"
//   - reasoning_effort "low" recommended (quality vs tokens/latency)
//   - message.content holds the answer, with inline citation markers such as 【2†L6-L10】
// These tests use a fake Groq: they pin the request we SEND and how we treat the documented response. They do not
// prove that the real Groq service accepts it; that needs the live verification script and a real key.
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { loadConfig } = require('../src/config');
const { createApp } = require('../src/app');
const { hashPassword } = require('../src/security');
const { AI_LIMITS } = require('../src/ai/limits');

const ADMIN_PW = 'a-strong-admin-passphrase';
const KEY = 'gsk_test_key_0000000000';
const BIG = { max: 1e6, windowMs: 6e4 };
const LIMITS = {
  apiPerIp: BIG, loginPerIp: BIG, loginPerAccount: BIG, registerPerIp: BIG, orderPerUser: BIG,
  adminLoginPerIp: BIG, adminLoginPerAccount: BIG, adminOtpPerIp: BIG, adminApiPerIp: BIG,
  adminAiChatPerAdmin: BIG, adminAiChatPerIp: BIG, adminAiSettingsPerIp: BIG,
};
const SIX_READ = { read_dashboard: true, read_orders: true, read_services: true, read_customers: true, read_wallet: true, read_audit: true };
const DOCUMENTED_MODELS = ['openai/gpt-oss-20b', 'openai/gpt-oss-120b', 'openai/gpt-oss-safeguard-20b'];
const STRUCTURED_OUTPUT_KEYS = ['response_format', 'json_schema', 'json_object', 'schema', 'strict'];

// The documented example response: snippets, then the answer with inline citation markers.
const DOC_SHAPED = '...[site snippets]\n\nLast week saw a reshuffling of AI leadership 【2†L6-L10】, while Meta claimed to be self-improving 【2†L17-L23】.';

class Client {
  constructor(base) { this.base = base; this.jar = {}; this.csrf = null; }
  async call(method, url, body) {
    const cookie = Object.entries(this.jar).map(([k, v]) => `${k}=${v}`).join('; ');
    const res = await fetch(this.base + url, {
      method, redirect: 'manual',
      headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(cookie ? { Cookie: cookie } : {}), ...(this.csrf && method !== 'GET' ? { 'X-CSRF-Token': this.csrf } : {}) },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    const text = await res.text(); let json = null; try { json = JSON.parse(text); } catch { /* not json */ }
    for (const c of res.headers.getSetCookie?.() ?? []) { const [pair] = c.split(';'); const i = pair.indexOf('='); const k = pair.slice(0, i); const v = pair.slice(i + 1); if (v === '') delete this.jar[k]; else this.jar[k] = v; }
    return { status: res.status, json, text };
  }
  get(u) { return this.call('GET', u); }
  post(u, b) { return this.call('POST', u, b); }
  patch(u, b) { return this.call('PATCH', u, b); }
}

function makeFake() {
  const f = { script: [], searchReplies: [], mainCalls: [], searchCalls: [], searchMeta: [] };
  f.fetchImpl = async (url, opts) => {
    const body = JSON.parse(opts.body);
    const ok = (message) => ({ ok: true, status: 200, json: async () => ({ choices: [{ message }] }) });
    if ((body.tools || []).some((t) => t.type === 'browser_search')) {
      f.searchCalls.push(body); f.searchMeta.push({ url, method: opts.method, headers: opts.headers });
      return ok({ content: f.searchReplies.shift() ?? 'A normal search answer.' });
    }
    f.mainCalls.push(body);
    return ok(f.script.shift() ?? { content: 'ok' });
  };
  return f;
}

async function withApp(fn) {
  const fake = makeFake();
  const cfg = loadConfig({}, { databasePath: ':memory:', logRequests: false, mailTransport: 'memory', limits: LIMITS, staticDir: '/nonexistent' });
  const app = createApp(cfg, { aiFetch: fake.fetchImpl });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  try {
    app.db.prepare('INSERT INTO admins (email, name, password_hash) VALUES (?,?,?)').run('boss@example.com', 'The Boss', await hashPassword(ADMIN_PW));
    const boss = new Client(base);
    assert.equal((await boss.post('/api/admin/login', { email: 'boss@example.com', password: ADMIN_PW })).status, 200);
    const otp = await boss.post('/api/admin/verify-otp', { code: /code is (\d{6})/.exec(app.mailer.outbox.at(-1).text)[1] });
    boss.csrf = otp.json.csrfToken;
    const save = (patch) => boss.patch('/api/admin/ai/settings', { ...patch, currentPassword: ADMIN_PW });
    assert.equal((await save({ enabled: true, apiKey: KEY, searchProvider: 'groq', toolPermissions: { ...SIX_READ, web_search: true } })).status, 200);
    const ask = async (query) => {
      fake.script.push({ content: '', tool_calls: [{ id: 'c1', function: { name: 'web_search', arguments: JSON.stringify({ query }) } }] }, { content: 'done' });
      const r = await boss.post('/api/admin/ai/chat', { message: 'look this up' });
      assert.equal(r.status, 200, r.text);
      return r.json;
    };
    await fn({ app, fake, boss, save, ask });
  } finally { await app.close(); }
}

const allKeys = (v, out = new Set()) => { if (Array.isArray(v)) v.forEach((x) => allKeys(x, out)); else if (v && typeof v === 'object') for (const [k, x] of Object.entries(v)) { out.add(k); allKeys(x, out); } return out; };

test('1. the search request is exactly the documented shape: endpoint, tools, tool_choice, low reasoning effort, key only in the header', async () => {
  await withApp(async ({ fake, ask }) => {
    const r = await ask('current Node.js LTS version');
    assert.deepEqual(r.toolsUsed, ['web_search']);
    assert.equal(fake.searchCalls.length, 1);
    const body = fake.searchCalls[0]; const meta = fake.searchMeta[0];
    assert.equal(meta.url, 'https://api.groq.com/openai/v1/chat/completions');
    assert.equal(meta.method, 'POST');
    assert.equal(meta.headers.Authorization, `Bearer ${KEY}`);
    assert.deepEqual(body.tools, [{ type: 'browser_search' }]);
    assert.equal(body.tool_choice, 'required');
    assert.equal(body.reasoning_effort, 'low');
    assert.equal(body.model, 'openai/gpt-oss-120b');
    assert.deepEqual(body.messages.map((m) => m.role), ['system', 'user']);
    assert.deepEqual(Object.keys(body).sort(), ['messages', 'model', 'reasoning_effort', 'tool_choice', 'tools'], 'no parameters beyond the documented ones');
    assert.equal(JSON.stringify(body).includes(KEY), false, 'the key is never in the body');
  });
});

test('2. Browser Search is never combined with structured outputs, in the search call or the main call', async () => {
  await withApp(async ({ fake, ask }) => {
    await ask('public topic');
    assert.ok(fake.searchCalls.length >= 1 && fake.mainCalls.length >= 2);
    for (const [label, body] of [['search', fake.searchCalls[0]], ...fake.mainCalls.map((b, i) => [`main ${i + 1}`, b])]) {
      const keys = allKeys(body);
      for (const k of STRUCTURED_OUTPUT_KEYS) assert.equal(keys.has(k), false, `${label} request must not contain "${k}"`);
    }
  });
});

test('3. browser_search lives only in the separate search call; EL tools and chat history never go into it', async () => {
  await withApp(async ({ fake, ask }) => {
    await ask('public topic');
    for (const m of fake.mainCalls) {
      assert.equal(m.tools.some((t) => t.type === 'browser_search'), false, 'the main EL call never carries browser_search');
      assert.equal(m.tools.every((t) => t.type === 'function'), true);
    }
    const s = fake.searchCalls[0];
    assert.equal(s.tools.length, 1, 'the search call carries nothing but browser_search');
    assert.equal(JSON.stringify(s).includes('get_dashboard_stats'), false, 'no EL tool definitions in the search call');
    assert.equal(s.messages.length, 2, 'no conversation history in the search call');
    assert.equal(s.messages[1].content, 'public topic');
  });
});

test('4. the supported-model list is exactly Groq\'s documented list, and each documented model really sends a search', async () => {
  assert.deepEqual([...AI_LIMITS.WEB_SEARCH_SUPPORTED_MODELS].sort(), [...DOCUMENTED_MODELS].sort());
  await withApp(async ({ fake, save, ask }) => {
    for (const model of DOCUMENTED_MODELS) {
      assert.equal((await save({ model })).status, 200);
      const before = fake.searchCalls.length;
      const r = await ask(`public topic for ${model}`);
      assert.deepEqual(r.toolsUsed, ['web_search'], model);
      assert.equal(fake.searchCalls.length, before + 1, model);
      assert.equal(fake.searchCalls.at(-1).model, model);
    }
    assert.equal((await save({ model: 'llama-3.3-70b-versatile' })).status, 200);
    const before = fake.searchCalls.length;
    assert.deepEqual((await ask('public topic')).toolsUsed, [], 'an undocumented model is refused...');
    assert.equal(fake.searchCalls.length, before, '...and nothing is sent to Groq');
  });
});

test('5. a documented-shape response (citation markers inside message.content) is passed on as untrusted data, answer included', async () => {
  await withApp(async ({ fake, ask }) => {
    fake.searchReplies.push(DOC_SHAPED);
    const r = await ask('what happened in AI last week');
    assert.deepEqual(r.toolsUsed, ['web_search']);
    const toolMsg = fake.mainCalls.at(-1).messages.filter((m) => m.role === 'tool').at(-1);
    const tool = JSON.parse(toolMsg.content);
    assert.equal(tool.truncated, false);
    const text = tool.passages.join(' ');
    assert.ok(text.includes('【2†L6-L10】') && text.includes('【2†L17-L23】'), 'inline citation markers survive intact');
    assert.ok(text.includes('reshuffling of AI leadership'), 'the answer at the end of the text is kept');
    assert.match(tool.source, /Unverified/); assert.match(tool.source, /Untrusted/);
    assert.equal(typeof tool._untrusted_data_notice, 'string');
  });
});
