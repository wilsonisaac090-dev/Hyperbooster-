'use strict';
const { test, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { loadConfig } = require('../src/config');
const { createApp } = require('../src/app');
const { transaction } = require('../src/db');
const { applyLedger } = require('../src/wallet');
const { verifyKoraSignature } = require('../src/kora/signature');
const { koboToNairaAmount, nairaAmountToKobo } = require('../src/kora/money');

const SECRET = 'sk_test_fake_secret_for_tests';
const LIMITS = {
  apiPerIp: { max: 1e6, windowMs: 6e4 }, loginPerIp: { max: 1e6, windowMs: 6e4 }, loginPerAccount: { max: 1e6, windowMs: 6e4 },
  registerPerIp: { max: 1e6, windowMs: 6e4 }, orderPerUser: { max: 1e6, windowMs: 6e4 },
  adminLoginPerIp: { max: 1e6, windowMs: 6e4 }, adminLoginPerAccount: { max: 1e6, windowMs: 6e4 }, adminOtpPerIp: { max: 1e6, windowMs: 6e4 }, adminApiPerIp: { max: 1e6, windowMs: 6e4 },
  adminAiChatPerAdmin: { max: 1e6, windowMs: 6e4 }, adminAiChatPerIp: { max: 1e6, windowMs: 6e4 }, adminAiSettingsPerIp: { max: 1e6, windowMs: 6e4 },
  depositCreatePerUser: { max: 1e6, windowMs: 6e4 }, depositCreatePerIp: { max: 1e6, windowMs: 6e4 }, koraWebhookPerIp: { max: 1e6, windowMs: 6e4 },
};

let app, base, cfg, koraCalls;

class Client {
  constructor() { this.jar = {}; }
  async call(method, url, { body, raw, headers = {} } = {}) {
    const has = body !== undefined || raw !== undefined;
    const cookie = Object.entries(this.jar).map(([k, v]) => `${k}=${v}`).join('; ');
    const res = await fetch(base + url, { method, headers: { ...(has ? { 'Content-Type': 'application/json' } : {}), ...(cookie ? { Cookie: cookie } : {}), ...headers }, body: raw ?? (body !== undefined ? JSON.stringify(body) : undefined) });
    const text = await res.text(); let json = null; try { json = JSON.parse(text); } catch { /* not json */ }
    for (const c of res.headers.getSetCookie?.() ?? []) { const [pair] = c.split(';'); const i = pair.indexOf('='); const k = pair.slice(0, i); const v = pair.slice(i + 1); if (v === '') delete this.jar[k]; else this.jar[k] = v; }
    return { status: res.status, json, text };
  }
  get(u, o) { return this.call('GET', u, o); }
  post(u, body, o) { return this.call('POST', u, { body, ...o }); }
}

// A scripted fake Kora server: every test controls exactly what "Kora" returns.
function makeFakeKora() {
  const initReplies = []; const queryReplies = {};
  const fetchImpl = async (url, opts) => {
    koraCalls.push({ url, method: opts.method, body: opts.body ? JSON.parse(opts.body) : null, auth: opts.headers.Authorization });
    if (url.includes('/charges/initialize')) {
      const next = initReplies.shift() || { status: true, message: 'ok', data: { reference: JSON.parse(opts.body).reference, checkout_url: 'https://checkout.korapay.com/pay/fake' } };
      return { ok: next.httpStatus !== 500, status: next.httpStatus || 200, json: async () => next };
    }
    const ref = decodeURIComponent(url.split('/charges/')[1]);
    const q = queryReplies[ref] || { status: true, data: { reference: ref, status: 'pending', amount: '0', amount_paid: null } };
    return { ok: true, status: 200, json: async () => q };
  };
  return { fetchImpl, initReplies, queryReplies };
}

async function newCustomer(email, name = 'Cust') {
  const c = new Client();
  const r = await c.post('/api/register', { fullName: name, email, password: 'a-long-password' });
  assert.equal(r.status, 201, r.text);
  return { client: c, id: r.json.user.id };
}
function signWebhook(dataObject, secret = SECRET) {
  return crypto.createHmac('sha256', secret).update(JSON.stringify(dataObject)).digest('hex');
}
async function sendWebhook(c, eventBody, sigSecret = SECRET) {
  return c.call('POST', '/api/webhooks/kora', { raw: JSON.stringify(eventBody), headers: { 'Content-Type': 'application/json', 'x-korapay-signature': signWebhook(eventBody.data, sigSecret) } });
}

let kora, ada;
before(async () => {
  kora = makeFakeKora(); koraCalls = kora.initReplies && []; koraCalls = [];
  cfg = loadConfig({ KORA_SECRET_KEY: SECRET, KORA_BASE_URL: 'https://api.korapay.com' }, { databasePath: ':memory:', logRequests: false, mailTransport: 'memory', limits: LIMITS, staticDir: '/nonexistent' });
  app = createApp(cfg, { koraFetch: kora.fetchImpl });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  ada = await newCustomer('ada@example.com', 'Ada Lovelace');
});
after(() => app.close());
beforeEach(() => { kora.initReplies.length = 0; for (const k of Object.keys(kora.queryReplies)) delete kora.queryReplies[k]; koraCalls.length = 0; });

// ---------- money conversion ----------
test('naira/kobo conversion is exact and never guesses on malformed input', () => {
  assert.equal(koboToNairaAmount(150050), 1500.5);
  assert.equal(koboToNairaAmount(100000), 1000);
  assert.equal(nairaAmountToKobo('1000'), 100000);
  assert.equal(nairaAmountToKobo(1000), 100000);
  assert.equal(nairaAmountToKobo('1000.5'), 100050);
  assert.equal(nairaAmountToKobo('22000.00'), 2200000);
  assert.equal(nairaAmountToKobo('not-a-number'), null);
  assert.equal(nairaAmountToKobo(''), null);
  assert.equal(nairaAmountToKobo(null), null);
  assert.equal(nairaAmountToKobo('12.999'), null, 'more than 2 decimals is rejected, not rounded blindly');
});

// ---------- webhook signature ----------
test("webhook signature verification matches Kora's documented HMAC-SHA256-of-data-only scheme", () => {
  const data = { reference: 'r1', amount: 1000, status: 'success' };
  const sig = crypto.createHmac('sha256', SECRET).update(JSON.stringify(data)).digest('hex');
  assert.equal(verifyKoraSignature(SECRET, data, sig), true);
  assert.equal(verifyKoraSignature(SECRET, data, 'deadbeef'), false);
  assert.equal(verifyKoraSignature(SECRET, data, ''), false);
  assert.equal(verifyKoraSignature(SECRET, data, undefined), false);
  assert.equal(verifyKoraSignature('wrong-secret', data, sig), false);
  assert.equal(verifyKoraSignature(SECRET, { ...data, amount: 2000 }, sig), false, 'signature is tied to the exact data payload');
});

// ---------- unauthorized access ----------
test('unauthenticated users cannot create a deposit or read any deposit', async () => {
  const anon = new Client();
  assert.equal((await anon.post('/api/deposits', { amountKobo: 500000 })).status, 401);
  assert.equal((await anon.get('/api/deposits/HB-DEP-ANYTHING')).status, 401);
});
test("a customer cannot see another customer's deposit, even with a real reference", async () => {
  kora.initReplies.push({ status: true, message: 'ok', data: { reference: 'x', checkout_url: 'https://pay.korapay.com/x' } });
  const created = await ada.client.post('/api/deposits', { amountKobo: 500000 });
  assert.equal(created.status, 201, created.text);
  const bola = await newCustomer('bola@example.com', 'Bola');
  assert.equal((await bola.client.get(`/api/deposits/${created.json.reference}`)).status, 404);
});
test('an unknown/invalid deposit reference returns 404, not a crash', async () => {
  assert.equal((await ada.client.get('/api/deposits/HB-DEP-DOES-NOT-EXIST')).status, 404);
});

// ---------- deposit creation + minimum validation ----------
test('deposit creation validates the amount and enforces the existing minimum-deposit setting', async () => {
  const bad = async (amountKobo) => (await ada.client.post('/api/deposits', { amountKobo })).status;
  assert.equal(await bad(0), 400);
  assert.equal(await bad(-500), 400);
  assert.equal(await bad(1.5), 400);
  const tooSmall = await ada.client.post('/api/deposits', { amountKobo: 100 }); // NGN 1, below the NGN 1,000 default minimum
  assert.equal(tooSmall.status, 400);
  assert.equal(tooSmall.json.field, 'amountKobo');
  assert.match(tooSmall.json.error, /minimum deposit/i);
  assert.equal(koraCalls.length, 0, 'Kora is never called for an amount that fails validation');
});

test('a valid deposit creates a real pending row, calls Kora Initialize Charge with the secret key server-side, and returns the checkout URL', async () => {
  kora.initReplies.push({ status: true, message: 'ok', data: { reference: 'echoed-back', checkout_url: 'https://checkout.korapay.com/pay/abc123' } });
  const r = await ada.client.post('/api/deposits', { amountKobo: 250000 });
  assert.equal(r.status, 201, r.text);
  assert.ok(r.json.reference.startsWith('HB-DEP-'));
  assert.equal(r.json.checkoutUrl, 'https://checkout.korapay.com/pay/abc123');

  assert.equal(koraCalls.length, 1);
  assert.equal(koraCalls[0].auth, `Bearer ${SECRET}`);
  assert.equal(koraCalls[0].body.amount, 2500, 'kobo 250000 is sent to Kora as naira 2500, not 250000');
  assert.equal(koraCalls[0].body.currency, 'NGN');
  assert.equal(koraCalls[0].body.customer.email, 'ada@example.com');
  assert.ok(koraCalls[0].body.redirect_url && koraCalls[0].body.notification_url);
  assert.equal(r.text.includes(SECRET), false, 'the secret key never appears in any response to the browser');

  const row = app.db.prepare('SELECT * FROM deposits WHERE reference = ?').get(r.json.reference);
  assert.equal(row.status, 'pending');
  assert.equal(row.amount_kobo, 250000);
  assert.equal(row.user_id, ada.id);
});

test("if Kora's Initialize Charge call fails, no phantom pending deposit is left behind and the customer sees a clean error", async () => {
  kora.initReplies.push({ status: false, message: 'bad request', httpStatus: 400 });
  const r = await ada.client.post('/api/deposits', { amountKobo: 300000 });
  assert.equal(r.status, 503);
  const rows = app.db.prepare("SELECT status FROM deposits WHERE user_id = ? AND amount_kobo = 300000").all(ada.id);
  assert.ok(rows.every((row) => row.status === 'failed'), 'never left pending');
});

test('deposit creation is rate limited per user', async () => {
  const tight = loadConfig({ KORA_SECRET_KEY: SECRET }, { databasePath: ':memory:', logRequests: false, mailTransport: 'memory', limits: { ...LIMITS, depositCreatePerUser: { max: 1, windowMs: 60000 } }, staticDir: '/nonexistent' });
  const tightApp = createApp(tight, { koraFetch: async () => ({ ok: true, status: 200, json: async () => ({ status: true, data: { reference: 'x', checkout_url: 'https://x' } }) }) });
  try {
    await new Promise((r) => tightApp.server.listen(0, '127.0.0.1', r));
    const tbase = `http://127.0.0.1:${tightApp.server.address().port}`;
    const c = new Client();
    const reg = await fetch(tbase + '/api/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ fullName: 'T', email: 't@example.com', password: 'a-long-password' }) });
    for (const sc of reg.headers.getSetCookie()) { const [pair] = sc.split(';'); const i = pair.indexOf('='); c.jar[pair.slice(0, i)] = pair.slice(i + 1); }
    const send = () => fetch(tbase + '/api/deposits', { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: Object.entries(c.jar).map(([k, v]) => `${k}=${v}`).join('; ') }, body: JSON.stringify({ amountKobo: 200000 }) });
    assert.equal((await send()).status, 201);
    assert.equal((await send()).status, 429);
  } finally { await tightApp.close(); }
});

// ---------- webhook: successful payment ----------
async function makeDeposit(client, amountKobo, koraCheckoutReply) {
  kora.initReplies.push(koraCheckoutReply || { status: true, message: 'ok', data: { reference: 'x', checkout_url: 'https://pay/x' } });
  const r = await client.post('/api/deposits', { amountKobo });
  assert.equal(r.status, 201, r.text);
  return r.json.reference;
}

test('a verified successful webhook credits the wallet exactly once, using the ledger and correct kobo amount', async () => {
  const reference = await makeDeposit(ada.client, 500000);
  kora.queryReplies[reference] = { status: true, data: { reference, status: 'success', amount: '5000.00', amount_paid: '5000.00', currency: 'NGN' } };
  const before = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;

  const w1 = await sendWebhook(ada.client, { event: 'charge.success', data: { reference, amount: 5000, currency: 'NGN', status: 'success' } });
  assert.equal(w1.status, 200, w1.text);
  const after = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  assert.equal(after, before + 500000);

  const dep = app.db.prepare('SELECT status, verified_amount_kobo FROM deposits WHERE reference = ?').get(reference);
  assert.equal(dep.status, 'successful');
  assert.equal(dep.verified_amount_kobo, 500000);

  const ledgerRows = app.db.prepare("SELECT amount_kobo FROM wallet_ledger WHERE reference_type='deposit' AND reference_id = (SELECT id FROM deposits WHERE reference = ?)").all(reference);
  assert.equal(ledgerRows.length, 1);
  assert.equal(ledgerRows[0].amount_kobo, 500000);
});

test('the SAME webhook delivered twice credits the wallet only once (idempotent)', async () => {
  const reference = await makeDeposit(ada.client, 400000);
  kora.queryReplies[reference] = { status: true, data: { reference, status: 'success', amount: '4000.00', amount_paid: '4000.00' } };
  const before = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  const body = { event: 'charge.success', data: { reference, amount: 4000, status: 'success' } };
  assert.equal((await sendWebhook(ada.client, body)).status, 200);
  assert.equal((await sendWebhook(ada.client, body)).status, 200);
  assert.equal((await sendWebhook(ada.client, body)).status, 200, 'a third delivery is still handled cleanly');
  const after = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  assert.equal(after, before + 400000, 'credited exactly once despite three deliveries');
  const count = app.db.prepare("SELECT COUNT(*) AS n FROM wallet_ledger WHERE description LIKE ?").get(`%${reference}%`).n;
  assert.equal(count, 1);
});

test('the wallet is credited with the amount KORA VERIFIES, never the amount the browser originally requested', async () => {
  const reference = await makeDeposit(ada.client, 200000); // customer asked to deposit NGN 2,000...
  kora.queryReplies[reference] = { status: true, data: { reference, status: 'success', amount: '2000.00', amount_paid: '3500.00' } }; // ...but actually paid NGN 3,500 (e.g. bank transfer overpayment)
  const before = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  await sendWebhook(ada.client, { event: 'charge.success', data: { reference, amount: 2000, status: 'success' } });
  const after = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  assert.equal(after, before + 350000, 'credited what Kora verified as paid (amount_paid), not the originally requested amount');
});

test('a webhook claiming success but with no parseable verified amount does NOT credit the wallet', async () => {
  const reference = await makeDeposit(ada.client, 500000);
  kora.queryReplies[reference] = { status: true, data: { reference, status: 'success', amount: null, amount_paid: null } };
  const before = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  await sendWebhook(ada.client, { event: 'charge.success', data: { reference, status: 'success' } });
  const after = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  assert.equal(after, before, 'no credit without a verifiable amount');
  assert.equal(app.db.prepare('SELECT status FROM deposits WHERE reference = ?').get(reference).status, 'failed');
});

// ---------- failed / cancelled / expired payments ----------
for (const koraStatus of ['failed', 'cancelled', 'expired']) {
  test(`a ${koraStatus} payment never credits the wallet and the deposit is marked accordingly`, async () => {
    const reference = await makeDeposit(ada.client, 300000);
    kora.queryReplies[reference] = { status: true, data: { reference, status: koraStatus } };
    const before = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
    await sendWebhook(ada.client, { event: 'charge.failed', data: { reference, status: koraStatus } });
    const after = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
    assert.equal(after, before);
    const dep = app.db.prepare('SELECT status FROM deposits WHERE reference = ?').get(reference);
    assert.equal(dep.status, koraStatus === 'canceled' ? 'cancelled' : koraStatus);
  });
}

// ---------- invalid / unverified webhook ----------
test('a webhook with an invalid signature is rejected and never touches the wallet', async () => {
  const reference = await makeDeposit(ada.client, 500000);
  kora.queryReplies[reference] = { status: true, data: { reference, status: 'success', amount: '5000.00', amount_paid: '5000.00' } };
  const before = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  const r = await ada.client.call('POST', '/api/webhooks/kora', { raw: JSON.stringify({ event: 'charge.success', data: { reference, amount: 5000, status: 'success' } }), headers: { 'Content-Type': 'application/json', 'x-korapay-signature': 'not-a-real-signature' } });
  assert.equal(r.status, 401);
  const after = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  assert.equal(after, before);
  assert.equal(app.db.prepare('SELECT status FROM deposits WHERE reference = ?').get(reference).status, 'pending');
});
test('a webhook signed with the WRONG secret key is rejected', async () => {
  const reference = await makeDeposit(ada.client, 200000);
  const r = await sendWebhook(ada.client, { event: 'charge.success', data: { reference, amount: 2000, status: 'success' } }, 'sk_test_a_totally_different_secret');
  assert.equal(r.status, 401);
});
test('a webhook with no signature header at all is rejected', async () => {
  const reference = await makeDeposit(ada.client, 200000);
  const r = await ada.client.call('POST', '/api/webhooks/kora', { raw: JSON.stringify({ event: 'charge.success', data: { reference, amount: 2000, status: 'success' } }), headers: { 'Content-Type': 'application/json' } });
  assert.equal(r.status, 401);
});
test('a webhook for an unknown reference is acknowledged but does nothing (no crash, no leak of which references exist)', async () => {
  const body = { event: 'charge.success', data: { reference: 'HB-DEP-NEVER-EXISTED', amount: 1000, status: 'success' } };
  const r = await ada.client.call('POST', '/api/webhooks/kora', { raw: JSON.stringify(body), headers: { 'Content-Type': 'application/json', 'x-korapay-signature': signWebhook(body.data) } });
  assert.equal(r.status, 200);
});
test('a malformed webhook body is rejected before any signature check', async () => {
  const r = await ada.client.call('POST', '/api/webhooks/kora', { raw: JSON.stringify({ nope: true }), headers: { 'Content-Type': 'application/json', 'x-korapay-signature': 'x' } });
  assert.equal(r.status, 400);
});
test('if the server-to-server re-verification with Kora itself fails, nothing is credited and it is reported as retryable', async () => {
  const { resolveByQuery } = require('../src/kora/deposits');
  const reference = await makeDeposit(ada.client, 200000);
  const before = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  const dep = app.db.prepare('SELECT * FROM deposits WHERE reference = ?').get(reference);
  const ctx = { cfg, db: app.db, koraFetch: async () => { throw new Error('network down'); } };
  const result = await resolveByQuery(ctx, dep, { source: 'test' });
  assert.equal(result.queryFailed, true);
  assert.equal(result.changed, false);
  assert.equal(app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo, before);
  assert.equal(app.db.prepare('SELECT status FROM deposits WHERE reference = ?').get(reference).status, 'pending');
});

// ---------- customer status-check self-heals when the webhook hasn't arrived yet ----------
test('checking deposit status resolves it via a live Kora query if still pending (self-heal), then wallet reflects it', async () => {
  const reference = await makeDeposit(ada.client, 150000);
  kora.queryReplies[reference] = { status: true, data: { reference, status: 'success', amount: '1500.00', amount_paid: '1500.00' } };
  const before = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  const r = await ada.client.get(`/api/deposits/${reference}`);
  assert.equal(r.status, 200);
  assert.equal(r.json.deposit.status, 'successful');
  assert.equal(r.json.wallet.balanceKobo, before + 150000);
});
test('checking status on an already-successful deposit does not re-credit', async () => {
  const reference = await makeDeposit(ada.client, 150000);
  kora.queryReplies[reference] = { status: true, data: { reference, status: 'success', amount: '1500.00', amount_paid: '1500.00' } };
  await ada.client.get(`/api/deposits/${reference}`);
  const afterFirst = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  await ada.client.get(`/api/deposits/${reference}`);
  const afterSecond = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  assert.equal(afterFirst, afterSecond);
});

// ---------- public min-deposit endpoint / minimal admin visibility ----------
test('the public settings endpoint exposes only the minimum deposit and currency, nothing else', async () => {
  const r = await new Client().get('/api/settings');
  assert.equal(r.status, 200);
  assert.deepEqual(Object.keys(r.json).sort(), ['currency', 'minDepositKobo']);
});

test("an admin can see a customer's deposit status (minimal visibility), with no secret leaked", async () => {
  const { hashPassword } = require('../src/security');
  app.db.prepare('INSERT INTO admins (email, name, password_hash) VALUES (?,?,?)').run('boss@example.com', 'Boss', await hashPassword('a-strong-admin-passphrase'));
  const admin = new Client();
  const loginRes = await admin.post('/api/admin/login', { email: 'boss@example.com', password: 'a-strong-admin-passphrase' });
  assert.equal(loginRes.status, 200, loginRes.text);
  const lastMail = app.mailer.outbox.at(-1);
  assert.ok(lastMail, 'no mail was sent');
  const codeMatch = /code is (\d{6})/.exec(lastMail.text);
  assert.ok(codeMatch, 'unexpected mail body: ' + lastMail.text);
  const otp = await admin.post('/api/admin/verify-otp', { code: codeMatch[1] });
  assert.equal(otp.status, 200, otp.text);
  const csrf = otp.json.csrfToken;

  const reference = await makeDeposit(ada.client, 500000);
  kora.queryReplies[reference] = { status: true, data: { reference, status: 'success', amount: '5000.00', amount_paid: '5000.00' } };
  await sendWebhook(ada.client, { event: 'charge.success', data: { reference, amount: 5000, status: 'success' } });

  const profile = await admin.call('GET', `/api/admin/customers/${ada.id}`, { headers: { 'X-CSRF-Token': csrf } });
  assert.equal(profile.status, 200, profile.text);
  const dep = profile.json.deposits.find((d) => d.reference === reference);
  assert.ok(dep);
  assert.equal(dep.status, 'successful');
  assert.equal(dep.amountKobo, 500000);
  assert.equal(dep.verifiedAmountKobo, 500000);
  assert.equal(profile.text.includes(SECRET), false);
});
