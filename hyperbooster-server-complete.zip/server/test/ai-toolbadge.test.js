'use strict';
// Regression tests for the admin chat's "Checked: ..." note. The note is built from `toolsUsed` in the chat
// response, so a refused, rate-limited or failed tool call must NOT appear there (and must not be audited as
// a success), while every call that really worked must.
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { loadConfig } = require('../src/config');
const { createApp } = require('../src/app');
const { hashPassword } = require('../src/security');
const { buildTools } = require('../src/ai/tools');

const ADMIN_PW = 'a-strong-admin-passphrase';
const KEY = 'gsk_test_key_0000000000';
const BIG = { max: 1e6, windowMs: 6e4 };
const LIMITS = {
  apiPerIp: BIG, loginPerIp: BIG, loginPerAccount: BIG, registerPerIp: BIG, orderPerUser: BIG,
  adminLoginPerIp: BIG, adminLoginPerAccount: BIG, adminOtpPerIp: BIG, adminApiPerIp: BIG,
  adminAiChatPerAdmin: BIG, adminAiChatPerIp: BIG, adminAiSettingsPerIp: BIG,
};
const SIX_READ = { read_dashboard: true, read_orders: true, read_services: true, read_customers: true, read_wallet: true, read_audit: true };
const SETTINGS = '/api/admin/ai/settings';
const call = (id, name, args = {}) => ({ id, function: { name, arguments: JSON.stringify(args) } });
// Exactly what the admin page shows (see admin-ui/admin.js): a "Checked: ..." line only when toolsUsed is non-empty.
const badgeText = (toolsUsed) => (toolsUsed && toolsUsed.length ? `Checked: ${toolsUsed.join(', ').replaceAll('_', ' ')}` : null);

class Client {
  constructor(base) { this.base = base; this.jar = {}; this.csrf = null; }
  async call(method, url, body) {
    const cookie = Object.entries(this.jar).map(([k, v]) => `${k}=${v}`).join('; ');
    const res = await fetch(this.base + url, {
      method, redirect: 'manual',
      headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(cookie ? { Cookie: cookie } : {}), ...(this.csrf && method !== 'GET' ? { 'X-CSRF-Token': this.csrf } : {}) },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    const text = await res.text(); let json = null; try { json = JSON.parse(text); } catch { /* not json */ }
    for (const c of res.headers.getSetCookie?.() ?? []) { const [pair] = c.split(';'); const i = pair.indexOf('='); const k = pair.slice(0, i); const v = pair.slice(i + 1); if (v === '') delete this.jar[k]; else this.jar[k] = v; }
    return { status: res.status, json, text };
  }
  get(u) { return this.call('GET', u); }
  post(u, b) { return this.call('POST', u, b); }
  patch(u, b) { return this.call('PATCH', u, b); }
}

function makeFake() {
  const f = { script: [], searchReplies: [], mainCalls: [], searchCalls: [] };
  f.fetchImpl = async (url, opts) => {
    const body = JSON.parse(opts.body);
    const ok = (message) => ({ ok: true, status: 200, json: async () => ({ choices: [{ message }] }) });
    if ((body.tools || []).some((t) => t.type === 'browser_search')) {
      f.searchCalls.push(body);
      const r = f.searchReplies.shift() ?? { text: 'A normal search answer.' };
      if (r.fail) return { ok: false, status: r.fail, json: async () => ({}) };
      if (r.throw) throw new Error(r.throw);
      return ok({ content: r.text });
    }
    f.mainCalls.push(body);
    return ok(f.script.shift() ?? { content: 'ok' });
  };
  return f;
}

async function withApp({ webSearch = true } = {}, fn) {
  const fake = makeFake();
  const cfg = loadConfig({}, { databasePath: ':memory:', logRequests: false, mailTransport: 'memory', limits: LIMITS, staticDir: '/nonexistent' });
  const app = createApp(cfg, { aiFetch: fake.fetchImpl });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  try {
    app.db.prepare('INSERT INTO admins (email, name, password_hash) VALUES (?,?,?)').run('boss@example.com', 'The Boss', await hashPassword(ADMIN_PW));
    const boss = new Client(base);
    assert.equal((await boss.post('/api/admin/login', { email: 'boss@example.com', password: ADMIN_PW })).status, 200);
    const otp = await boss.post('/api/admin/verify-otp', { code: /code is (\d{6})/.exec(app.mailer.outbox.at(-1).text)[1] });
    boss.csrf = otp.json.csrfToken;
    const save = (patch) => boss.patch(SETTINGS, { ...patch, currentPassword: ADMIN_PW });
    assert.equal((await save({ enabled: true, apiKey: KEY, searchProvider: 'groq', toolPermissions: { ...SIX_READ, web_search: webSearch } })).status, 200);
    const h = { app, fake, boss, save };
    // One chat message in which the (scripted) model makes these tool calls in a single round.
    h.ask = async (calls, replies = []) => {
      fake.script.push({ content: '', tool_calls: calls.map(([name, args], i) => call(`c${i}`, name, args)) }, { content: 'done' });
      fake.searchReplies.push(...replies);
      const r = await boss.post('/api/admin/ai/chat', { message: 'please look into it' });
      assert.equal(r.status, 200, r.text);
      return r.json;
    };
    h.toolCallAudits = (tool) => app.db.prepare("SELECT details FROM audit_logs WHERE action = 'AI_TOOL_CALLED' ORDER BY id").all().map((r) => JSON.parse(r.details)).filter((d) => d.tool === tool).map((d) => d.success);
    await fn(h);
  } finally { await app.close(); }
}

const words = (n) => { const w = ('abcd '.repeat(Math.ceil(n / 5))).slice(0, n); return w.endsWith(' ') ? `${w.slice(0, -1)}x` : w; };

test('1. a search that really ran IS listed ("Checked: web search") and audited as a success', async () => {
  await withApp({}, async (h) => {
    const r = await h.ask([['web_search', { query: 'latest Node.js LTS version' }]]);
    assert.deepEqual(r.toolsUsed, ['web_search']);
    assert.equal(badgeText(r.toolsUsed), 'Checked: web search');
    assert.deepEqual(h.toolCallAudits('web_search'), [true]);
    assert.equal(h.fake.searchCalls.length, 1);
  });
});

test('2. every kind of refused or failed search is NOT listed and is audited as a failure', async () => {
  await withApp({}, async (h) => {
    const refused = [
      ['too long', { query: words(201) }],
      ['empty', { query: '   ' }],
      ['wrong type', { query: 42 }],
      ['missing', {}],
      ['email', { query: 'find jane@example.com' }],
      ['key-shaped', { query: 'use gsk_abcdefghij1234567890' }],
      ['phone number', { query: 'call 08012345678' }],
    ];
    for (const [label, args] of refused) {
      const r = await h.ask([['web_search', args]]);
      assert.deepEqual(r.toolsUsed, [], `${label}: not listed`);
      assert.equal(badgeText(r.toolsUsed), null, `${label}: no "Checked" note is shown`);
    }
    assert.deepEqual(h.toolCallAudits('web_search'), refused.map(() => false), 'each refusal is audited success:false');
    assert.equal(h.fake.searchCalls.length, 0, 'none reached the search service');

    for (const [label, reply] of [['Groq 500', { fail: 500 }], ['Groq 401', { fail: 401 }], ['Groq 429', { fail: 429 }], ['network error', { throw: 'ECONNRESET' }]]) {
      const r = await h.ask([['web_search', { query: `public topic ${label}` }]], [reply]);
      assert.deepEqual(r.toolsUsed, [], `${label}: not listed`);
      assert.equal(badgeText(r.toolsUsed), null);
    }
    assert.deepEqual(h.toolCallAudits('web_search').slice(refused.length), [false, false, false, false], 'provider failures are audited success:false');
    assert.equal(h.fake.searchCalls.length, 4, 'those four did reach the service (and failed there)');

    await h.save({ model: 'llama-3.3-70b-versatile' });
    const u = await h.ask([['web_search', { query: 'public topic unsupported model' }]]);
    assert.deepEqual(u.toolsUsed, [], 'unsupported model: not listed');
    assert.equal(h.toolCallAudits('web_search').at(-1), false);
  });
});

test('3. a rate-limited search is not listed: 12 requested in one message, only the 10 that ran are counted', async () => {
  await withApp({}, async (h) => {
    const r = await h.ask(Array.from({ length: 12 }, (_, i) => ['web_search', { query: `public topic number ${i}` }]));
    assert.equal(h.fake.searchCalls.length, 10);
    assert.equal(r.toolsUsed.length, 10, 'ten searches really ran');
    assert.equal(r.toolsUsed.every((t) => t === 'web_search'), true);
    const audits = h.toolCallAudits('web_search');
    assert.deepEqual([audits.filter(Boolean).length, audits.filter((x) => !x).length], [10, 2], '10 successes and 2 failures audited');
    const next = await h.ask([['web_search', { query: 'one more public topic' }]]);
    assert.deepEqual(next.toolsUsed, [], 'still limited in the next message: nothing listed');
    assert.equal(badgeText(next.toolsUsed), null);
  });
});

test('4. mixed message: only the calls that really worked are listed, in order, and the audit flags match', async () => {
  await withApp({}, async (h) => {
    const r = await h.ask([
      ['get_dashboard_stats', {}],
      ['web_search', { query: 'public topic that works' }],
      ['web_search', { query: words(250) }],
      ['web_search', { query: 'mail jane@example.com' }],
      ['get_system_status', {}],
      ['no_such_tool', {}],
    ]);
    assert.deepEqual(r.toolsUsed, ['get_dashboard_stats', 'web_search', 'get_system_status']);
    assert.equal(badgeText(r.toolsUsed), 'Checked: get dashboard stats, web search, get system status');
    assert.deepEqual(h.toolCallAudits('web_search'), [true, false, false]);
    assert.deepEqual([h.toolCallAudits('get_dashboard_stats'), h.toolCallAudits('get_system_status')], [[true], [true]]);
  });
});

test('5. nothing changes for the original tools: those that work are still listed and audited as successes', async () => {
  await withApp({}, async (h) => {
    const safe = ['get_dashboard_stats', 'get_system_status', 'get_recent_activity', 'get_pending_orders', 'get_services', 'get_customers', 'get_orders', 'get_audit_logs'];
    for (const n of safe) assert.ok(buildTools(h.app.db)[n], n);
    const r = await h.ask(safe.map((n) => [n, {}]));
    assert.deepEqual(r.toolsUsed, safe);
    for (const n of safe) assert.deepEqual(h.toolCallAudits(n), [true], n);
  });
});

test('6. the existing failure paths are unchanged: a crashing tool, an unknown tool and a switched-off search are not listed', async () => {
  await withApp({}, async (h) => {
    h.app.db.exec('ALTER TABLE orders RENAME TO orders_renamed'); // makes get_orders throw inside its handler
    const crash = await h.ask([['get_orders', {}], ['no_such_tool', {}]]);
    assert.deepEqual(crash.toolsUsed, [], 'a tool that throws is not listed');
    assert.deepEqual(h.toolCallAudits('get_orders'), [false]);
  });
  await withApp({ webSearch: false }, async (h) => {
    const off = await h.ask([['web_search', { query: 'public topic' }]]);
    assert.deepEqual(off.toolsUsed, [], 'search switched OFF: not listed');
    assert.deepEqual(h.toolCallAudits('web_search'), [], 'and nothing is audited as a tool call');
    assert.equal(h.fake.searchCalls.length, 0);
  });
});

test('7. no stale badge: toolsUsed is never saved, so reloading a conversation cannot show "Checked" for a refused search', async () => {
  await withApp({}, async (h) => {
    const r = await h.ask([['web_search', { query: words(250) }]]);
    assert.deepEqual(r.toolsUsed, []);
    // ai_messages has a tool_name column, but nothing ever fills it: only user and assistant messages are saved.
    const ok = await h.ask([['web_search', { query: 'a search that works' }]]);
    assert.deepEqual(ok.toolsUsed, ['web_search']);
    const rows = h.app.db.prepare('SELECT role, tool_name FROM ai_messages').all();
    assert.ok(rows.length >= 4, `${rows.length} messages saved`);
    assert.equal(rows.every((m) => m.tool_name === null && m.role !== 'tool'), true, 'no tool name or tool message is ever stored, not even for a search that worked');
    const conv = await h.boss.get(`/api/admin/ai/conversations/${r.conversationId}/messages`);
    assert.equal(conv.status, 200, conv.text);
    assert.equal(/toolsUsed|tools_used|Checked/.test(conv.text), false, 'a reloaded conversation carries no tool-use data');
    assert.deepEqual([...new Set(conv.json.messages.flatMap((m) => Object.keys(m)))].sort(), ['content', 'createdAt', 'role'], 'a reloaded message carries only role, content and time');
  });
});

test('8. the admin page builds the note only from a non-empty toolsUsed, exactly as these tests assume', async () => {
  await withApp({}, async (h) => {
    const js = (await h.boss.get('/admin/assets/admin.js')).text;
    assert.ok(js.includes("if (r.toolsUsed && r.toolsUsed.length) working.append(h('div', { class: 'chat-tool-note', text: `Checked: ${r.toolsUsed.join(', ').replaceAll('_', ' ')}` }));"),
      'the UI expression is the one badgeText() mirrors');
    assert.equal((js.match(/Checked:/g) || []).length, 1, 'there is one place that renders the note');
    assert.equal(badgeText([]), null);
    assert.equal(badgeText(['web_search']), 'Checked: web search');
  });
});
