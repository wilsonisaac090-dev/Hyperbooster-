'use strict';
const { test, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { loadConfig } = require('../src/config');
const { createApp } = require('../src/app');

const API_KEY = 'nsm_test_fake_key_for_tests';
const LIMITS = {
  apiPerIp: { max: 1e6, windowMs: 6e4 }, loginPerIp: { max: 1e6, windowMs: 6e4 }, loginPerAccount: { max: 1e6, windowMs: 6e4 },
  registerPerIp: { max: 1e6, windowMs: 6e4 }, orderPerUser: { max: 1e6, windowMs: 6e4 },
  adminLoginPerIp: { max: 1e6, windowMs: 6e4 }, adminLoginPerAccount: { max: 1e6, windowMs: 6e4 }, adminOtpPerIp: { max: 1e6, windowMs: 6e4 }, adminApiPerIp: { max: 1e6, windowMs: 6e4 },
  adminAiChatPerAdmin: { max: 1e6, windowMs: 6e4 }, adminAiChatPerIp: { max: 1e6, windowMs: 6e4 }, adminAiSettingsPerIp: { max: 1e6, windowMs: 6e4 },
  depositCreatePerUser: { max: 1e6, windowMs: 6e4 }, depositCreatePerIp: { max: 1e6, windowMs: 6e4 }, koraWebhookPerIp: { max: 1e6, windowMs: 6e4 },
};

let app, base, cfg, calls;

class Client {
  constructor() { this.jar = {}; }
  async call(method, url, { body, headers = {} } = {}) {
    const cookie = Object.entries(this.jar).map(([k, v]) => `${k}=${v}`).join('; ');
    const res = await fetch(base + url, { method, headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(cookie ? { Cookie: cookie } : {}), ...headers }, body: body !== undefined ? JSON.stringify(body) : undefined });
    const text = await res.text(); let json = null; try { json = JSON.parse(text); } catch { /* not json */ }
    for (const c of res.headers.getSetCookie?.() ?? []) { const [pair] = c.split(';'); const i = pair.indexOf('='); const k = pair.slice(0, i); const v = pair.slice(i + 1); if (v === '') delete this.jar[k]; else this.jar[k] = v; }
    return { status: res.status, json, text };
  }
  get(u, o) { return this.call('GET', u, o); }
  post(u, body, o) { return this.call('POST', u, { body, ...o }); }
  patch(u, body, o) { return this.call('PATCH', u, { method: 'PATCH', body, ...o }); }
}

// A scripted fake NigeriaSMM server: tests control exactly what "the provider" replies with, never touch the real internet.
function makeFakeProvider() {
  const addReplies = []; let statusReply = null;
  const fetchImpl = async (url, opts) => {
    const params = new URLSearchParams(opts.body);
    calls.push({ url, action: params.get('action'), key: params.get('key'), params: Object.fromEntries(params) });
    if (params.get('action') === 'add') {
      const next = addReplies.shift() ?? { order: '9001' };
      return { ok: true, status: 200, json: async () => next };
    }
    if (params.get('action') === 'status') {
      if (params.has('orders')) {
        const ids = params.get('orders').split(',');
        const out = {}; for (const id of ids) out[id] = statusReply?.[id] || { error: 'Not found' };
        return { ok: true, status: 200, json: async () => out };
      }
      return { ok: true, status: 200, json: async () => (statusReply?.[params.get('order')] || { error: 'Not found' }) };
    }
    return { ok: true, status: 200, json: async () => ({ error: 'Unknown action' }) };
  };
  return { fetchImpl, addReplies, get statusReply() { return statusReply; }, setStatus(id, row) { statusReply = statusReply || {}; statusReply[id] = row; } };
}

async function newCustomer(email, name = 'Cust') {
  const c = new Client();
  const r = await c.post('/api/register', { fullName: name, email, password: 'a-long-password' });
  assert.equal(r.status, 201, r.text);
  return { client: c, id: r.json.user.id };
}

async function loginAdmin(email, password) {
  const c = new Client();
  const login = await c.post('/api/admin/login', { email, password });
  assert.equal(login.status, 200, login.text);
  const mail = app.mailer.outbox.at(-1);
  const match = /code is (\d{6})/.exec(mail.text);
  assert.ok(match, 'no OTP mail: ' + mail.text);
  const otp = await c.post('/api/admin/verify-otp', { code: match[1] });
  assert.equal(otp.status, 200, otp.text);
  return { client: c, csrf: otp.json.csrfToken };
}

let serviceCounter = 0;
async function makeService(admin, { providerServiceId = '555', providerCostKobo = 50000, priceKobo = 100000 } = {}) {
  serviceCounter += 1;
  const r = await admin.client.post('/api/admin/services', {
    name: `Instagram Followers ${serviceCounter}`, category: 'Followers', platform: 'instagram', serviceType: 'followers',
    providerServiceId, providerCostKobo, pricePer1000Kobo: priceKobo, minQuantity: 100, maxQuantity: 100000,
    refillAvailable: false, dropRate: 'Low', averageCompletionTime: '0-2 hours', description: 'x', isActive: true,
  }, { headers: { 'X-CSRF-Token': admin.csrf } });
  assert.equal(r.status, 201, r.text);
  return r.json.service.id;
}

let provider, admin, ada;
before(async () => {
  provider = makeFakeProvider(); calls = [];
  cfg = loadConfig({ NIGERIASMMPANEL_API_KEY: API_KEY, NIGERIASMMPANEL_API_URL: 'https://nigeriasmm.com/api/v2' }, { databasePath: ':memory:', logRequests: false, mailTransport: 'memory', limits: LIMITS, staticDir: '/nonexistent' });
  app = createApp(cfg, { providerFetch: provider.fetchImpl });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  const { hashPassword } = require('../src/security');
  app.db.prepare('INSERT INTO admins (email, name, password_hash) VALUES (?,?,?)').run('boss@example.com', 'Boss', await hashPassword('a-strong-admin-passphrase'));
  admin = await loginAdmin('boss@example.com', 'a-strong-admin-passphrase');
  ada = await newCustomer('ada@example.com', 'Ada Lovelace');
});
after(() => app.close());
beforeEach(async () => { provider.addReplies.length = 0; calls.length = 0; await new Promise((r) => setTimeout(r, 1)); await app.db.prepare("UPDATE users SET balance_kobo = 1000000 WHERE id = ?").run(ada.id); });

async function credit(client, kobo = 1000000) {
  await app.db.prepare('UPDATE users SET balance_kobo = ? WHERE id = ?').run(kobo, ada.id);
}

// ---------- 1. successful provider order ----------
test('a successful order: wallet charged once, request sent server-side with the key, provider order id saved, status becomes processing (never completed just because the request was sent)', async () => {
  const svcId = await makeService(admin, { providerServiceId: '777', priceKobo: 100000 });
  provider.addReplies.push({ order: '55501' });
  await credit(ada.client);
  const before = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;

  const r = await ada.client.post('/api/orders', { serviceId: svcId, quantity: 1000, link: 'https://instagram.com/ada' });
  assert.equal(r.status, 201, r.text);
  assert.equal(r.json.order.status, 'processing');
  assert.notEqual(r.json.order.status, 'completed');

  const after = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  assert.equal(before - after, 100000, 'charged exactly the calculated customer price, once');

  const row = app.db.prepare('SELECT * FROM orders WHERE id = ?').get(r.json.order.id);
  assert.equal(row.provider_order_id, '55501');

  const addCall = calls.find((c) => c.action === 'add');
  assert.equal(addCall.key, API_KEY);
  assert.equal(addCall.params.service, '777');
  assert.equal(addCall.params.quantity, '1000');
});

// ---------- 2. provider rejection -> refund exactly once ----------
test('a provider rejection refunds the customer exactly once and marks the order failed, not completed', async () => {
  const svcId = await makeService(admin, { providerServiceId: '778', priceKobo: 200000 });
  provider.addReplies.push({ error: 'Not enough funds on provider side' });
  await credit(ada.client);
  const before = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;

  const r = await ada.client.post('/api/orders', { serviceId: svcId, quantity: 1000, link: 'https://instagram.com/ada' });
  assert.equal(r.status, 201, r.text); // the ORDER ROW still exists; it just ends up failed+refunded
  assert.equal(r.json.order.status, 'failed');

  const after = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  assert.equal(after, before, 'refunded back to the exact pre-charge balance');

  const ledgerRows = app.db.prepare("SELECT amount_kobo FROM wallet_ledger WHERE reference_type='order' AND reference_id = ? AND entry_type='order_refund'").all(r.json.order.id);
  assert.equal(ledgerRows.length, 1, 'exactly one refund entry');
  assert.equal(ledgerRows[0].amount_kobo, 200000);
});

test('after an automatic provider-rejection refund, the admin cannot also refund the same order (blocked at the status-transition guard, AND the two paths share one idempotency key)', async () => {
  const svcId = await makeService(admin, { providerServiceId: '779', priceKobo: 150000 });
  provider.addReplies.push({ error: 'rejected' });
  await credit(ada.client);
  const r = await ada.client.post('/api/orders', { serviceId: svcId, quantity: 1000, link: 'https://x.com/a' });
  const orderId = r.json.order.id;
  assert.equal(r.json.order.status, 'failed', 'already auto-refunded and marked failed');
  const before = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;

  // The admin trying to redundantly mark it failed again is rejected by the transition guard itself...
  const patch = await admin.client.post(`/api/admin/orders/${orderId}/status`, { status: 'failed' }, { headers: { 'X-CSRF-Token': admin.csrf } });
  assert.equal(patch.status, 409, patch.text);

  // ...and even if that guard were bypassed, both paths write to the SAME idempotency key, so a
  // second refund attempt on this order is a provably safe no-op at the ledger level too.
  const { refundOrderOnce } = require('../src/provider/orders');
  const { transaction } = require('../src/db');
  const order = app.db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  const second = transaction(app.db, () => refundOrderOnce(app.db, order, 'double-refund attempt'));
  assert.equal(second.refunded, false, 'ledger-level idempotency key rejected the duplicate');

  const after = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  assert.equal(after, before, 'balance unchanged by either the blocked admin action or the duplicate refund attempt');
});

// ---------- 3. insufficient wallet balance ----------
test('insufficient wallet balance blocks the order before the provider is ever contacted', async () => {
  const svcId = await makeService(admin, { providerServiceId: '780', priceKobo: 500000 });
  await credit(ada.client, 100); // far less than needed
  const r = await ada.client.post('/api/orders', { serviceId: svcId, quantity: 1000, link: 'https://x.com/a' });
  assert.equal(r.status, 402, r.text);
  assert.equal(calls.filter((c) => c.action === 'add').length, 0, 'provider was never called');
});

// ---------- 4. duplicate order protection ----------
test('submitting the identical order twice in quick succession does not double-charge or double-place it', async () => {
  const svcId = await makeService(admin, { providerServiceId: '781', priceKobo: 100000 });
  provider.addReplies.push({ order: 'A1' }, { order: 'A2' });
  await credit(ada.client);
  const before = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  const body = { serviceId: svcId, quantity: 1000, link: 'https://x.com/dup' };
  const [r1, r2] = await Promise.all([ada.client.post('/api/orders', body), ada.client.post('/api/orders', body)]);
  const statuses = [r1.status, r2.status].sort();
  const succeeded = [r1, r2].filter((r) => r.status === 201);
  const after = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  assert.equal(before - after, succeeded.length * 100000, 'balance only reflects orders that actually went through — no phantom extra charge');
  assert.ok(statuses.includes(201));
});

// ---------- 5. status sync ----------
test('provider status sync maps a documented status onto the existing order enum and updates start_count/remains', async () => {
  const svcId = await makeService(admin, { providerServiceId: '790', priceKobo: 100000 });
  provider.addReplies.push({ order: 'S1' });
  await credit(ada.client);
  const r = await ada.client.post('/api/orders', { serviceId: svcId, quantity: 1000, link: 'https://x.com/s' });
  const orderId = r.json.order.id;
  app.db.prepare("UPDATE orders SET updated_at = '1970-01-01T00:00:00.000Z' WHERE id = ?").run(orderId);
  provider.setStatus('S1', { charge: '4.50', start_count: '120', status: 'Completed', remains: '0', currency: 'USD' });

  const { syncProviderOrders } = require('../src/provider/orders');
  const result = await syncProviderOrders({ cfg, db: app.db, providerFetch: provider.fetchImpl }, { limit: 100 });
  assert.equal(result.updated, 1);

  const row = app.db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  assert.equal(row.status, 'completed');
  assert.equal(row.start_count, 120);
  assert.equal(row.remains, 0);
  assert.equal(row.provider_status, 'Completed');
  assert.ok(row.completed_at);
});

test('an unrecognized provider status is recorded but does not corrupt the existing order status', async () => {
  const svcId = await makeService(admin, { providerServiceId: '791', priceKobo: 100000 });
  provider.addReplies.push({ order: 'S2' });
  await credit(ada.client);
  const r = await ada.client.post('/api/orders', { serviceId: svcId, quantity: 500, link: 'https://x.com/s2' });
  const orderId = r.json.order.id;
  app.db.prepare("UPDATE orders SET updated_at = '1970-01-01T00:00:00.000Z' WHERE id = ?").run(orderId);
  provider.setStatus('S2', { status: 'SomeNewStatusWeHaveNeverSeen', start_count: '10', remains: '5' });

  const { syncProviderOrders } = require('../src/provider/orders');
  await syncProviderOrders({ cfg, db: app.db, providerFetch: provider.fetchImpl }, { limit: 100 });
  const row = app.db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  assert.equal(row.status, 'processing', 'left untouched rather than guessed');
  assert.equal(row.provider_status, 'SomeNewStatusWeHaveNeverSeen', 'raw text still recorded for admin visibility');
});

test('a provider "canceled" status triggers exactly one refund', async () => {
  const svcId = await makeService(admin, { providerServiceId: '792', priceKobo: 300000 });
  provider.addReplies.push({ order: 'S3' });
  await credit(ada.client);
  const r = await ada.client.post('/api/orders', { serviceId: svcId, quantity: 1000, link: 'https://x.com/s3' });
  const orderId = r.json.order.id;
  const afterCharge = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  app.db.prepare("UPDATE orders SET updated_at = '1970-01-01T00:00:00.000Z' WHERE id = ?").run(orderId);
  provider.setStatus('S3', { status: 'Canceled', start_count: '0', remains: '1000' });

  const { syncProviderOrders } = require('../src/provider/orders');
  await syncProviderOrders({ cfg, db: app.db, providerFetch: provider.fetchImpl }, { limit: 100 });
  const after = app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
  assert.equal(after - afterCharge, 300000, 'refunded back the exact charge amount');
  const ledgerRows = app.db.prepare("SELECT id FROM wallet_ledger WHERE reference_type='order' AND reference_id = ? AND entry_type='order_refund'").all(orderId);
  assert.equal(ledgerRows.length, 1);
});

test('the admin-triggered single-order sync endpoint refreshes one order on demand', async () => {
  const svcId = await makeService(admin, { providerServiceId: '793', priceKobo: 100000 });
  provider.addReplies.push({ order: 'S4' });
  await credit(ada.client);
  const r = await ada.client.post('/api/orders', { serviceId: svcId, quantity: 1000, link: 'https://x.com/s4' });
  provider.setStatus('S4', { status: 'Completed', start_count: '5', remains: '0' });
  const sync = await admin.client.post(`/api/admin/orders/${r.json.order.id}/sync`, {}, { headers: { 'X-CSRF-Token': admin.csrf } });
  assert.equal(sync.status, 200, sync.text);
  assert.equal(sync.json.order.status, 'completed');
});

// ---------- 6. key never leaked ----------
test('the provider API key never appears in any customer or admin response', async () => {
  const svcId = await makeService(admin, { providerServiceId: '800', priceKobo: 100000 });
  provider.addReplies.push({ order: 'K1' });
  await credit(ada.client);
  const r = await ada.client.post('/api/orders', { serviceId: svcId, quantity: 1000, link: 'https://x.com/k' });
  assert.equal(r.text.includes(API_KEY), false);
  const settings = await admin.client.get('/api/admin/settings', { headers: { 'X-CSRF-Token': admin.csrf } });
  assert.equal(settings.text.includes(API_KEY), false);
});

test('customers never see provider_service_id or provider cost anywhere in the public API', async () => {
  const svcId = await makeService(admin, { providerServiceId: '801', providerCostKobo: 42000, priceKobo: 100000 });
  const list = await ada.client.get('/api/services');
  assert.equal(list.text.includes('801'), false);
  assert.equal(list.text.toLowerCase().includes('providerservice'), false);
  assert.equal(list.text.toLowerCase().includes('providercost'), false);
  const order = await ada.client.post('/api/orders', { serviceId: svcId, quantity: 1000, link: 'https://x.com/p' });
  assert.equal(JSON.stringify(order.json).toLowerCase().includes('providerservice'), false);
  assert.equal(JSON.stringify(order.json).toLowerCase().includes('providercost'), false);
});

// ---------- 7. customers cannot access admin APIs ----------
test('a signed-in customer cannot reach any admin order/service/settings endpoint', async () => {
  assert.equal((await ada.client.get('/api/admin/orders')).status, 401);
  assert.equal((await ada.client.get('/api/admin/settings')).status, 401);
  assert.equal((await ada.client.post('/api/admin/services', {})).status, 401);
  assert.equal((await ada.client.post('/api/admin/orders/1/sync', {})).status, 401);
});

// ---------- services without a provider mapping simply aren't forwarded ----------
test('a service with no providerServiceId stays pending locally instead of erroring the order', async () => {
  const r = await admin.client.post('/api/admin/services', {
    name: 'Manual Fulfillment Service', category: 'Other', platform: 'tiktok', serviceType: 'views',
    pricePer1000Kobo: 50000, minQuantity: 10, maxQuantity: 1000, refillAvailable: false, dropRate: 'Low', averageCompletionTime: '1 day', description: 'x', isActive: true,
  }, { headers: { 'X-CSRF-Token': admin.csrf } });
  assert.equal(r.status, 201, r.text);
  await credit(ada.client);
  const order = await ada.client.post('/api/orders', { serviceId: r.json.service.id, quantity: 100, link: 'https://tiktok.com/x' });
  assert.equal(order.status, 201, order.text);
  assert.equal(order.json.order.status, 'pending');
  assert.equal(calls.filter((c) => c.action === 'add').length, 0);
});

// ---------- overlap guard / rate of requests ----------
test('a batched sync call fetches multiple orders in ONE provider request (multistatus), not one call per order', async () => {
  const svcId = await makeService(admin, { providerServiceId: '900', priceKobo: 50000 });
  await credit(ada.client, 1000000);
  const ids = [];
  for (const providerId of ['M1', 'M2', 'M3']) {
    provider.addReplies.push({ order: providerId });
    const r = await ada.client.post('/api/orders', { serviceId: svcId, quantity: 100, link: 'https://x.com/m' });
    ids.push(r.json.order.id);
    provider.setStatus(providerId, { status: 'Completed', start_count: '1', remains: '0' });
  }
  for (const id of ids) app.db.prepare("UPDATE orders SET updated_at = '1970-01-01T00:00:00.000Z' WHERE id = ?").run(id);
  calls.length = 0;
  const { syncProviderOrders } = require('../src/provider/orders');
  const result = await syncProviderOrders({ cfg, db: app.db, providerFetch: provider.fetchImpl }, { limit: 100 });
  assert.equal(result.updated, 3);
  const statusCalls = calls.filter((c) => c.action === 'status');
  assert.equal(statusCalls.length, 1, 'one batched multistatus call, not three');
  assert.equal(statusCalls[0].params.orders.split(',').length, 3);
});
