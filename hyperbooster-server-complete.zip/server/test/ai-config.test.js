'use strict';
// Step 2: migration v6 + web-search / vision configuration plumbing. These tests cover the SETTINGS only:
// neither the web_search tool nor image analysis exists yet, and test 11 proves enabling them does nothing.
const { test, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const vm = require('node:vm');
const { DatabaseSync } = require('node:sqlite');
const { loadConfig } = require('../src/config');
const { createApp } = require('../src/app');
const { openDatabase } = require('../src/db');
const { MIGRATIONS } = require('../src/migrations');
const { hashPassword } = require('../src/security');
const { buildTools } = require('../src/ai/tools');
const { AI_LIMITS } = require('../src/ai/limits');

const ADMIN_PW = 'a-strong-admin-passphrase';
const BIG = { max: 1e6, windowMs: 6e4 };
const LIMITS = {
  apiPerIp: BIG, loginPerIp: BIG, loginPerAccount: BIG, registerPerIp: BIG, orderPerUser: BIG,
  adminLoginPerIp: BIG, adminLoginPerAccount: { max: 5, windowMs: 6e4 }, adminOtpPerIp: BIG, adminApiPerIp: BIG,
  adminAiChatPerAdmin: BIG, adminAiChatPerIp: BIG, adminAiSettingsPerIp: BIG,
};
const SIX_READ = { read_dashboard: true, read_orders: true, read_services: true, read_customers: true, read_wallet: true, read_audit: true };
const SETTINGS = '/api/admin/ai/settings';

let app, base, boss, fake;

class Client {
  constructor() { this.jar = {}; this.csrf = null; }
  async call(method, url, body, opts = {}) {
    const cookie = Object.entries(this.jar).map(([k, v]) => `${k}=${v}`).join('; ');
    const res = await fetch(base + url, {
      method, redirect: 'manual',
      headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(cookie ? { Cookie: cookie } : {}), ...(this.csrf && method !== 'GET' && opts.csrf !== false ? { 'X-CSRF-Token': this.csrf } : {}) },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    const text = await res.text(); let json = null; try { json = JSON.parse(text); } catch { /* not json */ }
    for (const c of res.headers.getSetCookie?.() ?? []) { const [pair] = c.split(';'); const i = pair.indexOf('='); const k = pair.slice(0, i); const v = pair.slice(i + 1); if (v === '') delete this.jar[k]; else this.jar[k] = v; }
    return { status: res.status, json, text };
  }
  get(u) { return this.call('GET', u); }
  post(u, b, o) { return this.call('POST', u, b, o); }
  patch(u, b, o) { return this.call('PATCH', u, b, o); }
}

const save = (patch) => boss.patch(SETTINGS, { ...patch, currentPassword: ADMIN_PW });
const current = async () => (await boss.get(SETTINGS)).json;
const rawStored = () => JSON.parse(app.db.prepare('SELECT tool_permissions FROM ai_settings WHERE id = 1').get().tool_permissions);
const tmpDir = () => fs.mkdtempSync(path.join(os.tmpdir(), 'hb-v6-'));
const listJs = (dir) => fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? listJs(path.join(dir, e.name)) : e.name.endsWith('.js') ? [path.join(dir, e.name)] : []));

before(async () => {
  fake = { script: [], seen: [] };
  const aiFetch = async (url, opts) => {
    fake.seen.push({ url, body: JSON.parse(opts.body) });
    const next = fake.script.shift();
    return { ok: true, status: 200, json: async () => ({ choices: [{ message: next || { content: 'ok' } }] }) };
  };
  const cfg = loadConfig({}, { databasePath: ':memory:', logRequests: false, mailTransport: 'memory', limits: LIMITS, staticDir: '/nonexistent' });
  app = createApp(cfg, { aiFetch });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  app.db.prepare('INSERT INTO admins (email, name, password_hash) VALUES (?,?,?)').run('boss@example.com', 'The Boss', await hashPassword(ADMIN_PW));
  boss = new Client();
  assert.equal((await boss.post('/api/admin/login', { email: 'boss@example.com', password: ADMIN_PW })).status, 200);
  const otp = await boss.post('/api/admin/verify-otp', { code: /code is (\d{6})/.exec(app.mailer.outbox.at(-1).text)[1] });
  assert.equal(otp.status, 200, otp.text);
  boss.csrf = otp.json.csrfToken;
});
after(() => app.close());
beforeEach(() => { fake.script.length = 0; fake.seen.length = 0; });

// =====================================================================================================
// MIGRATION v6
// =====================================================================================================

test('1. a fresh database is at the latest schema version (7), with vision_model (v6) NOT NULL and defaulting to the configured constant', () => {
  const db = openDatabase(':memory:');
  assert.equal(MIGRATIONS.at(-1).version, 7);
  assert.deepEqual(MIGRATIONS.map((m) => m.version), [1, 2, 3, 4, 5, 6, 7], 'v1-v6 are still there, v7 (Exa search settings) is the only addition');
  assert.equal(db.prepare('PRAGMA user_version').get().user_version, 7);
  const col = db.prepare('PRAGMA table_info(ai_settings)').all().find((c) => c.name === 'vision_model');
  assert.ok(col, 'vision_model column exists');
  assert.equal(col.notnull, 1);
  assert.equal(db.prepare('SELECT vision_model FROM ai_settings WHERE id = 1').get().vision_model, AI_LIMITS.DEFAULT_VISION_MODEL);
  assert.equal(db.prepare('SELECT tool_permissions FROM ai_settings WHERE id = 1').get().tool_permissions, '{}', 'no permission is pre-granted by the migration');
  db.close();
});

test('2. upgrading a REAL v5 database (through v6 and v7) keeps every existing EL setting and adds the default vision model', () => {
  const dir = tmpDir(); const file = path.join(dir, 'v5.db');
  try {
    const old = new DatabaseSync(file);
    for (const m of MIGRATIONS.filter((x) => x.version <= 5)) { old.exec(m.sql); old.exec(`PRAGMA user_version = ${m.version}`); }
    old.prepare("UPDATE ai_settings SET enabled = 1, model = 'custom/model-x', assistant_name = 'Zed', tool_permissions = ?, api_key_ciphertext = 'cipher-blob', api_key_last4 = 'abcd', system_instructions = 'be brief' WHERE id = 1").run('{"read_orders":false}');
    assert.equal(old.prepare('PRAGMA user_version').get().user_version, 5);
    assert.equal(old.prepare('PRAGMA table_info(ai_settings)').all().some((c) => c.name === 'vision_model'), false, 'really a v5 database');
    old.close();

    const db = openDatabase(file); // the real code path: opens and migrates
    const row = db.prepare('SELECT * FROM ai_settings WHERE id = 1').get();
    assert.equal(db.prepare('PRAGMA user_version').get().user_version, 7);
    assert.equal(row.vision_model, AI_LIMITS.DEFAULT_VISION_MODEL);
    assert.deepEqual([row.enabled, row.model, row.assistant_name, row.tool_permissions, row.api_key_ciphertext, row.api_key_last4, row.system_instructions], [1, 'custom/model-x', 'Zed', '{"read_orders":false}', 'cipher-blob', 'abcd', 'be brief']);
    db.close();
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test('3. re-opening an already-migrated database is a safe no-op (still v7, data intact)', () => {
  const dir = tmpDir(); const file = path.join(dir, 'again.db');
  try {
    const a = openDatabase(file);
    a.prepare("UPDATE ai_settings SET vision_model = 'other/model' WHERE id = 1").run();
    a.close();
    const b = openDatabase(file);
    assert.equal(b.prepare('PRAGMA user_version').get().user_version, 7);
    assert.equal(b.prepare('SELECT vision_model FROM ai_settings WHERE id = 1').get().vision_model, 'other/model');
    b.close();
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

// =====================================================================================================
// SETTINGS PAYLOAD + PERMISSIONS
// =====================================================================================================

test('4. settings payload: new fields present, web search and vision default OFF, existing read permissions unchanged, nothing secret', async () => {
  const p = await current();
  assert.equal(p.toolPermissions.web_search, false);
  assert.equal(p.toolPermissions.vision, false);
  for (const k of Object.keys(SIX_READ)) assert.equal(p.toolPermissions[k], true, `${k} keeps its default-on behaviour`);
  assert.deepEqual(Object.keys(p.toolPermissions), [...Object.keys(SIX_READ), 'web_search', 'vision']);
  assert.equal(p.visionModel, AI_LIMITS.DEFAULT_VISION_MODEL);
  assert.deepEqual(p.capabilityAvailable, { web_search: true, vision: true }, 'web search (Step 3) and image analysis (Step 4) are both implemented');
  assert.deepEqual(p.limits, { webSearch: { maxQueryChars: 200, maxResults: { min: 1, max: 10, default: 5 }, resultChars: { min: 500, max: 8000, default: 4000 } }, vision: { maxImages: 3, maxImageBytes: 2 * 1024 * 1024 } });
  assert.equal(p.financialActionsPermanentlyDisabled, true);
  assert.equal(p.writeActionsDisabled, true);
  assert.equal(rawStored().web_search, undefined, 'a fresh install stores no capability grant at all');
  assert.equal(/ciphertext|apiKey"\s*:\s*"/i.test(JSON.stringify(p)), false, 'no secret material in the payload');
});

test('5. permission validation: capability keys accept only booleans; unknown, mis-cased and financial keys are still rejected, all-or-nothing', async () => {
  const status = async (perms) => (await save({ toolPermissions: perms })).status;
  assert.equal(await status({ web_search: 'yes' }), 400);
  assert.equal(await status({ vision: 1 }), 400);
  assert.equal(await status({ vision: null }), 400);
  assert.equal(await status({ Vision: true }), 400, 'case-sensitive');
  assert.equal(await status({ 'web_search ': true }), 400);
  assert.equal(await status({ web_search_admin: true }), 400);
  assert.equal(await status({ credit_wallet: true }), 400);
  assert.equal(await status({ financial: true }), 400);
  assert.equal(await status(JSON.parse('{"__proto__": true}')), 400, 'a literal __proto__ key is just an unknown key');
  assert.equal(await status({ web_search: true, credit_wallet: true }), 400, 'one bad key rejects the whole request...');
  assert.equal((await current()).toolPermissions.web_search, false, '...and the good key was not applied');
  assert.equal(await status([]), 400);
  assert.equal(await status('web_search'), 400);
});

test('6. toggling is independent and persistent; the old six-key UI payload never resets a capability', async () => {
  let r = await save({ toolPermissions: { web_search: true } });
  assert.equal(r.status, 200, r.text);
  assert.deepEqual([r.json.toolPermissions.web_search, r.json.toolPermissions.vision], [true, false]);
  assert.equal(rawStored().web_search, true);

  r = await save({ toolPermissions: { vision: true } });
  assert.deepEqual([r.json.toolPermissions.web_search, r.json.toolPermissions.vision], [true, true]);

  r = await save({ toolPermissions: { ...SIX_READ, read_orders: false } }); // what the pre-Step-2 admin UI sent
  assert.equal(r.status, 200, r.text);
  assert.deepEqual([r.json.toolPermissions.web_search, r.json.toolPermissions.vision, r.json.toolPermissions.read_orders], [true, true, false], 'capabilities survive an old-shaped save');
  await save({ toolPermissions: { read_orders: true } });

  r = await save({ toolPermissions: { web_search: false, vision: false } });
  assert.deepEqual([r.json.toolPermissions.web_search, r.json.toolPermissions.vision], [false, false]);
  assert.deepEqual([rawStored().web_search, rawStored().vision], [false, false]);
  assert.deepEqual((await current()).toolPermissions, { ...SIX_READ, web_search: false, vision: false });
});

test('7. every settings change, including the new ones, needs the admin password, a CSRF token and a session', async () => {
  const before = JSON.stringify(await current());
  const patch = { toolPermissions: { web_search: true }, visionModel: 'sneaky/model' };
  assert.equal((await boss.patch(SETTINGS, patch)).status, 403, 'no password');
  assert.equal((await boss.patch(SETTINGS, { ...patch, currentPassword: 'wrong-password' })).status, 403, 'wrong password');
  assert.equal((await boss.patch(SETTINGS, { ...patch, currentPassword: ADMIN_PW }, { csrf: false })).status, 403, 'no CSRF token');
  assert.equal((await boss.patch(SETTINGS, { toolPermissions: { web_search: false }, currentPassword: '' })).status, 403, 'turning OFF also needs the password');
  assert.equal((await new Client().get(SETTINGS)).status, 401, 'anonymous');
  assert.equal(JSON.stringify(await current()), before, 'nothing changed after any of those');
});

test('8. vision model validation: sensible ids are accepted and persisted; anything else is rejected and changes nothing', async () => {
  for (const ok of ['qwen/qwen3.8-27b', 'meta-llama/llama-4-scout-17b-16e-instruct', 'a:b-c_d.e', 'X']) {
    const r = await save({ visionModel: ok });
    assert.equal(r.status, 200, `${ok}: ${r.text}`);
    assert.equal(r.json.visionModel, ok);
    assert.equal(app.db.prepare('SELECT vision_model FROM ai_settings WHERE id = 1').get().vision_model, ok);
  }
  const keep = (await current()).visionModel;
  for (const bad of ['', '   ', 'has space', 'new\nline', 'quote"x', "tick'x", '-leading', '/leading', '.leading', '<script>', 'a'.repeat(101), 123, null, {}, ['x']]) {
    assert.equal((await save({ visionModel: bad })).status, 400, `rejects ${JSON.stringify(bad)}`);
  }
  assert.equal((await current()).visionModel, keep, 'unchanged after every rejection');
  assert.equal((await save({ visionModel: 'a'.repeat(100) })).status, 200, '100 characters is the allowed maximum');
  assert.equal((await save({ visionModel: AI_LIMITS.DEFAULT_VISION_MODEL })).json.visionModel, AI_LIMITS.DEFAULT_VISION_MODEL);
});

test('9. capability toggles and vision-model changes are audited, without leaking the password or any key', async () => {
  const n = () => app.db.prepare("SELECT COUNT(*) AS n FROM audit_logs WHERE action LIKE 'AI_CAPABILITY_%'").get().n;
  const start = n();
  await save({ toolPermissions: { web_search: true } });
  await save({ toolPermissions: { web_search: true } }); // no actual change: must NOT audit again
  await save({ toolPermissions: { web_search: false, vision: true } });
  await save({ toolPermissions: { vision: false } });
  await save({ visionModel: 'audit/model-1' });
  const rows = app.db.prepare("SELECT * FROM audit_logs WHERE action LIKE 'AI_CAPABILITY_%' ORDER BY id").all().slice(start);
  assert.deepEqual(rows.map((r) => r.action), ['AI_CAPABILITY_ENABLED', 'AI_CAPABILITY_DISABLED', 'AI_CAPABILITY_ENABLED', 'AI_CAPABILITY_DISABLED'], 'exactly one entry per real change');
  assert.deepEqual(rows.map((r) => JSON.parse(r.details).capability), ['web_search', 'web_search', 'vision', 'vision']);
  const settingsChange = JSON.stringify(app.db.prepare("SELECT * FROM audit_logs WHERE action = 'AI_SETTINGS_CHANGED' ORDER BY id DESC LIMIT 1").get());
  assert.ok(settingsChange.includes('audit/model-1') && settingsChange.includes('visionModel'));
  const everything = JSON.stringify(app.db.prepare('SELECT * FROM audit_logs').all());
  assert.equal(everything.includes(ADMIN_PW), false, 'the password is never written to the audit log');
  await save({ visionModel: AI_LIMITS.DEFAULT_VISION_MODEL });
});

// =====================================================================================================
// CENTRALISED CONFIGURATION
// =====================================================================================================

test('10. limits are centralised constants with the approved values; no stray copies elsewhere in the source', () => {
  assert.equal(AI_LIMITS.WEB_SEARCH_MAX_QUERY_CHARS, 200);
  assert.equal(AI_LIMITS.VISION_MAX_IMAGES, 3);
  assert.equal(AI_LIMITS.VISION_MAX_IMAGE_BYTES, 2 * 1024 * 1024);
  assert.equal(AI_LIMITS.MAX_UNTRUSTED_STRING_CHARS, 500, 'Step 1 values unchanged');
  assert.equal(AI_LIMITS.MAX_TOOL_RESULT_CHARS, 40000, 'Step 1 values unchanged');
  // Step 4: the images of one request are capped TOGETHER (2.5 MiB, about 3.5 MB as base64) so the whole request stays under
  // the 4 MB base64 request size some Groq documentation states; a single image may still be 2 MB.
  assert.equal(AI_LIMITS.VISION_MAX_TOTAL_IMAGE_BYTES, 2.5 * 1024 * 1024);
  const base64Needed = Math.ceil(AI_LIMITS.VISION_MAX_TOTAL_IMAGE_BYTES / 3) * 4;
  assert.ok(AI_LIMITS.VISION_MAX_BODY_BYTES > base64Needed, 'body limit leaves room for the largest allowed upload as base64');
  assert.ok(AI_LIMITS.VISION_MAX_BODY_BYTES < 4 * 1000 * 1000, 'and stays under 4 MB');
  assert.ok(AI_LIMITS.VISION_MAX_BODY_BYTES < base64Needed + 1024 * 1024, 'but not a generous multiple of that');
  assert.ok(AI_LIMITS.VISION_MAX_BODY_BYTES > 16 * 1024, 'bigger than the global default, which stays untouched');
  assert.ok(Object.isFrozen(AI_LIMITS) && Object.isFrozen(AI_LIMITS.WEB_SEARCH_RATE) && Object.isFrozen(AI_LIMITS.VISION_RATE));
  for (const r of [AI_LIMITS.WEB_SEARCH_RATE, AI_LIMITS.VISION_RATE]) assert.ok(Number.isInteger(r.max) && r.max > 0 && r.windowMs >= 1000);

  const srcDir = path.resolve(__dirname, '..', 'src');
  const holders = listJs(srcDir).filter((f) => fs.readFileSync(f, 'utf8').includes('qwen/qwen3')).map((f) => path.relative(srcDir, f).split(path.sep).join('/'));
  assert.deepEqual(holders.sort(), ['ai/limits.js', 'migrations.js'], 'the default vision model id lives only in limits.js and the migration it must match');
  const fixedWindowBody = listJs(srcDir).filter((f) => /VISION_MAX_BODY_BYTES|WEB_SEARCH_MAX_QUERY_CHARS/.test(fs.readFileSync(f, 'utf8'))).map((f) => path.relative(srcDir, f).split(path.sep).join('/'));
  assert.ok(fixedWindowBody.includes('ai/limits.js') && fixedWindowBody.includes('admin/aiRoutes.js'));
});

test('11. vision is still plumbing only: with BOTH capabilities on, EL gets the 13 original tools plus web_search, and no image input', async () => {
  assert.equal((await save({ enabled: true, apiKey: 'gsk_test_key_0000000000', visionModel: 'plumbing/test-model', toolPermissions: { ...SIX_READ, web_search: true, vision: true } })).status, 200);
  fake.script.push({ content: 'hello' });
  const r = await boss.post('/api/admin/ai/chat', { message: 'What can you do?' });
  assert.equal(r.status, 200, r.text);
  assert.equal(fake.seen.length, 1, 'exactly one model call; no extra search or vision call');
  const body = fake.seen[0].body;
  const offered = (body.tools || []).map((t) => `${t.type}:${t.function?.name}`).sort();
  const expected = Object.keys(buildTools(app.db)).map((n) => `function:${n}`).sort();
  assert.deepEqual(offered, expected, 'the model is offered exactly the registry: the original 13 function tools plus web_search');
  assert.equal(offered.length, 14);
  const wire = JSON.stringify(body);
  for (const forbidden of ['browser_search', 'image_url', 'plumbing/test-model']) assert.equal(wire.includes(forbidden), false, `${forbidden} must not appear in the model request`);
  assert.equal(body.model, 'openai/gpt-oss-120b', 'the main model is unchanged');
  await save({ enabled: false, toolPermissions: { web_search: false, vision: false }, visionModel: AI_LIMITS.DEFAULT_VISION_MODEL, apiKey: null });
});

test('12. the served admin page ships the new controls (valid JavaScript, capabilities default unchecked, read permissions unchanged)', async () => {
  const r = await boss.get('/admin/assets/admin.js');
  assert.equal(r.status, 200);
  assert.doesNotThrow(() => new vm.Script(r.text), 'admin.js parses');
  for (const needle of ['ai-cap-web-search', 'ai-cap-vision', 'ai-vision-model', 'Optional capabilities (off by default)', 'visionModel: visionModel.value.trim()']) assert.ok(r.text.includes(needle), `contains ${needle}`);
  assert.ok(r.text.includes("checked: ai.toolPermissions[key] === true"), 'capabilities are checked only when explicitly true');
  assert.ok(r.text.includes("checked: ai.toolPermissions[key] !== false"), 'the six read permissions keep their default-on rule');
  assert.ok(r.text.includes("capRow('web_search'") && r.text.includes("capRow('vision'"));
  assert.equal((await new Client().get('/admin/assets/admin.js')).status !== 200, true, 'the admin script is still gated behind a session');
});
