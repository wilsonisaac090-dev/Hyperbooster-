'use strict';
const { test, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { loadConfig } = require('../src/config');
const { createApp } = require('../src/app');

const ENV_KEY = 'nsm_ENV_key_1111';
const SAVED_KEY = 'nsm_SAVED_secret_key_9876';
const KORA_KEY = 'sk_test_KORA_secret_key_5432';
const GROQ_KEY = 'gsk_GROQ_secret_key_4321';
const ADMIN_PW = 'a-strong-admin-passphrase';
const LIMITS = {
  apiPerIp: { max: 1e6, windowMs: 6e4 }, loginPerIp: { max: 1e6, windowMs: 6e4 }, loginPerAccount: { max: 1e6, windowMs: 6e4 },
  registerPerIp: { max: 1e6, windowMs: 6e4 }, orderPerUser: { max: 1e6, windowMs: 6e4 },
  adminLoginPerIp: { max: 1e6, windowMs: 6e4 }, adminLoginPerAccount: { max: 1e6, windowMs: 6e4 }, adminOtpPerIp: { max: 1e6, windowMs: 6e4 }, adminApiPerIp: { max: 1e6, windowMs: 6e4 },
  adminAiChatPerAdmin: { max: 1e6, windowMs: 6e4 }, adminAiChatPerIp: { max: 1e6, windowMs: 6e4 }, adminAiSettingsPerIp: { max: 1e6, windowMs: 6e4 },
  depositCreatePerUser: { max: 1e6, windowMs: 6e4 }, depositCreatePerIp: { max: 1e6, windowMs: 6e4 }, koraWebhookPerIp: { max: 1e6, windowMs: 6e4 },
};

let app, base, cfg, calls;

class Client {
  constructor() { this.jar = {}; }
  async call(method, url, { body, headers = {} } = {}) {
    const cookie = Object.entries(this.jar).map(([k, v]) => `${k}=${v}`).join('; ');
    const res = await fetch(base + url, { method, headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(cookie ? { Cookie: cookie } : {}), ...headers }, body: body !== undefined ? JSON.stringify(body) : undefined });
    const text = await res.text(); let json = null; try { json = JSON.parse(text); } catch { /* not json */ }
    for (const c of res.headers.getSetCookie?.() ?? []) { const [pair] = c.split(';'); const i = pair.indexOf('='); const k = pair.slice(0, i); const v = pair.slice(i + 1); if (v === '') delete this.jar[k]; else this.jar[k] = v; }
    return { status: res.status, json, text };
  }
  get(u, o) { return this.call('GET', u, o); }
  post(u, body, o) { return this.call('POST', u, { body, ...o }); }
  patch(u, body, o) { return this.call('PATCH', u, { method: 'PATCH', body, ...o }); }
}


let provider, kora;
function makeFakes() {
  const p = { calls: [], balanceReply: { balance: '12.50', currency: 'USD' }, addReply: null, throwNetwork: false };
  p.fetchImpl = async (url, opts) => {
    const params = new URLSearchParams(opts.body);
    p.calls.push({ action: params.get('action'), key: params.get('key') });
    if (p.throwNetwork) throw new Error('socket hang up');
    if (params.get('action') === 'balance') return { ok: true, status: 200, json: async () => p.balanceReply };
    if (params.get('action') === 'add') return { ok: true, status: 200, json: async () => p.addReply || { order: 'P' + p.calls.length } };
    return { ok: true, status: 200, json: async () => ({ error: 'x' }) };
  };
  const k = { calls: [], reply: { httpStatus: 404, body: { status: false, message: 'Transaction not found' } } };
  k.fetchImpl = async (url, opts) => {
    k.calls.push({ url, auth: opts.headers.Authorization });
    return { ok: k.reply.httpStatus < 400, status: k.reply.httpStatus, json: async () => k.reply.body };
  };
  return { p, k };
}

async function adminLogin() {
  const c = new Client();
  assert.equal((await c.post('/api/admin/login', { email: 'boss@example.com', password: ADMIN_PW })).status, 200);
  const m = /code is (\d{6})/.exec(app.mailer.outbox.at(-1).text);
  const otp = await c.post('/api/admin/verify-otp', { code: m[1] });
  assert.equal(otp.status, 200);
  return { client: c, csrf: otp.json.csrfToken };
}

let admin, ada;
before(async () => {
  const f = makeFakes(); provider = f.p; kora = f.k; calls = [];
  cfg = loadConfig({ NIGERIASMMPANEL_API_KEY: ENV_KEY, KORA_SECRET_KEY: KORA_KEY, AI_ENCRYPTION_KEY: 'ab'.repeat(32) }, { databasePath: ':memory:', logRequests: false, mailTransport: 'memory', limits: LIMITS, staticDir: '/nonexistent' });
  app = createApp(cfg, { providerFetch: provider.fetchImpl, koraFetch: kora.fetchImpl });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  const { hashPassword } = require('../src/security');
  app.db.prepare('INSERT INTO admins (email, name, password_hash) VALUES (?,?,?)').run('boss@example.com', 'Boss', await hashPassword(ADMIN_PW));
  admin = await adminLogin();
  const r = await new Client().post('/api/register', { fullName: 'Ada', email: 'ada@example.com', password: 'a-long-password' });
  ada = new Client(); await ada.post('/api/login', { email: 'ada@example.com', password: 'a-long-password' });
  ada.id = r.json.user.id;
});
after(() => app.close());

const H = () => ({ headers: { 'X-CSRF-Token': admin.csrf } });
const put = (name, body) => admin.client.call('PUT', `/api/admin/integrations/${name}/key`, { body, ...H() });
const runTest = (name) => admin.client.post(`/api/admin/integrations/${name}/test`, {}, H());
const allAudit = () => JSON.stringify(app.db.prepare('SELECT * FROM audit_logs').all());
const SECRETS = [ENV_KEY, SAVED_KEY, KORA_KEY, GROQ_KEY];

test('customers cannot reach any admin integration endpoint', async () => {
  assert.equal((await ada.get('/api/admin/integrations')).status, 401);
  assert.equal((await ada.call('PUT', '/api/admin/integrations/provider/key', { body: { apiKey: 'x'.repeat(20), currentPassword: 'a-long-password' } })).status, 401);
  assert.equal((await ada.post('/api/admin/integrations/provider/test', {})).status, 401);
});

test('the listing shows only state and the last four characters — never a secret', async () => {
  const r = await admin.client.get('/api/admin/integrations', H());
  assert.equal(r.status, 200, r.text);
  const nsm = r.json.integrations.find((i) => i.id === 'provider');
  assert.equal(nsm.keyMasked, '••••••••••••1111');
  assert.equal(nsm.source, 'environment');
  assert.equal(nsm.url, 'https://nigeriasmm.com/api/v2');
  for (const s of SECRETS) assert.equal(r.text.includes(s), false);
  assert.deepEqual(r.json.integrations.map((i) => i.id), ['provider', 'kora', 'groq']);
});

test('changing a key requires the admin password, enforced on the server', async () => {
  const none = await put('provider', { apiKey: SAVED_KEY });
  assert.equal(none.status, 403);
  const wrong = await put('provider', { apiKey: SAVED_KEY, currentPassword: 'not-my-password' });
  assert.equal(wrong.status, 403);
  assert.equal(app.db.prepare('SELECT COUNT(*) n FROM integration_credentials').get().n, 0, 'nothing saved without valid re-authentication');
  assert.equal((await put('nope', { apiKey: SAVED_KEY, currentPassword: ADMIN_PW })).status, 404);
});

test('a saved key is encrypted at rest, masked in every response, and audit-logged without the secret', async () => {
  const r = await put('provider', { apiKey: SAVED_KEY, currentPassword: ADMIN_PW });
  assert.equal(r.status, 200, r.text);
  assert.equal(r.json.integration.keyMasked, '••••••••••••9876');
  assert.equal(r.json.integration.source, 'admin');
  assert.equal(r.text.includes(SAVED_KEY), false);
  const row = app.db.prepare("SELECT * FROM integration_credentials WHERE name='provider'").get();
  assert.equal(row.ciphertext.includes(SAVED_KEY), false, 'no plaintext in the database');
  assert.equal(row.last4, '9876');
  assert.match(row.ciphertext, /^[A-Za-z0-9+/=]+:[A-Za-z0-9+/=]+:[A-Za-z0-9+/=]+$/, 'iv:tag:ciphertext (AES-256-GCM) format');
  const audit = allAudit();
  assert.ok(audit.includes('INTEGRATION_KEY_UPDATED'));
  for (const s of SECRETS) assert.equal(audit.includes(s), false, 'audit log never holds a secret');
});

test('an admin-saved key takes precedence over the environment variable for real provider calls', async () => {
  provider.calls.length = 0;
  const t = await runTest('provider');
  assert.equal(t.status, 200, t.text);
  assert.equal(t.json.ok, true);
  assert.equal(provider.calls[0].action, 'balance', 'Test Connection is read-only: it asks for the balance, places no order');
  assert.equal(provider.calls[0].key, SAVED_KEY);
  assert.equal(t.text.includes(SAVED_KEY), false);
  assert.equal(t.json.integration.status, 'connected');
});

test('Test Connection reports a rejected key and a network failure without leaking anything', async () => {
  provider.balanceReply = { error: 'Invalid API key' };
  const bad = await runTest('provider');
  assert.equal(bad.json.ok, false);
  assert.equal(bad.json.integration.status, 'error');
  assert.equal(bad.text.includes(SAVED_KEY), false);
  provider.balanceReply = { balance: '1', currency: 'USD' };
  provider.throwNetwork = true;
  const net = await runTest('provider');
  assert.equal(net.json.ok, false);
  provider.throwNetwork = false;
});

test('Kora: key saved encrypted; Test Connection proves the key WITHOUT creating any charge', async () => {
  assert.equal((await put('kora', { apiKey: KORA_KEY, currentPassword: ADMIN_PW })).status, 200);
  kora.calls.length = 0;
  kora.reply = { httpStatus: 404, body: { status: false, message: 'Transaction not found' } };
  const ok = await runTest('kora');
  assert.equal(ok.json.ok, true);
  assert.equal(kora.calls.length, 1);
  assert.ok(kora.calls[0].url.includes('/charges/hb-connection-test-does-not-exist'), 'a lookup only — never /charges/initialize');
  assert.equal(kora.calls[0].auth, `Bearer ${KORA_KEY}`);
  kora.reply = { httpStatus: 401, body: { status: false, message: 'Unauthorized' } };
  const bad = await runTest('kora');
  assert.equal(bad.json.ok, false);
  assert.equal(bad.text.includes(KORA_KEY), false);
});

test('Groq / EL Assistant appears in Integrations using its existing encrypted store, masked', async () => {
  const set = await admin.client.call('PATCH', '/api/admin/ai/settings', { body: { apiKey: GROQ_KEY, currentPassword: ADMIN_PW }, ...H() });
  assert.equal(set.status, 200, set.text);
  const r = await admin.client.get('/api/admin/integrations', H());
  const g = r.json.integrations.find((i) => i.id === 'groq');
  assert.equal(g.keyMasked, '••••••••••••4321');
  assert.equal(g.model.length > 0, true);
  assert.equal(r.text.includes(GROQ_KEY), false);
});

test('no secret appears anywhere in the audit log after all credential activity', async () => {
  const audit = allAudit();
  for (const s of SECRETS) assert.equal(audit.includes(s), false);
  assert.ok(audit.includes('INTEGRATION_TESTED'));
});

// ---------- order safety around the provider ----------
async function makeSvc(name, providerServiceId = '4242') {
  const r = await admin.client.post('/api/admin/services', { name, category: 'Followers', platform: 'instagram', serviceType: 'followers', providerServiceId, providerCostKobo: 30000, pricePer1000Kobo: 100000, minQuantity: 100, maxQuantity: 100000, refillAvailable: false, dropRate: 'Low', averageCompletionTime: '1h', description: 'x', isActive: true }, H());
  assert.equal(r.status, 201, r.text);
  return r.json.service.id;
}
const balance = () => app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(ada.id).balance_kobo;
const setBalance = (k) => app.db.prepare('UPDATE users SET balance_kobo = ? WHERE id = ?').run(k, ada.id);

test('the provider is asked exactly once per order, even if forwarding is triggered again (retry-safe)', async () => {
  const svc = await makeSvc('Retry Safe Followers'); setBalance(1000000);
  provider.calls.length = 0;
  const r = await ada.post('/api/orders', { serviceId: svc, quantity: 1000, link: 'https://x.com/retry' });
  assert.equal(r.status, 201, r.text);
  const { forwardOrderToProvider } = require('../src/provider/orders');
  const again = await forwardOrderToProvider({ cfg, db: app.db, providerFetch: provider.fetchImpl }, r.json.order.id);
  const again2 = await forwardOrderToProvider({ cfg, db: app.db, providerFetch: provider.fetchImpl }, r.json.order.id);
  assert.equal(again.alreadyHandled, true); assert.equal(again2.alreadyHandled, true);
  assert.equal(provider.calls.filter((c) => c.action === 'add').length, 1, 'one provider order only');
  const row = app.db.prepare('SELECT * FROM orders WHERE id = ?').get(r.json.order.id);
  assert.ok(row.provider_order_id);
  assert.equal(app.db.prepare("SELECT COUNT(*) n FROM wallet_ledger WHERE reference_type='order' AND reference_id=? AND entry_type='order_charge'").get(row.id).n, 1, 'charged exactly once');
});

test('simultaneous forwarding of one order still reaches the provider once', async () => {
  const svc = await makeSvc('Race Followers'); setBalance(1000000);
  provider.calls.length = 0;
  const r = await ada.post('/api/orders', { serviceId: svc, quantity: 500, link: 'https://x.com/race' });
  app.db.prepare("UPDATE orders SET status='pending', provider_order_id=NULL, provider_status=NULL WHERE id=?").run(r.json.order.id);
  provider.calls.length = 0;
  const { forwardOrderToProvider } = require('../src/provider/orders');
  const ctx = { cfg, db: app.db, providerFetch: provider.fetchImpl };
  await Promise.all([forwardOrderToProvider(ctx, r.json.order.id), forwardOrderToProvider(ctx, r.json.order.id)]);
  assert.equal(provider.calls.filter((c) => c.action === 'add').length, 1);
});

test('an unclear failure (network drop) never refunds or re-sends: the order stays pending, flagged for an admin', async () => {
  const svc = await makeSvc('Uncertain Followers'); setBalance(1000000);
  provider.throwNetwork = true; provider.calls.length = 0;
  const r = await ada.post('/api/orders', { serviceId: svc, quantity: 1000, link: 'https://x.com/net' });
  provider.throwNetwork = false;
  assert.equal(r.status, 201, r.text);
  assert.equal(r.json.order.status, 'pending');
  assert.equal(balance(), 1000000 - 100000, 'still charged; NOT auto-refunded because the provider may have received it');
  assert.equal(app.db.prepare("SELECT COUNT(*) n FROM wallet_ledger WHERE entry_type='order_refund' AND reference_id=?").get(r.json.order.id).n, 0);
  assert.ok(allAudit().includes('PROVIDER_ORDER_UNCERTAIN'));
  const { forwardOrderToProvider } = require('../src/provider/orders');
  provider.calls.length = 0;
  await forwardOrderToProvider({ cfg, db: app.db, providerFetch: provider.fetchImpl }, r.json.order.id);
  assert.equal(provider.calls.length, 0, 'no automatic second attempt that could duplicate the order');
});

test('customer responses never contain any credential, provider service id or provider cost', async () => {
  const svc = await makeSvc('Leak Check Followers', '31337'); setBalance(1000000);
  const a = await ada.get('/api/services');
  const b = await ada.post('/api/orders', { serviceId: svc, quantity: 1000, link: 'https://x.com/leak' });
  const c = await ada.get('/api/orders');
  const d = await ada.get('/api/wallet');
  for (const res of [a, b, c, d]) {
    const t = res.text.toLowerCase();
    for (const s of SECRETS) assert.equal(res.text.includes(s), false);
    assert.equal(t.includes('31337'), false);
    assert.equal(t.includes('providerservice'), false);
    assert.equal(t.includes('providercost'), false);
    assert.equal(t.includes('provider_order_id'), false);
  }
});
