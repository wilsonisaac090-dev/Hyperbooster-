'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { loadConfig } = require('../src/config');
const { createApp } = require('../src/app');
const { seedServices } = require('../src/seed');
const { applyLedger } = require('../src/wallet');
const { transaction } = require('../src/db');
const { sha256 } = require('../src/security');
const { calcCharge } = require('../src/pricing');

let app;
let base;
let cfg;
let tmp;

async function call(method, url, { body, raw, cookie, headers = {} } = {}) {
  const hasBody = body !== undefined || raw !== undefined;
  const res = await fetch(base + url, {
    method,
    redirect: 'manual',
    headers: {
      ...(hasBody ? { 'Content-Type': 'application/json' } : {}),
      ...(cookie ? { Cookie: cookie } : {}),
      ...headers,
    },
    body: raw ?? (body !== undefined ? JSON.stringify(body) : undefined),
  });
  const text = await res.text();
  let json = null;
  try {
    json = JSON.parse(text);
  } catch {
    /* not json */
  }
  const setCookie = (res.headers.getSetCookie?.() ?? []).find((c) => c.startsWith(cfg.cookieName + '='));
  return { status: res.status, json, text, headers: res.headers, setCookie, cookie: setCookie ? setCookie.split(';')[0] : null };
}

const PW = 'correct horse battery';
async function signUp(email, name = 'Test User') {
  const r = await call('POST', '/api/register', { body: { fullName: name, email, password: PW } });
  assert.equal(r.status, 201, JSON.stringify(r.json));
  return r;
}
const userId = (email) => app.db.prepare('SELECT id FROM users WHERE email = ?').get(email).id;
const credit = (email, kobo) =>
  transaction(app.db, () => applyLedger(app.db, { userId: userId(email), deltaKobo: kobo, type: 'adjustment', description: 'test' }));

before(async () => {
  tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'hb-test-'));
  fs.mkdirSync(path.join(tmp, 'styles'));
  fs.mkdirSync(path.join(tmp, 'server'));
  fs.writeFileSync(path.join(tmp, 'index.html'), '<!doctype html><title>home</title>');
  fs.writeFileSync(path.join(tmp, 'login.html'), '<!doctype html><title>login</title>');
  fs.writeFileSync(path.join(tmp, 'styles', 'a.css'), 'body{}');
  fs.writeFileSync(path.join(tmp, 'secret.txt'), 'top secret');
  fs.writeFileSync(path.join(tmp, '.env'), 'KEY=1');
  fs.writeFileSync(path.join(tmp, 'server', 'leak.js'), 'module.exports = 1');

  cfg = loadConfig({}, {
    databasePath: ':memory:',
    staticDir: tmp,
    serverDir: path.join(tmp, 'server'),
    logRequests: false,
    limits: {
      apiPerIp: { max: 100000, windowMs: 60000 },
      loginPerIp: { max: 100000, windowMs: 60000 },
      loginPerAccount: { max: 5, windowMs: 60000 },
      registerPerIp: { max: 100000, windowMs: 60000 },
      orderPerUser: { max: 100000, windowMs: 60000 },
    },
  });
  app = createApp(cfg);
  await new Promise((resolve) => app.server.listen(0, '127.0.0.1', resolve));
  base = `http://127.0.0.1:${app.server.address().port}`;
});

after(async () => {
  await app.close();
  fs.rmSync(tmp, { recursive: true, force: true });
});

test('health endpoint and security headers', async () => {
  const r = await call('GET', '/api/health');
  assert.equal(r.status, 200);
  assert.deepEqual(r.json, { ok: true });
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(r.headers.get('x-frame-options'), 'DENY');
  assert.match(r.headers.get('content-security-policy'), /frame-ancestors 'none'/);
  assert.equal(r.headers.get('cache-control'), 'no-store');
});

test('register validates input', async () => {
  const bad = async (body, field) => {
    const r = await call('POST', '/api/register', { body });
    assert.equal(r.status, 400, JSON.stringify(body));
    assert.equal(r.json.field, field);
  };
  await bad({ fullName: '', email: 'a@b.co', password: PW }, 'fullName');
  await bad({ fullName: 'A', email: 'nope', password: PW }, 'email');
  await bad({ fullName: 'A', email: 'a@b.co', password: 'short' }, 'password');
  await bad({ fullName: 'A', email: 'a@b.co', password: 'x'.repeat(129) }, 'password');
  await bad({ fullName: 'A', email: { $ne: 1 }, password: PW }, 'email');
});

test('register creates account, hashes password, logs in with an HttpOnly cookie', async () => {
  const r = await signUp('Ada@Example.com', 'Ada Lovelace');
  assert.equal(r.json.user.email, 'ada@example.com');
  assert.equal(r.json.user.fullName, 'Ada Lovelace');
  assert.equal(r.json.user.role, 'user');
  assert.equal(r.json.wallet.balanceKobo, 0);
  assert.match(r.setCookie, /HttpOnly/);
  assert.match(r.setCookie, /SameSite=Lax/);
  assert.equal(JSON.stringify(r.json).includes('password'), false);

  const row = app.db.prepare('SELECT password_hash FROM users WHERE email = ?').get('ada@example.com');
  assert.match(row.password_hash, /^scrypt\$/);
  assert.equal(row.password_hash.includes(PW), false);

  // raw session token is never stored, only its hash
  const token = r.cookie.split('=')[1];
  const sess = app.db.prepare('SELECT token_hash FROM sessions').all();
  assert.ok(sess.some((s) => s.token_hash === sha256(token)));
  assert.ok(sess.every((s) => s.token_hash !== token));

  const me = await call('GET', '/api/me', { cookie: r.cookie });
  assert.equal(me.status, 200);
  assert.equal(me.json.user.fullName, 'Ada Lovelace');
  assert.equal(me.json.wallet.balanceKobo, 0);
});

test('duplicate email (any case) is rejected', async () => {
  const r = await call('POST', '/api/register', { body: { fullName: 'Ada 2', email: 'ADA@example.com', password: PW } });
  assert.equal(r.status, 409);
  assert.equal(r.json.field, 'email');
});

test('login: generic failure message, success, logout invalidates session', async () => {
  const wrongPw = await call('POST', '/api/login', { body: { email: 'ada@example.com', password: 'wrong-password' } });
  const noUser = await call('POST', '/api/login', { body: { email: 'ghost@example.com', password: 'wrong-password' } });
  assert.equal(wrongPw.status, 401);
  assert.equal(noUser.status, 401);
  assert.equal(wrongPw.json.error, noUser.json.error);

  const missing = await call('POST', '/api/login', { body: { email: 'ada@example.com' } });
  assert.equal(missing.status, 400);

  const ok = await call('POST', '/api/login', { body: { email: 'ADA@example.com', password: PW } });
  assert.equal(ok.status, 200);
  assert.ok(ok.cookie);
  assert.equal((await call('GET', '/api/me', { cookie: ok.cookie })).status, 200);

  const out = await call('POST', '/api/logout', { cookie: ok.cookie, body: {} });
  assert.equal(out.status, 200);
  assert.match(out.setCookie, /Max-Age=0/);
  assert.equal((await call('GET', '/api/me', { cookie: ok.cookie })).status, 401);
});

test('protected endpoints need a session', async () => {
  assert.equal((await call('GET', '/api/me')).status, 401);
  assert.equal((await call('GET', '/api/wallet')).status, 401);
  assert.equal((await call('GET', '/api/orders')).status, 401);
  assert.equal((await call('POST', '/api/orders', { body: {} })).status, 401);
  assert.equal((await call('GET', '/api/me', { cookie: `${cfg.cookieName}=garbage` })).status, 401);
});

test('services: multiple per platform, active only, provider id hidden', async () => {
  assert.deepEqual((await call('GET', '/api/services')).json.services, []);
  assert.ok(seedServices(app.db) >= 16);
  assert.equal(seedServices(app.db), 0); // idempotent

  app.db.prepare("UPDATE services SET provider_service_id = 'SECRET-123' WHERE name = 'Instagram Followers'").run();
  app.db.prepare("UPDATE services SET is_active = 0 WHERE name = 'Instagram Views'").run();

  const all = await call('GET', '/api/services');
  assert.equal(all.status, 200);
  assert.equal(all.text.includes('SECRET-123'), false);
  assert.equal(all.text.includes('providerServiceId'), false);
  assert.equal(all.json.services.some((s) => s.name === 'Instagram Views'), false);

  const ig = await call('GET', '/api/services?platform=instagram');
  assert.deepEqual(ig.json.services.map((s) => s.serviceType).sort(), ['followers', 'likes']);
  const s = ig.json.services.find((x) => x.serviceType === 'followers');
  assert.equal(s.pricePer1000Kobo, 100000);
  assert.equal(s.minQuantity, 100);
  assert.equal(s.maxQuantity, 100000);
  assert.equal(s.refillAvailable, false);
  assert.equal(s.averageCompletionTime, '4 hours');
  assert.deepEqual(s.notes, ['Make sure the account is public.', 'Do not change the username while the order is running.']);

  assert.equal((await call('GET', '/api/services?platform=../etc')).status, 400);
  assert.deepEqual((await call('GET', '/api/services?platform=nothing')).json.services, []);
});

test('price maths is exact integer maths (rounds up to the next kobo)', () => {
  assert.equal(calcCharge(100000, 1000), 100000);
  assert.equal(calcCharge(100000, 250), 25000);
  assert.equal(calcCharge(333, 1), 1);
  assert.equal(calcCharge(1, 1), 1);
  assert.equal(calcCharge(0, 5000), 0);
  assert.equal(calcCharge(10000000000, 10000000), 100000000000000);
});

test('quote validates and calculates on the server', async () => {
  const svc = (await call('GET', '/api/services?platform=instagram')).json.services.find((s) => s.serviceType === 'followers');
  const q = await call('POST', '/api/orders/quote', { body: { serviceId: svc.id, quantity: 250 } });
  assert.equal(q.status, 200);
  assert.equal(q.json.quote.chargeKobo, 25000);
  assert.equal(q.json.canAfford, undefined);

  assert.equal((await call('POST', '/api/orders/quote', { body: { serviceId: svc.id, quantity: 99 } })).status, 400);
  assert.equal((await call('POST', '/api/orders/quote', { body: { serviceId: svc.id, quantity: 100001 } })).status, 400);
  assert.equal((await call('POST', '/api/orders/quote', { body: { serviceId: svc.id, quantity: 1.5 } })).status, 400);
  assert.equal((await call('POST', '/api/orders/quote', { body: { serviceId: svc.id, quantity: -5 } })).status, 400);
  assert.equal((await call('POST', '/api/orders/quote', { body: { serviceId: 999999, quantity: 500 } })).status, 404);
  const inactive = app.db.prepare("SELECT id FROM services WHERE name = 'Instagram Views'").get().id;
  assert.equal((await call('POST', '/api/orders/quote', { body: { serviceId: inactive, quantity: 500 } })).status, 404);
});

test('orders: insufficient balance rolls back completely', async () => {
  const u = await signUp('poor@example.com');
  const svc = (await call('GET', '/api/services?platform=tiktok')).json.services[0];
  const r = await call('POST', '/api/orders', { cookie: u.cookie, body: { serviceId: svc.id, quantity: 1000, link: '@poor' } });
  assert.equal(r.status, 402);
  assert.equal(app.db.prepare('SELECT COUNT(*) AS n FROM orders WHERE user_id = ?').get(userId('poor@example.com')).n, 0);
  assert.equal(app.db.prepare('SELECT COUNT(*) AS n FROM wallet_ledger WHERE user_id = ?').get(userId('poor@example.com')).n, 0);
});

test('orders: successful order charges wallet once and writes ledger', async () => {
  const u = await signUp('buyer@example.com', 'Buyer One');
  credit('buyer@example.com', 500000); // NGN 5,000
  const svc = (await call('GET', '/api/services?platform=instagram')).json.services.find((s) => s.serviceType === 'likes');

  const bad = async (body) => (await call('POST', '/api/orders', { cookie: u.cookie, body })).status;
  assert.equal(await bad({ serviceId: svc.id, quantity: 100, link: 'javascript:alert(1)' }), 400);
  assert.equal(await bad({ serviceId: svc.id, quantity: 100, link: 'has space' }), 400);
  assert.equal(await bad({ serviceId: svc.id, quantity: 10, link: '@buyer' }), 400);
  assert.equal(await bad({ serviceId: svc.id, quantity: 100 }), 400);

  const r = await call('POST', '/api/orders', {
    cookie: u.cookie,
    body: { serviceId: svc.id, quantity: 1500, link: 'https://instagram.com/buyer' },
  });
  assert.equal(r.status, 201, JSON.stringify(r.json));
  assert.equal(r.json.order.chargeKobo, 150000);
  assert.equal(r.json.order.status, 'pending');
  assert.equal(r.json.order.serviceName, 'Instagram Likes');
  assert.equal(r.json.wallet.balanceKobo, 350000);
  assert.equal(r.text.includes('provider'), false);

  const me = await call('GET', '/api/me', { cookie: u.cookie });
  assert.equal(me.json.wallet.balanceKobo, 350000);

  const wallet = await call('GET', '/api/wallet', { cookie: u.cookie });
  assert.equal(wallet.json.balanceKobo, 350000);
  assert.equal(wallet.json.entries[0].type, 'order_charge');
  assert.equal(wallet.json.entries[0].amountKobo, -150000);
  assert.equal(wallet.json.entries[0].balanceAfterKobo, 350000);
  assert.equal(wallet.json.entries[1].type, 'adjustment');

  const list = await call('GET', '/api/orders', { cookie: u.cookie });
  assert.equal(list.json.orders.length, 1);

  // price snapshot survives later price changes
  app.db.prepare("UPDATE services SET price_per_1000_kobo = 999999 WHERE id = ?").run(svc.id);
  const one = await call('GET', `/api/orders/${r.json.order.id}`, { cookie: u.cookie });
  assert.equal(one.json.order.chargeKobo, 150000);
  app.db.prepare("UPDATE services SET price_per_1000_kobo = 100000 WHERE id = ?").run(svc.id);

  // another user can never read this order
  const other = await signUp('other@example.com');
  assert.equal((await call('GET', `/api/orders/${r.json.order.id}`, { cookie: other.cookie })).status, 404);
  assert.deepEqual((await call('GET', '/api/orders', { cookie: other.cookie })).json.orders, []);
});

test('orders: two simultaneous orders cannot overspend the wallet', async () => {
  const u = await signUp('racer@example.com');
  credit('racer@example.com', 150000); // enough for exactly one NGN 1,000 order
  const svc = (await call('GET', '/api/services?platform=tiktok')).json.services.find((s) => s.serviceType === 'followers');
  const place = () =>
    call('POST', '/api/orders', { cookie: u.cookie, body: { serviceId: svc.id, quantity: 1000, link: '@racer' } });
  const results = await Promise.all([place(), place(), place()]);
  const statuses = results.map((r) => r.status).sort();
  assert.deepEqual(statuses, [201, 402, 402]);
  const bal = app.db.prepare('SELECT balance_kobo FROM users WHERE email = ?').get('racer@example.com').balance_kobo;
  assert.equal(bal, 50000);
});

test('ledger idempotency: applying the same key twice credits once', async () => {
  await signUp('idem2@example.com');
  const id = userId('idem2@example.com');
  const run = () =>
    transaction(app.db, () =>
      applyLedger(app.db, { userId: id, deltaKobo: 10000, type: 'deposit', idempotencyKey: 'deposit:test-1' })
    );
  assert.equal(run().duplicate, false);
  assert.equal(run().duplicate, true);
  assert.equal(app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(id).balance_kobo, 10000);
});

test('database constraints block negative balances and bad ledger signs', () => {
  const id = userId('idem2@example.com');
  assert.throws(() => app.db.prepare('UPDATE users SET balance_kobo = -1 WHERE id = ?').run(id));
  assert.throws(() =>
    app.db
      .prepare("INSERT INTO wallet_ledger (user_id, entry_type, amount_kobo, balance_after_kobo) VALUES (?, 'order_charge', 500, 500)")
      .run(id)
  );
});

test('CSRF: cross-origin POST is blocked, same-origin allowed', async () => {
  const evil = await call('POST', '/api/login', {
    headers: { Origin: 'https://evil.example' },
    body: { email: 'ada@example.com', password: PW },
  });
  assert.equal(evil.status, 403);
  const same = await call('POST', '/api/login', {
    headers: { Origin: base },
    body: { email: 'ada@example.com', password: PW },
  });
  assert.equal(same.status, 200);
});

test('request body handling: content type, malformed JSON, size limit', async () => {
  const noType = await fetch(base + '/api/login', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: 'x' });
  assert.equal(noType.status, 415);
  assert.equal((await call('POST', '/api/login', { raw: '{oops' })).status, 400);
  assert.equal((await call('POST', '/api/login', { raw: '[1,2]' })).status, 400);
  const big = await call('POST', '/api/login', { raw: JSON.stringify({ email: 'a@b.co', password: 'x'.repeat(20000) }) });
  assert.equal(big.status, 413);
});

test('unknown routes and wrong methods return JSON errors', async () => {
  assert.equal((await call('GET', '/api/nope')).status, 404);
  assert.equal((await call('GET', '/api/login')).status, 405);
  assert.equal((await call('DELETE', '/api/me')).status, 405);
});

test('suspended users lose access immediately', async () => {
  const u = await signUp('banned@example.com');
  assert.equal((await call('GET', '/api/me', { cookie: u.cookie })).status, 200);
  app.db.prepare("UPDATE users SET status = 'suspended' WHERE email = 'banned@example.com'").run();
  assert.equal((await call('GET', '/api/me', { cookie: u.cookie })).status, 401);
  const login = await call('POST', '/api/login', { body: { email: 'banned@example.com', password: PW } });
  assert.equal(login.status, 403);
});

test('expired sessions are rejected', async () => {
  const u = await signUp('expired@example.com');
  app.db.prepare('UPDATE sessions SET expires_at = ? WHERE user_id = ?').run(Date.now() - 1000, userId('expired@example.com'));
  assert.equal((await call('GET', '/api/me', { cookie: u.cookie })).status, 401);
});

test('static files: pages served, sensitive paths are not', async () => {
  const home = await call('GET', '/');
  assert.equal(home.status, 200);
  assert.match(home.text, /home/);
  assert.match(home.headers.get('content-type'), /text\/html/);
  assert.equal((await call('GET', '/login.html')).status, 200);
  assert.equal((await call('GET', '/styles/a.css')).status, 200);

  for (const p of ['/secret.txt', '/.env', '/server/leak.js', '/%2e%2e/etc/passwd', '/..%2f..%2fetc%2fpasswd', '/styles/%2e%2e/%2e%2e/x.html', '/index.html%00.css', '/nope.html', '/styles/']) {
    const r = await fetch(base + p);
    assert.equal(r.status, 404, p);
  }
});

test('login brute force is rate limited per account', async () => {
  await signUp('target@example.com');
  const attempt = () => call('POST', '/api/login', { body: { email: 'target@example.com', password: 'wrong-password!' } });
  for (let i = 0; i < 5; i++) assert.equal((await attempt()).status, 401);
  const blocked = await attempt();
  assert.equal(blocked.status, 429);
  assert.ok(Number(blocked.headers.get('retry-after')) > 0);
  // even the correct password is refused while blocked
  const correct = await call('POST', '/api/login', { body: { email: 'target@example.com', password: PW } });
  assert.equal(correct.status, 429);
});
