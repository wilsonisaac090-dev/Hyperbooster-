'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { loadConfig } = require('../src/config');
const { createApp } = require('../src/app');
const { createMailer } = require('../src/mailer');
const { hashPassword } = require('../src/security');
const { seedServices } = require('../src/seed');
const { applyLedger } = require('../src/wallet');
const { transaction } = require('../src/db');

const CANARIES = ['KORA-SECRET-CANARY', 'PROVIDER-KEY-CANARY', 'RESEND-CANARY'];
const ENV = { KORA_SECRET_KEY: CANARIES[0], PROVIDER_API_URL_UNUSED: 'https://provider.example/api', PROVIDER_API_KEY_UNUSED: CANARIES[1], RESEND_API_KEY: CANARIES[2], MAIL_FROM: 'x@y.z' };
const LIMITS = {
  apiPerIp: { max: 1e6, windowMs: 6e4 }, loginPerIp: { max: 1e6, windowMs: 6e4 }, loginPerAccount: { max: 1e6, windowMs: 6e4 },
  registerPerIp: { max: 1e6, windowMs: 6e4 }, orderPerUser: { max: 1e6, windowMs: 6e4 },
  adminLoginPerIp: { max: 1e6, windowMs: 6e4 }, adminLoginPerAccount: { max: 5, windowMs: 6e4 }, adminOtpPerIp: { max: 1e6, windowMs: 6e4 }, adminApiPerIp: { max: 1e6, windowMs: 6e4 },
};
const ADMIN_PW = 'correct horse battery staple';
let app, base, cfg;

class Client {
  constructor() { this.jar = {}; this.csrf = null; }
  async call(method, url, { body, raw, headers = {}, csrf = true } = {}) {
    const has = body !== undefined || raw !== undefined;
    const cookie = Object.entries(this.jar).map(([k, v]) => `${k}=${v}`).join('; ');
    const res = await fetch(base + url, {
      method, redirect: 'manual',
      headers: { ...(has ? { 'Content-Type': 'application/json' } : {}), ...(cookie ? { Cookie: cookie } : {}), ...(csrf && this.csrf && method !== 'GET' ? { 'X-CSRF-Token': this.csrf } : {}), ...headers },
      body: raw ?? (body !== undefined ? JSON.stringify(body) : undefined),
    });
    const text = await res.text();
    let json = null; try { json = JSON.parse(text); } catch { /* not json */ }
    const setCookies = res.headers.getSetCookie?.() ?? [];
    for (const c of setCookies) { const [pair] = c.split(';'); const i = pair.indexOf('='); const k = pair.slice(0, i); const v = pair.slice(i + 1); if (v === '') delete this.jar[k]; else this.jar[k] = v; }
    return { status: res.status, json, text, headers: res.headers, setCookies };
  }
  get(u, o) { return this.call('GET', u, o); }
  post(u, body, o) { return this.call('POST', u, { body, ...o }); }
  put(u, body, o) { return this.call('PUT', u, { body, ...o }); }
  patch(u, body, o) { return this.call('PATCH', u, { body, ...o }); }
  del(u, body, o) { return this.call('DELETE', u, { body, ...o }); }
}

const lastCode = () => { const m = app.mailer.outbox.at(-1); return m && /code is (\d{6})/.exec(m.text)?.[1]; };
async function signInAdmin(email = 'boss@example.com', password = ADMIN_PW) {
  const c = new Client();
  const step1 = await c.post('/api/admin/login', { email, password });
  assert.equal(step1.status, 200, step1.text);
  const step2 = await c.post('/api/admin/verify-otp', { code: lastCode() });
  assert.equal(step2.status, 200, step2.text);
  c.csrf = step2.json.csrfToken;
  return c;
}
async function newCustomer(email, funds = 0) {
  const c = new Client();
  const r = await c.post('/api/register', { fullName: 'Cust ' + email.split('@')[0], email, password: 'a-long-password' });
  assert.equal(r.status, 201, r.text);
  if (funds) transaction(app.db, () => applyLedger(app.db, { userId: r.json.user.id, deltaKobo: funds, type: 'adjustment', description: 'test funds' }));
  return { client: c, id: r.json.user.id };
}
const audits = (action) => app.db.prepare('SELECT * FROM audit_logs WHERE action = ? ORDER BY id').all(action);
const svcBody = (o = {}) => ({ name: 'Facebook Followers Standard', category: 'Followers', platform: 'facebook', serviceType: 'followers', providerServiceId: '12345', providerCostKobo: 50000, pricePer1000Kobo: 100000, minQuantity: 100, maxQuantity: 100000, refillAvailable: true, dropRate: 'Low', averageCompletionTime: '0-2 hours', description: 'Fast followers', notes: 'Public account only\nDo not change username', tags: ['Fast', 'Refill'], isActive: true, ...o });

let boss, cust;
before(async () => {
  cfg = loadConfig(ENV, { databasePath: ':memory:', logRequests: false, mailTransport: 'memory', limits: LIMITS, staticDir: '/nonexistent' });
  app = createApp(cfg);
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  app.db.prepare('INSERT INTO admins (email, name, password_hash) VALUES (?,?,?)').run('boss@example.com', 'The Boss', await hashPassword(ADMIN_PW));
  boss = await signInAdmin();
  cust = await newCustomer('cust1@example.com', 5000000);
});
after(() => app.close());

test('admin pages and API are closed to everyone who is not a signed-in admin', async () => {
  const anon = new Client();
  for (const u of ['/api/admin/overview', '/api/admin/services', '/api/admin/orders', '/api/admin/customers', '/api/admin/settings', '/api/admin/audit', '/api/admin/session']) {
    assert.equal((await anon.get(u)).status, 401, u);
  }
  assert.equal((await anon.post('/api/admin/services', svcBody())).status, 401);
  const custRes = await cust.client.get('/api/admin/overview'); // a signed-in CUSTOMER
  assert.equal(custRes.status, 401);
  const page = await anon.get('/admin');
  assert.equal(page.status, 302);
  assert.equal(page.headers.get('location'), '/admin/login');
  assert.equal((await cust.client.get('/admin')).status, 302);
  assert.equal((await anon.get('/admin/assets/admin.js')).status, 401);
  assert.equal((await anon.get('/admin/login')).status, 200);
  assert.equal((await anon.get('/admin/assets/login.js')).status, 200);
  assert.equal((await anon.get('/admin/nothing')).status, 404);
  const ok = await boss.get('/admin');
  assert.equal(ok.status, 200);
  assert.equal(ok.headers.get('cache-control'), 'no-store');
  assert.equal((await boss.get('/admin/login')).status, 302); // already signed in
});

test('admin sign-in: password first, then an emailed code; no session until the code is right', async () => {
  const c = new Client();
  const bad = await c.post('/api/admin/login', { email: 'boss@example.com', password: 'wrong-password-here' });
  const ghost = await c.post('/api/admin/login', { email: 'ghost@example.com', password: 'wrong-password-here' });
  assert.equal(bad.status, 401); assert.equal(ghost.status, 401);
  assert.equal(bad.json.error, ghost.json.error);
  assert.equal((await c.post('/api/admin/login', { email: 'boss@example.com' })).status, 400);

  // a normal CUSTOMER account cannot sign in as admin, even with the right customer password
  assert.equal((await c.post('/api/admin/login', { email: 'cust1@example.com', password: 'a-long-password' })).status, 401);

  const before = app.mailer.outbox.length;
  const s1 = await c.post('/api/admin/login', { email: 'BOSS@example.com', password: ADMIN_PW });
  assert.equal(s1.status, 200);
  assert.equal(s1.json.step, 'otp');
  assert.match(s1.json.maskedEmail, /^b\*+@example\.com$/);
  assert.equal(app.mailer.outbox.length, before + 1);
  assert.equal(app.mailer.outbox.at(-1).to, 'boss@example.com');
  assert.equal(s1.text.includes(lastCode()), false, 'code must never be in the HTTP response');
  assert.equal(c.jar[cfg.adminCookieName], undefined, 'no session yet');
  assert.equal((await c.get('/api/admin/session')).status, 401);

  assert.equal((await c.post('/api/admin/verify-otp', { code: 'abc' })).status, 400);
  const wrong = lastCode() === '000000' ? '111111' : '000000';
  assert.equal((await c.post('/api/admin/verify-otp', { code: wrong })).status, 401);
  assert.equal((await c.get('/api/admin/session')).status, 401);

  const s2 = await c.post('/api/admin/verify-otp', { code: lastCode() });
  assert.equal(s2.status, 200);
  const sessionCookie = s2.setCookies.find((x) => x.startsWith(cfg.adminCookieName + '='));
  assert.match(sessionCookie, /HttpOnly/); assert.match(sessionCookie, /SameSite=Strict/);
  assert.equal(s2.text.includes('password'), false);
  c.csrf = s2.json.csrfToken;
  assert.equal((await c.get('/api/admin/session')).json.admin.email, 'boss@example.com');
  assert.equal((await c.post('/api/admin/verify-otp', { code: lastCode() })).status, 401, 'a code works only once');

  const tokenStored = app.db.prepare('SELECT token_hash FROM admin_sessions').all().every((r) => r.token_hash !== c.jar[cfg.adminCookieName]);
  assert.ok(tokenStored, 'raw session token is never stored');
  assert.ok(audits('admin.login').length >= 1);
  assert.ok(audits('admin.login_failed').length >= 1);

  assert.equal((await c.post('/api/admin/logout', {}, { csrf: false })).status, 403, 'logout needs the security token');
  assert.equal((await c.post('/api/admin/logout', {})).status, 200);
  assert.equal((await c.get('/api/admin/session')).status, 401);
  assert.ok(audits('admin.logout').length >= 1);
});

test('wrong codes lock the challenge; expired codes and resend rules', async () => {
  let c = new Client();
  await c.post('/api/admin/login', { email: 'boss@example.com', password: ADMIN_PW });
  const good = lastCode(); const wrong = good === '123456' ? '654321' : '123456';
  for (let i = 0; i < 4; i++) assert.equal((await c.post('/api/admin/verify-otp', { code: wrong })).status, 401);
  assert.equal((await c.post('/api/admin/verify-otp', { code: wrong })).status, 401);
  assert.equal((await c.post('/api/admin/verify-otp', { code: good })).status, 401, 'after 5 wrong tries even the right code is refused');

  c = new Client();
  await c.post('/api/admin/login', { email: 'boss@example.com', password: ADMIN_PW });
  app.db.prepare('UPDATE admin_login_challenges SET expires_at = ?').run(Date.now() - 1000);
  const exp = await c.post('/api/admin/verify-otp', { code: lastCode() });
  assert.equal(exp.status, 401); assert.match(exp.json.error, /expired/);

  c = new Client();
  await c.post('/api/admin/login', { email: 'boss@example.com', password: ADMIN_PW });
  const oldCode = lastCode();
  assert.equal((await c.post('/api/admin/resend-otp', {})).status, 429, 'too soon');
  app.db.prepare('UPDATE admin_login_challenges SET last_sent_at = ?').run(Date.now() - 60000);
  assert.equal((await c.post('/api/admin/resend-otp', {})).status, 200);
  const newC = lastCode();
  if (newC !== oldCode) assert.equal((await c.post('/api/admin/verify-otp', { code: oldCode })).status, 401, 'old code dies when a new one is sent');
  assert.equal((await c.post('/api/admin/verify-otp', { code: newC })).status, 200);
  assert.equal((await new Client().post('/api/admin/resend-otp', {})).status, 401);
});

test('admin password guessing is rate limited per account', async () => {
  const c = new Client();
  for (let i = 0; i < 5; i++) assert.equal((await c.post('/api/admin/login', { email: 'lock@example.com', password: 'nope-nope-nope' })).status, 401);
  const r = await c.post('/api/admin/login', { email: 'lock@example.com', password: 'nope-nope-nope' });
  assert.equal(r.status, 429); assert.ok(Number(r.headers.get('retry-after')) > 0);
});

test('sign-in fails closed when email cannot be sent', async () => {
  const noMail = createApp({ ...cfg, mailTransport: 'none' });
  await new Promise((r) => noMail.server.listen(0, '127.0.0.1', r));
  noMail.db.prepare('INSERT INTO admins (email, password_hash) VALUES (?,?)').run('a@b.co', await hashPassword(ADMIN_PW));
  const res = await fetch(`http://127.0.0.1:${noMail.server.address().port}/api/admin/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'a@b.co', password: ADMIN_PW }) });
  assert.equal(res.status, 503);
  await noMail.close();

  const broken = createApp(cfg, { mailer: { send: async () => { throw new Error('smtp down'); }, outbox: [] } });
  await new Promise((r) => broken.server.listen(0, '127.0.0.1', r));
  broken.db.prepare('INSERT INTO admins (email, password_hash) VALUES (?,?)').run('a@b.co', await hashPassword(ADMIN_PW));
  const res2 = await fetch(`http://127.0.0.1:${broken.server.address().port}/api/admin/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'a@b.co', password: ADMIN_PW }) });
  assert.equal(res2.status, 503);
  assert.equal(broken.db.prepare('SELECT COUNT(*) AS n FROM admin_login_challenges').get().n, 0);
  await broken.close();
});

test('the Resend mail transport sends the code through the HTTPS API with the key server-side', async () => {
  const seen = [];
  const mailer = createMailer({ mailTransport: 'resend', resendApiKey: 'KEY123', mailFrom: 'Admin <a@b.co>' }, async (url, opts) => { seen.push({ url, opts }); return { ok: true, status: 200 }; });
  await mailer.send({ to: 'boss@example.com', subject: 'S', text: 'code is 123456' });
  assert.equal(seen[0].url, 'https://api.resend.com/emails');
  assert.equal(seen[0].opts.headers.Authorization, 'Bearer KEY123');
  assert.deepEqual(JSON.parse(seen[0].opts.body).to, ['boss@example.com']);
  const failing = createMailer({ mailTransport: 'resend', resendApiKey: 'K', mailFrom: 'a' }, async () => ({ ok: false, status: 401 }));
  await assert.rejects(() => failing.send({ to: 'a', subject: 's', text: 't' }));
});

test('changes need the security (CSRF) token and a same-origin request', async () => {
  const body = svcBody({ name: 'CSRF probe' });
  assert.equal((await boss.post('/api/admin/services', body, { csrf: false })).status, 403);
  assert.equal((await boss.post('/api/admin/services', body, { csrf: false, headers: { 'X-CSRF-Token': 'wrong' } })).status, 403);
  assert.equal((await boss.post('/api/admin/services', body, { headers: { Origin: 'https://evil.example' } })).status, 403);
  assert.equal(app.db.prepare("SELECT COUNT(*) AS n FROM services WHERE name = 'CSRF probe'").get().n, 0);
});

test('services: create with tiers and tags, validation, duplicates', async () => {
  const create = await boss.post('/api/admin/services', svcBody());
  assert.equal(create.status, 201, create.text);
  const s = create.json.service;
  assert.equal(s.marginKobo, 50000); assert.deepEqual(s.tags, ['Fast', 'Refill']); assert.equal(s.providerServiceId, '12345');
  assert.equal(s.refillAvailable, true); assert.equal(s.isActive, true);

  // same platform + type, different tiers, each with its own provider id / cost / price / limits
  const tiers = [['Facebook Followers Low Drop', '22222', 70000, 150000, 200, 50000, ['Low Drop']], ['Facebook Followers Premium', '33333', 120000, 250000, 500, 20000, ['Premium', 'High Retention']]];
  for (const [name, pid, cost, price, min, max, tags] of tiers) {
    const r = await boss.post('/api/admin/services', svcBody({ name, providerServiceId: pid, providerCostKobo: cost, pricePer1000Kobo: price, minQuantity: min, maxQuantity: max, tags }));
    assert.equal(r.status, 201, r.text);
  }
  assert.equal(app.db.prepare("SELECT COUNT(*) AS n FROM services WHERE platform='facebook' AND service_type='followers'").get().n, 3);

  const dup = await boss.post('/api/admin/services', svcBody());
  assert.equal(dup.status, 409); assert.equal(dup.json.field, 'name');

  const cases = [
    [{ name: '' }, 'name'], [{ platform: 'Face Book' }, 'platform'], [{ serviceType: '' }, 'serviceType'], [{ category: '' }, 'category'],
    [{ pricePer1000Kobo: -1 }, 'pricePer1000Kobo'], [{ pricePer1000Kobo: 10.5 }, 'pricePer1000Kobo'], [{ pricePer1000Kobo: '1000' }, 'pricePer1000Kobo'],
    [{ providerCostKobo: -5 }, 'providerCostKobo'], [{ minQuantity: 0 }, 'minQuantity'], [{ minQuantity: 500, maxQuantity: 100 }, 'maxQuantity'],
    [{ maxQuantity: 99999999 }, 'maxQuantity'], [{ refillAvailable: 'yes' }, 'refillAvailable'], [{ tags: 'Fast' }, 'tags'],
    [{ tags: new Array(11).fill('x').map((x, i) => x + i) }, 'tags'], [{ notes: new Array(11).fill('n').join('\n') }, 'notes'],
  ];
  for (const [patch, field] of cases) {
    const r = await boss.post('/api/admin/services', svcBody({ name: 'Bad ' + JSON.stringify(patch).slice(0, 20), ...patch }));
    assert.equal(r.status, 400, JSON.stringify(patch)); assert.equal(r.json.field, field, JSON.stringify(patch));
  }
  assert.equal(audits('service.create').length, 3);
});

test('services: search, filters, edit (price change is audited), enable/disable, delete rules', async () => {
  seedServices(app.db);
  const list = (qs) => boss.get('/api/admin/services' + qs).then((r) => r.json);
  assert.equal((await list('?platform=facebook&limit=100')).services.filter((x) => x.serviceType === 'followers').length >= 3, true);
  assert.equal((await list('?q=Premium')).total, 1);
  assert.equal((await list('?q=33333')).total, 1, 'searchable by provider service id');
  assert.equal((await list('?q=%25')).total, 0, 'LIKE wildcards are escaped');
  assert.equal((await list('?tag=Low%20Drop')).total, 1);
  assert.equal((await list('?category=followers&platform=facebook')).total >= 3, true);
  const f = (await list('?limit=1')).filters;
  assert.ok(f.platforms.includes('facebook') && f.tags.includes('Premium') && f.categories.includes('Followers'));

  const std = (await list('?q=Standard')).services[0];
  const edited = await boss.put(`/api/admin/services/${std.id}`, svcBody({ pricePer1000Kobo: 180000, providerCostKobo: 60000, tags: ['Fast'], minQuantity: 250 }));
  assert.equal(edited.status, 200, edited.text);
  assert.equal(edited.json.service.marginKobo, 120000);
  const audit = audits('service.update').at(-1); const d = JSON.parse(audit.details).changes;
  assert.deepEqual(d.pricePer1000Kobo, [100000, 180000]); assert.deepEqual(d.minQuantity, [100, 250]); assert.ok(d.tags && d.providerCostKobo);
  assert.equal(audit.admin_email, 'boss@example.com');
  const before = audits('service.update').length;
  await boss.put(`/api/admin/services/${std.id}`, svcBody({ pricePer1000Kobo: 180000, providerCostKobo: 60000, tags: ['fast'], minQuantity: 250 }));
  assert.equal(audits('service.update').length, before, 'an edit that changes nothing is not logged');

  // customer-facing system uses the new database price automatically
  const anon = new Client();
  const quote = await anon.post('/api/orders/quote', { serviceId: std.id, quantity: 500 });
  assert.equal(quote.json.quote.chargeKobo, 90000, '500 units at NGN 1,800 per 1,000 = NGN 900');
  await boss.put(`/api/admin/services/${std.id}`, svcBody({ pricePer1000Kobo: 100000, providerCostKobo: 50000, minQuantity: 100 }));
  assert.equal((await anon.post('/api/orders/quote', { serviceId: std.id, quantity: 500 })).json.quote.chargeKobo, 50000, '500 units at NGN 1,000 per 1,000 = NGN 500');
  assert.equal((await anon.post('/api/orders/quote', { serviceId: std.id, quantity: 5000 })).json.quote.chargeKobo, 500000);
  const pub = (await anon.get('/api/services?platform=facebook')).json;
  assert.equal(pub.text?.includes?.('12345'), undefined);
  const mine = pub.services.find((x) => x.id === std.id);
  assert.deepEqual(mine.tags, ['Fast', 'Refill'].slice(0, 1).concat([]).length ? mine.tags : []);
  assert.equal(JSON.stringify(pub).includes('providerServiceId'), false);
  assert.equal(JSON.stringify(pub).includes('providerCost'), false);

  // disable hides it from customers but keeps the record
  assert.equal((await boss.post(`/api/admin/services/${std.id}/status`, { active: false })).json.service.isActive, false);
  assert.equal((await anon.get('/api/services?platform=facebook')).json.services.some((x) => x.id === std.id), false);
  assert.equal((await anon.post('/api/orders/quote', { serviceId: std.id, quantity: 500 })).status, 404);
  assert.equal(app.db.prepare('SELECT COUNT(*) AS n FROM services WHERE id = ?').get(std.id).n, 1);
  assert.equal((await list('?status=inactive')).services.some((x) => x.id === std.id), true);
  assert.equal((await boss.post(`/api/admin/services/${std.id}/status`, { active: 'no' })).status, 400);
  await boss.post(`/api/admin/services/${std.id}/status`, { active: true });
  assert.equal((await anon.post('/api/orders/quote', { serviceId: std.id, quantity: 500 })).status, 200);
  assert.ok(audits('service.disable').length === 1 && audits('service.enable').length === 1);

  // delete: needs confirmation; refused when orders exist; works (and is logged) otherwise
  assert.equal((await boss.del(`/api/admin/services/${std.id}`, {})).status, 400);
  const order = await cust.client.post('/api/orders', { serviceId: std.id, quantity: 1000, link: '@cust' });
  assert.equal(order.status, 201, order.text);
  const refused = await boss.del(`/api/admin/services/${std.id}`, { confirm: true });
  assert.equal(refused.status, 409); assert.match(refused.json.error, /Disable it instead/);
  const prem = (await list('?q=Premium')).services[0];
  assert.equal((await boss.del(`/api/admin/services/${prem.id}`, { confirm: true })).status, 200);
  assert.equal((await boss.get(`/api/admin/services/${prem.id}`)).status, 404);
  assert.equal(audits('service.delete').length, 1);
});

test('tags can be listed, added, renamed and removed', async () => {
  assert.ok((await boss.get('/api/admin/tags')).json.tags.some((t) => t.name === 'Fast' && t.serviceCount >= 1));
  const created = await boss.post('/api/admin/tags', { name: 'Cheap Service' });
  assert.equal(created.status, 201);
  assert.equal((await boss.post('/api/admin/tags', { name: 'cheap service' })).status, 409);
  assert.equal((await boss.patch(`/api/admin/tags/${created.json.tag.id}`, { name: 'Budget' })).status, 200);
  assert.equal((await boss.del(`/api/admin/tags/${created.json.tag.id}`)).status, 200);
  assert.equal((await boss.patch('/api/admin/tags/999999', { name: 'x' })).status, 404);
  assert.deepEqual(['tag.create', 'tag.rename', 'tag.delete'].map((a) => audits(a).length), [1, 1, 1]);
});

test('orders: list, search, detail, safe status changes, refunds happen once', async () => {
  const o = (await boss.get('/api/admin/orders')).json;
  assert.ok(o.total >= 1);
  const first = o.orders[0];
  assert.equal(first.customer.email, 'cust1@example.com'); assert.equal(first.status, 'pending'); assert.equal(first.amountKobo > 0, true);
  assert.equal((await boss.get('/api/admin/orders?status=pending')).json.total >= 1, true);
  assert.equal((await boss.get('/api/admin/orders?status=bogus')).status, 400);
  assert.equal((await boss.get('/api/admin/orders?q=cust1')).json.total >= 1, true);
  assert.equal((await boss.get(`/api/admin/orders?q=%23${first.id}`)).json.orders[0].id, first.id);

  app.db.prepare("UPDATE orders SET provider_order_id = 'PRV-777', provider_status = 'In progress' WHERE id = ?").run(first.id);
  const d = (await boss.get(`/api/admin/orders/${first.id}`)).json.order;
  assert.equal(d.providerOrderId, 'PRV-777'); assert.equal(d.paymentSource, 'Customer wallet'); assert.deepEqual(d.allowedStatuses, ['processing', 'completed', 'canceled', 'failed']);
  assert.equal(d.ledger[0].type, 'order_charge');
  for (const canary of CANARIES) assert.equal(JSON.stringify(d).includes(canary), false);

  assert.equal((await boss.post(`/api/admin/orders/${first.id}/status`, { status: 'exploded' })).status, 400);
  assert.equal((await boss.post(`/api/admin/orders/${first.id}/status`, { status: 'refunded' })).status, 400, 'internal statuses cannot be set');
  assert.equal((await boss.post(`/api/admin/orders/${first.id}/status`, { status: 'processing' })).json.order.status, 'processing');
  assert.equal((await boss.post(`/api/admin/orders/${first.id}/status`, { status: 'pending' })).status, 409, 'no going backwards');

  const bal = () => app.db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(cust.id).balance_kobo;
  const balBefore = bal();
  const cancel = await boss.post(`/api/admin/orders/${first.id}/status`, { status: 'canceled', note: 'Customer request' });
  assert.equal(cancel.status, 200);
  assert.equal(bal(), balBefore + first.amountKobo, 'cancelling refunds the wallet');
  assert.equal(cancel.json.order.ledger.at(-1).type, 'order_refund');
  assert.equal((await boss.post(`/api/admin/orders/${first.id}/status`, { status: 'canceled' })).status, 409);
  assert.equal((await boss.post(`/api/admin/orders/${first.id}/status`, { status: 'completed' })).status, 409, 'final');
  assert.equal(bal(), balBefore + first.amountKobo, 'never refunded twice');
  assert.equal(app.db.prepare("SELECT COUNT(*) AS n FROM wallet_ledger WHERE idempotency_key = ?").get(`order_refund:${first.id}`).n, 1);

  const svc = app.db.prepare("SELECT id FROM services WHERE platform='tiktok' LIMIT 1").get().id;
  const o2 = (await cust.client.post('/api/orders', { serviceId: svc, quantity: 2000, link: '@tt' })).json.order;
  const b2 = bal();
  assert.equal((await boss.post(`/api/admin/orders/${o2.id}/status`, { status: 'completed' })).json.order.completedAt !== null, true);
  assert.equal(bal(), b2, 'completing does not touch the wallet');
  const o3 = (await cust.client.post('/api/orders', { serviceId: svc, quantity: 1000, link: '@tt' })).json.order;
  const b3 = bal();
  await boss.post(`/api/admin/orders/${o3.id}/status`, { status: 'failed', note: 'Provider rejected' });
  assert.equal(bal(), b3 + o3.chargeKobo, 'failed orders are refunded');
  assert.equal((await boss.get('/api/admin/orders/999999')).status, 404);
  const log = audits('order.status_change'); assert.ok(log.length >= 4);
  assert.equal(JSON.parse(log.find((l) => JSON.parse(l.details).to === 'canceled').details).refundedKobo, first.amountKobo);
});

test('customers: list with totals, profile, wallet credit/debit ledger, suspension', async () => {
  const other = await newCustomer('cust2@example.com');
  const list = (await boss.get('/api/admin/customers?q=cust1')).json;
  const c1 = list.customers[0];
  assert.equal(c1.email, 'cust1@example.com'); assert.equal(c1.orderCount >= 3, true);
  const netSpent = app.db.prepare("SELECT -SUM(amount_kobo) AS n FROM wallet_ledger WHERE user_id = ? AND entry_type IN ('order_charge','order_refund')").get(cust.id).n;
  assert.equal(c1.totalSpentKobo, netSpent, 'spending is net of refunds');
  assert.ok(c1.lastActivityAt);
  assert.equal((await boss.get('/api/admin/customers?status=suspended')).json.total, 0);

  const p = (await boss.get(`/api/admin/customers/${cust.id}`)).json;
  assert.ok(p.orders.length >= 3 && p.ledger.length >= 4); assert.equal(p.customer.balanceKobo, c1.balanceKobo);

  const w = (b, o) => boss.post(`/api/admin/customers/${other.id}/wallet`, b, o);
  assert.equal((await w({ type: 'credit', amountKobo: 500000, reason: '' })).status, 400);
  assert.equal((await w({ type: 'credit', amountKobo: 500000, reason: 'ab' })).status, 400);
  assert.equal((await w({ type: 'gift', amountKobo: 500000, reason: 'promo' })).status, 400);
  assert.equal((await w({ type: 'credit', amountKobo: 0, reason: 'promo' })).status, 400);
  assert.equal((await w({ type: 'credit', amountKobo: 10.5, reason: 'promo' })).status, 400);
  assert.equal((await w({ type: 'credit', amountKobo: 500000, reason: 'Welcome bonus' })).status, 200);
  const debitTooMuch = await w({ type: 'debit', amountKobo: 900000, reason: 'Chargeback' });
  assert.equal(debitTooMuch.status, 400); assert.equal(debitTooMuch.json.field, 'amountKobo');
  const debit = await w({ type: 'debit', amountKobo: 120000, reason: 'Chargeback' });
  assert.equal(debit.status, 200);
  assert.equal(debit.json.customer.balanceKobo, 380000);
  const [a, b] = debit.json.ledger;
  assert.deepEqual([a.type, a.amountKobo, a.balanceAfterKobo, a.adminEmail, a.description], ['adjustment', -120000, 380000, 'boss@example.com', 'Manual debit: Chargeback']);
  assert.deepEqual([b.amountKobo, b.balanceAfterKobo, b.description], [500000, 500000, 'Manual credit: Welcome bonus']);
  assert.equal(audits('wallet.credit').length, 1); assert.equal(audits('wallet.debit').length, 1);
  const ad = JSON.parse(audits('wallet.debit')[0].details); assert.deepEqual([ad.amountKobo, ad.reason, ad.balanceAfterKobo], [120000, 'Chargeback', 380000]);
  assert.equal((await boss.post('/api/admin/customers/999999/wallet', { type: 'credit', amountKobo: 100, reason: 'test' })).status, 404);
  const sum = app.db.prepare('SELECT SUM(amount_kobo) AS s FROM wallet_ledger WHERE user_id = ?').get(other.id).s;
  assert.equal(sum, 380000, 'ledger always adds up to the balance');

  // suspension signs the customer out and blocks new sign-ins
  assert.equal((await other.client.get('/api/me')).status, 200);
  assert.equal((await boss.post(`/api/admin/customers/${other.id}/status`, { status: 'suspended' })).status, 200);
  assert.equal((await other.client.get('/api/me')).status, 401);
  assert.equal((await new Client().post('/api/login', { email: 'cust2@example.com', password: 'a-long-password' })).status, 403);
  assert.equal((await boss.post(`/api/admin/customers/${other.id}/status`, { status: 'weird' })).status, 400);
  await boss.post(`/api/admin/customers/${other.id}/status`, { status: 'active' });
  assert.equal((await new Client().post('/api/login', { email: 'cust2@example.com', password: 'a-long-password' })).status, 200);
  assert.equal(audits('customer.status_change').length, 2);
});

test('overview numbers come from the real database', async () => {
  const o = (await boss.get('/api/admin/overview')).json;
  const n = (sql) => app.db.prepare(sql).get().n;
  assert.equal(o.totalCustomers, n('SELECT COUNT(*) AS n FROM users'));
  assert.equal(o.totalOrders, n('SELECT COUNT(*) AS n FROM orders'));
  assert.equal(o.totalWalletBalanceKobo, n('SELECT SUM(balance_kobo) AS n FROM users'));
  assert.equal(o.totalCustomerSpendingKobo, n("SELECT -SUM(amount_kobo) AS n FROM wallet_ledger WHERE entry_type IN ('order_charge','order_refund')"));
  assert.equal(o.activeServices, n('SELECT COUNT(*) AS n FROM services WHERE is_active = 1'));
  const s = o.ordersByStatus;
  assert.equal(s.pending + s.processing + s.completed + s.canceled + s.failed, o.totalOrders);
  assert.deepEqual([s.completed, s.canceled, s.failed], [1, 1, 1]);
});

test('settings: validated, audited, secrets never exposed, maintenance mode blocks orders', async () => {
  const g = await boss.get('/api/admin/settings');
  assert.equal(g.status, 200);
  for (const canary of CANARIES) assert.equal(g.text.includes(canary), false, 'secret leaked: ' + canary);
  assert.equal(g.text.includes('provider.example'), false);
  assert.deepEqual([g.json.integrations.kora.configured, g.json.integrations.provider.configured, g.json.integrations.kora.integrationBuilt, g.json.integrations.provider.integrationBuilt], [true, false, true, true]);
  assert.equal(g.json.security.adminEmail, 'boss@example.com'); assert.equal(g.json.security.otpRequired, true);

  const bad = async (p) => (await boss.patch('/api/admin/settings', p)).status;
  assert.equal(await bad({}), 400); assert.equal(await bad({ siteName: '' }), 400); assert.equal(await bad({ siteStatus: 'closed' }), 400);
  assert.equal(await bad({ currency: 'USD' }), 400); assert.equal(await bad({ minDepositKobo: -1 }), 400); assert.equal(await bad({ otpTtlMinutes: 2 }), 400);
  assert.equal(await bad({ adminSessionHours: 99 }), 400); assert.equal(await bad({ KORA_SECRET_KEY: 'x' }), 400, 'secrets cannot be set through the API');
  const ok = await boss.patch('/api/admin/settings', { siteName: 'Hyper Booster', minDepositKobo: 200000, otpTtlMinutes: 15 });
  assert.equal(ok.status, 200); assert.deepEqual([ok.json.settings.siteName, ok.json.settings.minDepositKobo, ok.json.settings.otpTtlMinutes], ['Hyper Booster', 200000, 15]);
  assert.deepEqual(JSON.parse(audits('settings.update').at(-1).details).changes.minDepositKobo, [100000, 200000]);

  const svc = app.db.prepare("SELECT id FROM services WHERE platform='tiktok' LIMIT 1").get().id;
  await boss.patch('/api/admin/settings', { siteStatus: 'maintenance' });
  const blocked = await cust.client.post('/api/orders', { serviceId: svc, quantity: 100, link: '@x' });
  assert.equal(blocked.status, 503); assert.match(blocked.json.error, /maintenance/);
  await boss.patch('/api/admin/settings', { siteStatus: 'open' });
  assert.equal((await cust.client.post('/api/orders', { serviceId: svc, quantity: 100, link: '@x' })).status, 201);
});

test('changing the admin password signs out other devices and needs the current password', async () => {
  const second = await signInAdmin();
  assert.equal((await second.get('/api/admin/session')).status, 200);
  const pw = (b) => boss.post('/api/admin/password', b);
  assert.equal((await pw({ currentPassword: 'wrong-current-password', newPassword: 'a-brand-new-passphrase' })).status, 400);
  assert.equal((await pw({ currentPassword: ADMIN_PW, newPassword: 'short' })).status, 400);
  assert.equal((await pw({ currentPassword: ADMIN_PW, newPassword: ADMIN_PW })).status, 400);
  assert.equal((await pw({ currentPassword: ADMIN_PW, newPassword: 'a-brand-new-passphrase' })).status, 200);
  assert.equal((await boss.get('/api/admin/session')).status, 200, 'this device stays signed in');
  assert.equal((await second.get('/api/admin/session')).status, 401, 'other devices are signed out');
  assert.equal((await new Client().post('/api/admin/login', { email: 'boss@example.com', password: ADMIN_PW })).status, 401);
  const fresh = await signInAdmin('boss@example.com', 'a-brand-new-passphrase');
  assert.equal((await fresh.get('/api/admin/session')).status, 200);
  assert.equal(audits('admin.password_change').length, 1);
  const hash = app.db.prepare('SELECT password_hash FROM admins').get().password_hash;
  assert.match(hash, /^scrypt\$/);
});

test('audit log lists who did what, and filters by action', async () => {
  const all = (await boss.get('/api/admin/audit?limit=100')).json;
  const actions = new Set(all.entries.map((e) => e.action));
  for (const a of ['admin.login', 'admin.logout', 'service.create', 'service.update', 'service.enable', 'service.disable', 'service.delete', 'order.status_change', 'wallet.credit', 'wallet.debit', 'settings.update']) assert.ok(actions.has(a), 'missing ' + a);
  const one = all.entries.find((e) => e.action === 'wallet.credit');
  assert.equal(one.adminEmail, 'boss@example.com'); assert.equal(one.resourceType, 'customer'); assert.ok(one.createdAt);
  assert.ok((await boss.get('/api/admin/audit?action=service.create')).json.entries.every((e) => e.action === 'service.create'));
  assert.equal(JSON.stringify(all).includes('scrypt$'), false);
});

test('admin responses are never cached and carry the security headers', async () => {
  const r = await boss.get('/api/admin/overview');
  assert.equal(r.headers.get('cache-control'), 'no-store');
  assert.equal(r.headers.get('x-frame-options'), 'DENY');
  const scriptSrc = /script-src ([^;]*)/.exec(r.headers.get('content-security-policy'))[1];
  assert.equal(scriptSrc, "'self'", 'no inline scripts allowed on admin pages');
});
