'use strict';
(() => {
  const $ = (s) => document.querySelector(s);
  const passwordForm = $('#password-form');
  const codeForm = $('#code-form');
  const message = $('#auth-message');
  let busy = false;

  const say = (text, ok = false) => {
    message.textContent = text || '';
    message.classList.toggle('is-ok', ok);
  };

  async function post(path, body) {
    const res = await fetch('/api/admin' + path, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    return { ok: res.ok, status: res.status, data };
  }

  function showCodeStep(info) {
    passwordForm.hidden = true;
    codeForm.hidden = false;
    $('#auth-eyebrow').textContent = 'Check your email';
    $('#auth-title').textContent = 'Enter your code';
    $('#auth-copy').textContent = `We sent a 6-digit code to ${info.maskedEmail}. It expires in ${info.ttlMinutes} minutes.`;
    $('#code').value = '';
    $('#code').focus();
  }

  function showPasswordStep() {
    codeForm.hidden = true;
    passwordForm.hidden = false;
    $('#auth-eyebrow').textContent = 'Restricted area';
    $('#auth-title').textContent = 'Admin sign-in';
    $('#auth-copy').textContent = 'Sign in with your admin email and password. We will email you a one-time code.';
    $('#password').value = '';
    say('');
  }

  passwordForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (busy) return;
    const email = $('#email').value.trim();
    const password = $('#password').value;
    if (!email || !password) return say('Enter your admin email and password.');
    busy = true;
    say('Checking…', true);
    try {
      const r = await post('/login', { email, password });
      if (r.ok) { say(''); showCodeStep(r.data); } else say(r.data.error || 'Sign-in failed.');
    } catch {
      say('Network error. Please try again.');
    }
    busy = false;
  });

  codeForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (busy) return;
    const code = $('#code').value.trim();
    if (!/^\d{6}$/.test(code)) return say('Enter the 6-digit code.');
    busy = true;
    say('Verifying…', true);
    try {
      const r = await post('/verify-otp', { code });
      if (r.ok) { window.location.href = '/admin'; return; }
      say(r.data.error || 'Verification failed.');
      if (r.status === 401 && /sign in again|expired/i.test(r.data.error || '')) setTimeout(showPasswordStep, 1500);
    } catch {
      say('Network error. Please try again.');
    }
    busy = false;
  });

  $('#resend').addEventListener('click', async () => {
    if (busy) return;
    busy = true;
    try {
      const r = await post('/resend-otp', {});
      say(r.ok ? 'A new code is on its way.' : r.data.error || 'Could not send a new code.', r.ok);
    } catch {
      say('Network error. Please try again.');
    }
    busy = false;
  });

  $('#back').addEventListener('click', showPasswordStep);
})();
