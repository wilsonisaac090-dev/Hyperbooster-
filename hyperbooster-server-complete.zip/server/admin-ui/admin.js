'use strict';
(() => {
  // ===================================================================
  //  HYPERBOOSTER Admin: talks only to /api/admin/* (server-side auth).
  //  No secrets, prices or statistics live in this file.
  // ===================================================================
  const $ = (s, r = document) => r.querySelector(s);

  // ---------- tiny DOM helper (text is always set as text, never as HTML) ----------
  function h(tag, props, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (v === null || v === undefined || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (k === 'value') el.value = v;
      else if (k === 'checked') el.checked = v;
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat()) {
      if (kid === null || kid === undefined || kid === false) continue;
      el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    return el;
  }

  // ---------- formatting ----------
  const naira = (kobo) => '₦' + (kobo / 100).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const num = (n) => Number(n).toLocaleString('en-US');
  const when = (iso) => (iso ? new Date(iso).toLocaleString('en-NG', { dateStyle: 'medium', timeStyle: 'short' }) : '—');
  // "1,250.50" -> 125050 (whole kobo) or null if it is not a valid amount
  function parseNaira(text) {
    const t = String(text || '').replace(/[₦,\s]/g, '');
    if (!/^\d+(\.\d{1,2})?$/.test(t)) return null;
    const [w, f = ''] = t.split('.');
    return Number(w) * 100 + Number(f.padEnd(2, '0'));
  }
  const koboToInput = (k) => (k / 100).toFixed(2);
  // same rule as the server: ceil(quantity x pricePer1000 / 1000)
  const chargeFor = (price, qty) => Number((BigInt(price) * BigInt(qty) + 999n) / 1000n);

  const STATUS = { pending: 'Pending', processing: 'Processing', in_progress: 'Processing', completed: 'Completed', canceled: 'Cancelled', failed: 'Failed', partial: 'Partial', refunded: 'Refunded', active: 'Active', suspended: 'Suspended' };
  const badge = (status) => h('span', { class: `badge b-${status}`, text: STATUS[status] || status });

  // ---------- API ----------
  let csrf = '';
  let me = null;
  class ApiError extends Error {
    constructor(status, message, field) { super(message); this.status = status; this.field = field; }
  }
  async function api(path, { method = 'GET', body } = {}) {
    const res = await fetch('/api/admin' + path, {
      method,
      credentials: 'same-origin',
      headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(method !== 'GET' ? { 'X-CSRF-Token': csrf } : {}) },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 401) { window.location.href = '/admin/login'; throw new ApiError(401, 'Signed out'); }
    if (!res.ok) throw new ApiError(res.status, data.error || 'Something went wrong.', data.field);
    return data;
  }

  // ---------- toast, sheet, confirm ----------
  function toast(text, kind = 'ok') {
    const root = $('#toast-root');
    while (root.children.length >= 2) root.firstChild.remove();
    const el = h('div', { class: `toast t-${kind}`, text, onclick: () => el.remove() });
    root.append(el);
    setTimeout(() => el.remove(), 3200);
  }

  let sheetCount = 0;
  function openSheet(title, body, { foot } = {}) {
    const layer = h('div', { class: 'sheet-layer' });
    const close = () => { layer.remove(); sheetCount -= 1; if (!sheetCount) document.body.classList.remove('is-locked'); document.removeEventListener('keydown', onKey); };
    const onKey = (e) => { if (e.key === 'Escape') close(); };
    layer.append(
      h('button', { class: 'sheet-backdrop', type: 'button', 'aria-label': 'Close', tabindex: '-1', onclick: close }),
      h('section', { class: 'sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
        h('div', { class: 'sheet-handle', 'aria-hidden': 'true' }),
        h('div', { class: 'sheet-head' }, h('h2', { text: title }), h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Close', onclick: close }, h('span'), h('span'))),
        h('div', { class: 'sheet-body' }, body),
        foot ? h('div', { class: 'sheet-foot' }, foot) : null)
    );
    $('#sheet-root').append(layer);
    sheetCount += 1;
    document.body.classList.add('is-locked');
    document.addEventListener('keydown', onKey);
    return { close, el: layer };
  }

  function confirmDialog({ title, message, confirmLabel = 'Confirm', danger = false, extra = null }) {
    return new Promise((resolve) => {
      let done = false;
      const finish = (v) => { if (!done) { done = true; sheet.close(); resolve(v); } };
      const sheet = openSheet(title, h('div', null, h('p', { class: 'confirm-text', text: message }), extra),
        { foot: [h('button', { class: 'btn btn-secondary', type: 'button', text: 'Cancel', onclick: () => finish(false) }), h('button', { class: `btn ${danger ? 'btn-danger' : 'btn-primary'}`, type: 'button', text: confirmLabel, onclick: () => finish(true) })] });
      sheet.el.querySelector('.sheet-backdrop').addEventListener('click', () => finish(false));
    });
  }

  // ---------- small building blocks ----------
  const view = $('#view');
  const empty = (text) => h('div', { class: 'empty', text });
  const loading = () => h('div', { class: 'empty', text: 'Loading…' });
  const kv = (label, value) => h('div', { class: 'kv' }, h('span', { class: 'kv-k', text: label }), h('span', { class: 'kv-v' }, value ?? '—'));
  function fail(err, into) {
    if (err.status === 401) return;
    (into || view).replaceChildren(h('div', { class: 'card' }, h('p', { class: 'error-text', text: err.message || 'Could not load this page.' })));
  }
  function debounce(fn, ms = 300) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }
  function select(name, options, value, label) {
    return h('select', { class: 'input', name, 'aria-label': label }, options.map(([v, l]) => h('option', { value: v, text: l, ...(String(v) === String(value ?? '') ? { selected: true } : {}) })));
  }

  // ===================================================================
  //  OVERVIEW
  // ===================================================================
  async function pageOverview() {
    view.replaceChildren(loading());
    try {
      const o = await api('/overview');
      const s = o.ordersByStatus;
      const stat = (label, value, href, tone) => h(href ? 'a' : 'div', { class: `stat ${tone || ''}`, ...(href ? { href } : {}) }, h('div', { class: 'stat-value', text: value }), h('div', { class: 'stat-label', text: label }));
      view.replaceChildren(
        h('h1', { class: 'page-title', text: 'Overview' }),
        h('div', { class: 'stat-grid' },
          stat('Total customers', num(o.totalCustomers), '#/customers'),
          stat('Total orders', num(o.totalOrders), '#/orders'),
          stat('Pending orders', num(s.pending), '#/orders?status=pending', 'warn'),
          stat('Processing orders', num(s.processing), '#/orders?status=processing', 'info'),
          stat('Completed orders', num(s.completed), '#/orders?status=completed', 'good'),
          stat('Failed orders', num(s.failed), '#/orders?status=failed', 'bad'),
          stat('Wallet balance held', naira(o.totalWalletBalanceKobo)),
          stat('Customer spending', naira(o.totalCustomerSpendingKobo)),
          stat('Active services', `${num(o.activeServices)} / ${num(o.totalServices)}`, '#/services')),
        h('p', { class: 'hint', text: 'Spending is net of refunds. Cancelled orders: ' + num(s.canceled) + '.' }));
    } catch (e) { fail(e); }
  }

  // ===================================================================
  //  SERVICES
  // ===================================================================
  const svcState = { q: '', platform: '', category: '', status: '', tag: '', limit: 30 };

  async function pageServices() {
    const list = h('div', { class: 'list' });
    const count = h('p', { class: 'hint' });
    const more = h('div', { class: 'more' });
    let filters = { platforms: [], categories: [], tags: [] };
    const bar = h('div', { class: 'toolbar' });

    async function load(append = false) {
      if (!append) { svcState.offset = 0; list.replaceChildren(loading()); }
      const qs = new URLSearchParams({ limit: svcState.limit, offset: svcState.offset || 0 });
      for (const k of ['q', 'platform', 'category', 'status', 'tag']) if (svcState[k]) qs.set(k, svcState[k]);
      try {
        const r = await api('/services?' + qs);
        filters = r.filters;
        if (!append) list.replaceChildren();
        if (!r.services.length && !append) list.append(empty('No services match. Add one, or clear the filters.'));
        r.services.forEach((s) => list.append(serviceCard(s)));
        svcState.offset = (svcState.offset || 0) + r.services.length;
        count.textContent = `${num(r.total)} service${r.total === 1 ? '' : 's'}`;
        more.replaceChildren(svcState.offset < r.total ? h('button', { class: 'btn btn-secondary', type: 'button', text: 'Load more', onclick: () => load(true) }) : '');
        drawFilters();
      } catch (e) { fail(e, list); }
    }

    function drawFilters() {
      const opts = (all, values) => [['', all], ...values.map((v) => [v, v])];
      const change = (key) => (e) => { svcState[key] = e.target.value; load(); };
      bar.replaceChildren(
        h('input', { class: 'input search', type: 'search', placeholder: 'Search name or provider ID', value: svcState.q, 'aria-label': 'Search services', oninput: debounce((e) => { svcState.q = e.target.value; load(); }) }),
        h('div', { class: 'filter-row' },
          Object.assign(select('platform', opts('All platforms', filters.platforms), svcState.platform, 'Platform'), { onchange: change('platform') }),
          Object.assign(select('category', opts('All categories', filters.categories), svcState.category, 'Category'), { onchange: change('category') }),
          Object.assign(select('status', [['', 'Any status'], ['active', 'Active'], ['inactive', 'Inactive']], svcState.status, 'Status'), { onchange: change('status') }),
          Object.assign(select('tag', opts('All tags', filters.tags), svcState.tag, 'Tag'), { onchange: change('tag') })));
      const input = bar.querySelector('.search');
      if (document.activeElement === document.body && svcState.q) input.focus();
    }

    function serviceCard(s) {
      const below = s.pricePer1000Kobo < s.providerCostKobo;
      return h('article', { class: `item ${s.isActive ? '' : 'is-off'}` },
        h('div', { class: 'item-head' },
          h('div', null, h('div', { class: 'item-title', text: s.name }), h('div', { class: 'item-sub', text: `${s.platform} · ${s.serviceType} · ${s.category}` })),
          badge(s.isActive ? 'active' : 'suspended')),
        h('div', { class: 'item-grid' },
          kv('Customer price', `${naira(s.pricePer1000Kobo)} / 1,000`),
          kv('Provider cost', `${naira(s.providerCostKobo)} / 1,000`),
          kv('Margin', h('span', { class: below ? 'error-text' : '', text: `${naira(s.marginKobo)} / 1,000` })),
          kv('Provider ID', s.providerServiceId || 'Not set'),
          kv('Limits', `${num(s.minQuantity)} – ${num(s.maxQuantity)}`),
          kv('Refill · Drop · Time', `${s.refillAvailable ? 'Refill' : 'No refill'} · ${s.dropRate || '—'} · ${s.averageCompletionTime || '—'}`)),
        s.tags.length ? h('div', { class: 'chips' }, s.tags.map((t) => h('span', { class: 'chip', text: t }))) : null,
        h('div', { class: 'item-actions' },
          h('button', { class: 'btn btn-secondary btn-sm', type: 'button', text: 'Edit', onclick: () => serviceForm(s, filters, load) }),
          h('button', { class: 'btn btn-secondary btn-sm', type: 'button', text: s.isActive ? 'Disable' : 'Enable', onclick: async () => {
            try { await api(`/services/${s.id}/status`, { method: 'POST', body: { active: !s.isActive } }); toast(`${s.name} ${s.isActive ? 'disabled' : 'enabled'}`); load(); } catch (e) { toast(e.message, 'err'); }
          } }),
          h('button', { class: 'btn btn-ghost-danger btn-sm', type: 'button', text: 'Delete', onclick: async () => {
            const ok = await confirmDialog({ title: 'Delete service?', message: `“${s.name}” will be permanently deleted. Services that already have orders cannot be deleted; disable them instead.`, confirmLabel: 'Delete', danger: true });
            if (!ok) return;
            try { await api(`/services/${s.id}`, { method: 'DELETE', body: { confirm: true } }); toast('Service deleted'); load(); } catch (e) { toast(e.message, 'err'); }
          } })));
    }

    view.replaceChildren(
      h('div', { class: 'page-head' }, h('h1', { class: 'page-title', text: 'Services' }), h('button', { class: 'btn btn-primary', type: 'button', text: '+ Add service', onclick: () => serviceForm(null, filters, load) })),
      bar, count, list, more);
    drawFilters();
    load();
  }

  // ----- service form (drawer) -----
  async function serviceForm(service, filters, onSaved) {
    const editing = Boolean(service);
    const s = service || { name: '', category: '', platform: '', serviceType: '', providerServiceId: '', providerCostKobo: 0, pricePer1000Kobo: 0, minQuantity: 100, maxQuantity: 100000, refillAvailable: false, dropRate: '', averageCompletionTime: '', description: '', notes: '', tags: [], isActive: true, sortOrder: 0 };
    let allTags = [...(filters.tags || [])];
    try { allTags = (await api('/tags')).tags.map((t) => t.name); } catch { /* fall back to the list we have */ }
    const chosen = new Set(s.tags);

    const errors = {};
    const err = (name) => { const p = h('p', { class: 'field-error' }); errors[name] = p; return p; };
    const field = (label, name, input, hint) => h('div', { class: 'field' }, h('label', { for: `f-${name}`, text: label }), input, hint ? h('p', { class: 'hint', text: hint }) : null, err(name));
    const text = (name, value, extra = {}) => h('input', { class: 'input', id: `f-${name}`, name, value: value ?? '', autocomplete: 'off', ...extra });
    const dl = (id, values) => h('datalist', { id }, [...new Set(values)].map((v) => h('option', { value: v })));

    const f = {
      name: text('name', s.name, { maxlength: '80' }),
      platform: text('platform', s.platform, { list: 'dl-platform', placeholder: 'e.g. facebook', autocapitalize: 'none', maxlength: '32' }),
      category: text('category', s.category, { list: 'dl-category', placeholder: 'e.g. Followers', maxlength: '40' }),
      serviceType: text('serviceType', s.serviceType, { placeholder: 'e.g. followers', autocapitalize: 'none', maxlength: '32' }),
      providerServiceId: text('providerServiceId', s.providerServiceId, { maxlength: '64', placeholder: 'ID from your provider' }),
      providerCost: text('providerCostKobo', koboToInput(s.providerCostKobo), { inputmode: 'decimal' }),
      price: text('pricePer1000Kobo', koboToInput(s.pricePer1000Kobo), { inputmode: 'decimal' }),
      min: text('minQuantity', s.minQuantity, { inputmode: 'numeric' }),
      max: text('maxQuantity', s.maxQuantity, { inputmode: 'numeric' }),
      refill: h('input', { type: 'checkbox', id: 'f-refill', checked: s.refillAvailable }),
      drop: text('dropRate', s.dropRate, { placeholder: 'e.g. Low, 0-5%', maxlength: '40' }),
      time: text('averageCompletionTime', s.averageCompletionTime, { placeholder: 'e.g. 0-2 hours', maxlength: '40' }),
      description: h('textarea', { class: 'input', id: 'f-description', name: 'description', rows: '3', maxlength: '500' }),
      notes: h('textarea', { class: 'input', id: 'f-notes', name: 'notes', rows: '3', placeholder: 'One note per line' }),
      newTags: text('tags', '', { placeholder: 'Add tags, separated by commas' }),
      active: h('input', { type: 'checkbox', id: 'f-active', checked: s.isActive }),
      sort: text('sortOrder', s.sortOrder, { inputmode: 'numeric' }),
    };
    f.description.value = s.description || '';
    f.notes.value = s.notes || '';

    const preview = h('div', { class: 'price-preview' });
    function drawPreview() {
      const price = parseNaira(f.price.value); const cost = parseNaira(f.providerCost.value);
      if (price === null) { preview.replaceChildren(h('span', { class: 'hint', text: 'Enter a customer price to see examples.' })); return; }
      const line = (q) => `${num(q)} units = ${naira(chargeFor(price, q))}`;
      const margin = cost === null ? null : price - cost;
      preview.replaceChildren(
        h('div', { text: `${line(500)} · ${line(1000)} · ${line(5000)}` }),
        margin === null ? null : h('div', { class: margin < 0 ? 'error-text' : 'good-text', text: margin < 0 ? `Warning: selling below cost (${naira(margin)} per 1,000).` : `Margin ${naira(margin)} per 1,000.` }));
    }
    f.price.addEventListener('input', drawPreview); f.providerCost.addEventListener('input', drawPreview);

    const chips = h('div', { class: 'chips chips-pick' });
    function drawChips() {
      chips.replaceChildren(...allTags.map((t) => h('button', { type: 'button', class: `chip chip-btn ${chosen.has(t) ? 'is-on' : ''}`, 'aria-pressed': String(chosen.has(t)), text: t, onclick: () => { chosen.has(t) ? chosen.delete(t) : chosen.add(t); drawChips(); } })));
      if (!allTags.length) chips.append(h('span', { class: 'hint', text: 'No tags yet. Add some below.' }));
    }
    drawChips();
    drawPreview();

    const group = (title, ...kids) => h('fieldset', { class: 'group' }, h('legend', { text: title }), ...kids);
    const form = h('form', { class: 'form', novalidate: true },
      dl('dl-platform', filters.platforms || []), dl('dl-category', filters.categories || []),
      group('Basic information', field('Service name', 'name', f.name), h('div', { class: 'two' }, field('Platform', 'platform', f.platform), field('Service type', 'serviceType', f.serviceType)), field('Category', 'category', f.category)),
      group('Provider', field('Provider service ID', 'providerServiceId', f.providerServiceId, 'Only the ID is stored here. Provider API keys stay on the server.'), field('Provider cost (₦ per 1,000)', 'providerCostKobo', f.providerCost)),
      group('Customer pricing', field('Customer selling price (₦ per 1,000)', 'pricePer1000Kobo', f.price, 'Customers are charged quantity ÷ 1,000 × this price.'), preview),
      group('Limits', h('div', { class: 'two' }, field('Minimum quantity', 'minQuantity', f.min), field('Maximum quantity', 'maxQuantity', f.max))),
      group('Service information',
        h('label', { class: 'check', for: 'f-refill' }, f.refill, h('span', { text: 'Refill available' })),
        h('div', { class: 'two' }, field('Drop rate', 'dropRate', f.drop), field('Completion time', 'averageCompletionTime', f.time)),
        field('Description', 'description', f.description), field('Notes (shown to customers)', 'notes', f.notes),
        h('div', { class: 'field' }, h('label', { text: 'Tags' }), chips, f.newTags, err('tags'))),
      group('Status', h('label', { class: 'check', for: 'f-active' }, f.active, h('span', { text: 'Active (visible to customers)' })), field('Display order', 'sortOrder', f.sort, 'Lower numbers appear first.')),
      h('p', { class: 'field-error form-error', id: 'form-error' }));

    let saving = false;
    async function save() {
      if (saving) return;
      Object.values(errors).forEach((p) => { p.textContent = ''; });
      $('#form-error', form).textContent = '';
      const bad = (name, msg) => { (errors[name] || $('#form-error', form)).textContent = msg; return false; };
      let ok = true;
      const req = (name, val, label) => { if (!String(val).trim()) ok = bad(name, `${label} is required.`); };
      req('name', f.name.value, 'Service name'); req('platform', f.platform.value, 'Platform'); req('category', f.category.value, 'Category'); req('serviceType', f.serviceType.value, 'Service type');
      const price = parseNaira(f.price.value); if (price === null) ok = bad('pricePer1000Kobo', 'Enter a valid amount, e.g. 1000 or 1000.50.');
      const cost = f.providerCost.value.trim() === '' ? 0 : parseNaira(f.providerCost.value); if (cost === null) ok = bad('providerCostKobo', 'Enter a valid amount.');
      const min = Number(f.min.value); const max = Number(f.max.value);
      if (!Number.isInteger(min) || min < 1) ok = bad('minQuantity', 'Whole number, at least 1.');
      if (!Number.isInteger(max) || max < min) ok = bad('maxQuantity', 'Whole number, not below the minimum.');
      const sort = f.sort.value.trim() === '' ? 0 : Number(f.sort.value);
      if (!Number.isInteger(sort) || sort < 0) ok = bad('sortOrder', 'Whole number, 0 or more.');
      if (!ok) { toast('Please fix the highlighted fields.', 'err'); return; }

      const extra = f.newTags.value.split(',').map((t) => t.trim()).filter(Boolean);
      const body = {
        name: f.name.value.trim(), platform: f.platform.value.trim().toLowerCase(), category: f.category.value.trim(), serviceType: f.serviceType.value.trim().toLowerCase(),
        providerServiceId: f.providerServiceId.value.trim() || null, providerCostKobo: cost, pricePer1000Kobo: price, minQuantity: min, maxQuantity: max,
        refillAvailable: f.refill.checked, dropRate: f.drop.value.trim() || null, averageCompletionTime: f.time.value.trim() || null,
        description: f.description.value.trim() || null, notes: f.notes.value.trim() || null, tags: [...chosen, ...extra], isActive: f.active.checked, sortOrder: sort,
      };
      saving = true; saveBtn.disabled = true;
      try {
        await api(editing ? `/services/${s.id}` : '/services', { method: editing ? 'PUT' : 'POST', body });
        sheet.close(); toast(editing ? 'Service saved' : 'Service added'); onSaved();
      } catch (e) {
        const target = errors[e.field];
        if (target) { target.textContent = e.message; target.scrollIntoView({ block: 'center', behavior: 'smooth' }); } else $('#form-error', form).textContent = e.message;
        toast(e.message, 'err');
      }
      saving = false; saveBtn.disabled = false;
    }
    const saveBtn = h('button', { class: 'btn btn-primary', type: 'button', text: editing ? 'Save changes' : 'Add service', onclick: save });
    form.addEventListener('submit', (e) => { e.preventDefault(); save(); });
    const sheet = openSheet(editing ? 'Edit service' : 'Add service', form, { foot: [h('button', { class: 'btn btn-secondary', type: 'button', text: 'Cancel', onclick: () => sheet.close() }), saveBtn] });
  }

  // ===================================================================
  //  ORDERS
  // ===================================================================
  async function pageOrders(params) {
    const st = { q: params.get('q') || '', status: params.get('status') || '', offset: 0, limit: 20 };
    const list = h('div', { class: 'list' });
    const count = h('p', { class: 'hint' });
    const more = h('div', { class: 'more' });

    async function load(append = false) {
      if (!append) { st.offset = 0; list.replaceChildren(loading()); }
      const qs = new URLSearchParams({ limit: st.limit, offset: st.offset });
      if (st.q) qs.set('q', st.q); if (st.status) qs.set('status', st.status);
      try {
        const r = await api('/orders?' + qs);
        if (!append) list.replaceChildren();
        if (!r.orders.length && !append) list.append(empty('No orders found.'));
        r.orders.forEach((o) => list.append(h('a', { class: 'item item-link', href: `#/orders/${o.id}` },
          h('div', { class: 'item-head' }, h('div', null, h('div', { class: 'item-title', text: `#${o.id} · ${o.serviceName}` }), h('div', { class: 'item-sub', text: `${o.customer.name} · ${o.customer.email}` })), badge(o.status)),
          h('div', { class: 'item-grid' }, kv('Quantity', num(o.quantity)), kv('Amount', naira(o.amountKobo)), kv('Account', h('span', { class: 'break', text: o.link })), kv('Date', when(o.createdAt))))));
        st.offset += r.orders.length;
        count.textContent = `${num(r.total)} order${r.total === 1 ? '' : 's'}`;
        more.replaceChildren(st.offset < r.total ? h('button', { class: 'btn btn-secondary', type: 'button', text: 'Load more', onclick: () => load(true) }) : '');
      } catch (e) { fail(e, list); }
    }

    const statusSel = Object.assign(select('status', [['', 'All statuses'], ['pending', 'Pending'], ['processing', 'Processing'], ['completed', 'Completed'], ['canceled', 'Cancelled'], ['failed', 'Failed']], st.status, 'Status'), { onchange: (e) => { st.status = e.target.value; load(); } });
    view.replaceChildren(
      h('h1', { class: 'page-title', text: 'Orders' }),
      h('div', { class: 'toolbar' }, h('input', { class: 'input search', type: 'search', placeholder: 'Search order #, customer, link', value: st.q, 'aria-label': 'Search orders', oninput: debounce((e) => { st.q = e.target.value; load(); }) }), h('div', { class: 'filter-row' }, statusSel)),
      count, list, more);
    load();
  }

  async function pageOrderDetail(id) {
    view.replaceChildren(loading());
    try {
      const { order: o } = await api(`/orders/${id}`);
      const actions = h('div', { class: 'item-actions wrap' });
      const change = (status) => async () => {
        const refund = status === 'canceled' || status === 'failed';
        const note = h('input', { class: 'input', placeholder: 'Optional note (kept in the audit log)', maxlength: '200' });
        const ok = await confirmDialog({
          title: `Mark order #${o.id} as ${STATUS[status].toLowerCase()}?`,
          message: refund ? `The customer's wallet will be refunded ${naira(o.amountKobo)}. This cannot be undone.` : 'This cannot be reversed.',
          confirmLabel: `Mark ${STATUS[status].toLowerCase()}`, danger: refund, extra: refund ? note : null,
        });
        if (!ok) return;
        try { await api(`/orders/${o.id}/status`, { method: 'POST', body: { status, note: note.value.trim() || undefined } }); toast('Order updated'); pageOrderDetail(id); } catch (e) { toast(e.message, 'err'); }
      };
      o.allowedStatuses.forEach((s) => actions.append(h('button', { class: `btn btn-sm ${s === 'canceled' || s === 'failed' ? 'btn-ghost-danger' : 'btn-secondary'}`, type: 'button', text: `Mark ${STATUS[s].toLowerCase()}`, onclick: change(s) })));
      view.replaceChildren(
        h('a', { class: 'back', href: '#/orders', text: '← Orders' }),
        h('div', { class: 'page-head' }, h('h1', { class: 'page-title', text: `Order #${o.id}` }), badge(o.status)),
        h('section', { class: 'card' },
          kv('Customer', h('a', { href: `#/customers/${o.customer.id}`, text: `${o.customer.name} (${o.customer.email})` })),
          kv('Service', `${o.serviceName} (${o.platform} · ${o.serviceType})`), kv('Quantity', num(o.quantity)),
          kv('Account link / username', h('span', { class: 'break', text: o.link })),
          kv('Amount', naira(o.amountKobo)), kv('Price at purchase', `${naira(o.pricePer1000Kobo)} / 1,000`), kv('Payment source', o.paymentSource),
          kv('Provider order ID', o.providerOrderId || 'Not sent to a provider yet'), kv('Provider status', o.providerStatus || '—'),
          kv('Created', when(o.createdAt)), kv('Last update', when(o.updatedAt)), kv('Completed', when(o.completedAt)),
          o.errorMessage ? kv('Note', o.errorMessage) : null),
        h('section', { class: 'card' }, h('h2', { class: 'card-title', text: 'Update status' }), o.allowedStatuses.length ? actions : h('p', { class: 'hint', text: 'This order is finished, so its status can no longer be changed.' })),
        h('section', { class: 'card' }, h('h2', { class: 'card-title', text: 'Wallet entries for this order' }),
          o.ledger.length ? h('div', { class: 'list tight' }, o.ledger.map((l) => ledgerRow(l))) : h('p', { class: 'hint', text: 'None.' })));
    } catch (e) { fail(e); }
  }

  const LEDGER = { deposit: 'Deposit', order_charge: 'Order charge', order_refund: 'Order refund', adjustment: 'Manual adjustment' };
  const ledgerRow = (l) => h('div', { class: 'ledger' },
    h('div', null, h('div', { class: 'item-title', text: LEDGER[l.type] || l.type }), h('div', { class: 'item-sub', text: `${l.description || ''}${l.adminEmail ? ` · by ${l.adminEmail}` : ''}` }), h('div', { class: 'item-sub', text: when(l.createdAt) })),
    h('div', { class: 'ledger-amt' }, h('div', { class: l.amountKobo < 0 ? 'error-text' : 'good-text', text: (l.amountKobo > 0 ? '+' : '') + naira(l.amountKobo) }), h('div', { class: 'item-sub', text: `Balance ${naira(l.balanceAfterKobo)}` })));

  // ===================================================================
  //  CUSTOMERS / WALLETS
  // ===================================================================
  async function pageCustomers() {
    const st = { q: '', status: '', offset: 0, limit: 20 };
    const list = h('div', { class: 'list' });
    const count = h('p', { class: 'hint' });
    const more = h('div', { class: 'more' });
    async function load(append = false) {
      if (!append) { st.offset = 0; list.replaceChildren(loading()); }
      const qs = new URLSearchParams({ limit: st.limit, offset: st.offset });
      if (st.q) qs.set('q', st.q); if (st.status) qs.set('status', st.status);
      try {
        const r = await api('/customers?' + qs);
        if (!append) list.replaceChildren();
        if (!r.customers.length && !append) list.append(empty('No customers found.'));
        r.customers.forEach((c) => list.append(h('a', { class: 'item item-link', href: `#/customers/${c.id}` },
          h('div', { class: 'item-head' }, h('div', null, h('div', { class: 'item-title', text: c.fullName }), h('div', { class: 'item-sub', text: c.email })), badge(c.status)),
          h('div', { class: 'item-grid' }, kv('Wallet', naira(c.balanceKobo)), kv('Orders', num(c.orderCount)), kv('Total spent', naira(c.totalSpentKobo)), kv('Registered', when(c.createdAt)), kv('Last activity', when(c.lastActivityAt))))));
        st.offset += r.customers.length;
        count.textContent = `${num(r.total)} customer${r.total === 1 ? '' : 's'}`;
        more.replaceChildren(st.offset < r.total ? h('button', { class: 'btn btn-secondary', type: 'button', text: 'Load more', onclick: () => load(true) }) : '');
      } catch (e) { fail(e, list); }
    }
    view.replaceChildren(
      h('h1', { class: 'page-title', text: 'Customers' }),
      h('div', { class: 'toolbar' }, h('input', { class: 'input search', type: 'search', placeholder: 'Search name or email', 'aria-label': 'Search customers', oninput: debounce((e) => { st.q = e.target.value; load(); }) }),
        h('div', { class: 'filter-row' }, Object.assign(select('status', [['', 'All accounts'], ['active', 'Active'], ['suspended', 'Suspended']], '', 'Status'), { onchange: (e) => { st.status = e.target.value; load(); } }))),
      count, list, more);
    load();
  }

  async function pageCustomerDetail(id) {
    view.replaceChildren(loading());
    try {
      const d = await api(`/customers/${id}`);
      const c = d.customer;
      const type = h('select', { class: 'input', id: 'w-type', 'aria-label': 'Credit or debit' }, h('option', { value: 'credit', text: 'Credit (add money)' }), h('option', { value: 'debit', text: 'Debit (remove money)' }));
      const amount = h('input', { class: 'input', id: 'w-amount', inputmode: 'decimal', placeholder: 'Amount in ₦, e.g. 5000' });
      const reason = h('input', { class: 'input', id: 'w-reason', maxlength: '200', placeholder: 'Reason (required, kept in the audit log)' });
      const wErr = h('p', { class: 'field-error' });
      let busy = false;
      const adjust = async () => {
        if (busy) return; wErr.textContent = '';
        const kobo = parseNaira(amount.value);
        if (kobo === null || kobo < 1) return void (wErr.textContent = 'Enter a valid amount.');
        if (reason.value.trim().length < 3) return void (wErr.textContent = 'Enter a reason (at least 3 characters).');
        const ok = await confirmDialog({ title: `${type.value === 'credit' ? 'Credit' : 'Debit'} ${naira(kobo)}?`, message: `${c.fullName}'s wallet will be ${type.value === 'credit' ? 'credited' : 'debited'} ${naira(kobo)}. Reason: “${reason.value.trim()}”. This is recorded in the ledger under your name.`, confirmLabel: type.value === 'credit' ? 'Credit wallet' : 'Debit wallet', danger: type.value === 'debit' });
        if (!ok) return;
        busy = true;
        try { await api(`/customers/${id}/wallet`, { method: 'POST', body: { type: type.value, amountKobo: kobo, reason: reason.value.trim() } }); toast('Wallet updated'); pageCustomerDetail(id); }
        catch (e) { wErr.textContent = e.message; toast(e.message, 'err'); }
        busy = false;
      };
      const suspending = c.status === 'active';
      view.replaceChildren(
        h('a', { class: 'back', href: '#/customers', text: '← Customers' }),
        h('div', { class: 'page-head' }, h('h1', { class: 'page-title', text: c.fullName }), badge(c.status)),
        h('section', { class: 'card' }, kv('Email', c.email), kv('Registered', when(c.createdAt)), kv('Last activity', when(c.lastActivityAt)), kv('Orders', num(c.orderCount)), kv('Total spent', naira(c.totalSpentKobo)),
          h('div', { class: 'item-actions' }, h('button', { class: `btn btn-sm ${suspending ? 'btn-ghost-danger' : 'btn-secondary'}`, type: 'button', text: suspending ? 'Suspend account' : 'Reactivate account', onclick: async () => {
            const ok = await confirmDialog({ title: suspending ? 'Suspend this account?' : 'Reactivate this account?', message: suspending ? 'They will be signed out and unable to sign in or order until reactivated.' : 'They will be able to sign in and order again.', confirmLabel: suspending ? 'Suspend' : 'Reactivate', danger: suspending });
            if (!ok) return;
            try { await api(`/customers/${id}/status`, { method: 'POST', body: { status: suspending ? 'suspended' : 'active' } }); toast('Account updated'); pageCustomerDetail(id); } catch (e) { toast(e.message, 'err'); }
          } }))),
        h('section', { class: 'card' }, h('h2', { class: 'card-title', text: 'Wallet' }), h('div', { class: 'big-money', text: naira(c.balanceKobo) }),
          h('div', { class: 'form' }, h('div', { class: 'field' }, h('label', { for: 'w-type', text: 'Manual adjustment' }), type), h('div', { class: 'field' }, amount), h('div', { class: 'field' }, reason), wErr,
            h('button', { class: 'btn btn-primary', type: 'button', text: 'Apply adjustment', onclick: adjust }))),
        h('section', { class: 'card' }, h('h2', { class: 'card-title', text: 'Wallet transactions' }), d.ledger.length ? h('div', { class: 'list tight' }, d.ledger.map(ledgerRow)) : h('p', { class: 'hint', text: 'No transactions yet.' })),
        h('section', { class: 'card' }, h('h2', { class: 'card-title', text: 'Deposits' }), d.deposits.length ? h('div', { class: 'list tight' }, d.deposits.map((x) => h('div', { class: 'ledger' }, h('div', null, h('div', { class: 'item-title', text: x.reference }), h('div', { class: 'item-sub', text: `${x.gateway} · ${when(x.createdAt)}` })), h('div', { class: 'ledger-amt' }, h('div', { text: naira(x.amountKobo) }), badge(x.status === 'successful' ? 'completed' : x.status))))) : h('p', { class: 'hint', text: 'No deposits yet.' })),
        h('section', { class: 'card' }, h('h2', { class: 'card-title', text: 'Order history' }), d.orders.length ? h('div', { class: 'list tight' }, d.orders.map((o) => h('a', { class: 'ledger item-link', href: `#/orders/${o.id}` }, h('div', null, h('div', { class: 'item-title', text: `#${o.id} · ${o.serviceName}` }), h('div', { class: 'item-sub', text: `${num(o.quantity)} · ${when(o.createdAt)}` })), h('div', { class: 'ledger-amt' }, h('div', { text: naira(o.amountKobo) }), badge(o.status))))) : h('p', { class: 'hint', text: 'No orders yet.' })));
    } catch (e) { fail(e); }
  }

  // ===================================================================
  //  SETTINGS
  // ===================================================================
  // Integrations: secrets are write-only. The server only ever sends state + the last 4 characters.
  function integrationsCard() {
    const box = h('div', null, h('p', { class: 'hint', text: 'Loading…' }));
    const label = { connected: ['Connected', 'b-completed'], configured: ['Saved, not tested', 'b-pending'], not_configured: ['Not configured', 'b-pending'], error: ['Error', 'b-failed'] };
    async function load() {
      try {
        const d = await api('/integrations');
        box.replaceChildren(...d.integrations.map((it) => {
          const [text, cls] = label[it.status] || label.not_configured;
          const isGroq = it.id === 'groq';
          const rows = [
            h('div', { class: 'kv' }, h('span', { text: it.name }), h('span', { class: `badge ${cls}`, text })),
            it.url ? h('div', { class: 'kv' }, h('span', { text: 'API URL' }), h('span', { text: it.url })) : null,
            isGroq ? h('div', { class: 'kv' }, h('span', { text: 'Model' }), h('span', { text: it.model })) : null,
            h('div', { class: 'kv' }, h('span', { text: it.id === 'kora' ? 'Secret key' : 'API key' }), h('span', { text: it.keyMasked || 'Not configured' })),
          ];
          const msg = h('p', { class: 'hint', text: it.source === 'environment' ? 'Currently using the server environment variable. Saving a key here replaces it.' : '' });
          const updateBtn = h('button', { class: 'btn btn-secondary', type: 'button', text: it.keyMasked ? 'Update key' : 'Add key', onclick: () => keySheet(it) });
          const testBtn = isGroq ? null : h('button', { class: 'btn btn-secondary', type: 'button', text: 'Test connection', onclick: async (ev) => {
            ev.target.disabled = true; msg.textContent = 'Testing…';
            try { const r = await api(`/integrations/${it.id}/test`, { method: 'POST', body: {} }); toast(r.ok ? 'Connected' : 'Test failed', r.ok ? undefined : 'err'); msg.textContent = r.message; load(); } catch (e) { msg.textContent = e.message; ev.target.disabled = false; }
          } });
          return h('div', { class: 'field' }, ...rows, msg, h('div', { class: 'row' }, updateBtn, testBtn));
        }));
      } catch (e) { box.replaceChildren(h('p', { class: 'hint', text: 'Could not load integrations.' })); }
    }
    function keySheet(it) {
      const key = h('input', { class: 'input', type: 'password', autocomplete: 'off', placeholder: 'Paste the new key' });
      const pw = h('input', { class: 'input', type: 'password', autocomplete: 'current-password', placeholder: 'Your admin password' });
      const err = h('p', { class: 'field-error', role: 'alert' });
      const save = h('button', { class: 'btn btn-primary', type: 'button', text: 'Save key' });
      const body = h('div', null,
        h('p', { class: 'hint', text: 'The key is stored encrypted and can never be shown again. To change it later, enter a new one.' }),
        h('div', { class: 'field' }, h('label', { text: it.id === 'kora' ? 'Secret key' : 'API key' }), key),
        h('div', { class: 'field' }, h('label', { text: 'Confirm with your admin password' }), pw), err);
      const sheet = openSheet(`${it.keyMasked ? 'Update' : 'Add'} ${it.name} key`, body, { foot: [h('button', { class: 'btn btn-secondary', type: 'button', text: 'Cancel', onclick: () => sheet.close() }), save] });
      save.addEventListener('click', async () => {
        err.textContent = ''; save.disabled = true;
        try {
          if (it.id === 'groq') await api('/ai/settings', { method: 'PATCH', body: { apiKey: key.value, currentPassword: pw.value } });
          else await api(`/integrations/${it.id}/key`, { method: 'PUT', body: { apiKey: key.value, currentPassword: pw.value } });
          key.value = pw.value = ''; sheet.close(); toast('Key saved'); load();
        } catch (e) { err.textContent = e.message; save.disabled = false; }
      });
    }
    load();
    return box;
  }

  async function pageSettings() {
    view.replaceChildren(loading());
    try {
      const d = await api('/settings');
      const s = d.settings;
      const yes = (v, a = 'Configured', b = 'Not configured') => h('span', { class: `badge ${v ? 'b-completed' : 'b-pending'}`, text: v ? a : b });
      const saveGroup = async (body, label, errEl) => { errEl.textContent = ''; try { await api('/settings', { method: 'PATCH', body }); toast(`${label} saved`); pageSettings(); } catch (e) { errEl.textContent = e.message; toast(e.message, 'err'); } };

      const gErr = h('p', { class: 'field-error' });
      const siteName = h('input', { class: 'input', id: 's-name', value: s.siteName, maxlength: '60' });
      const siteStatus = h('select', { class: 'input', id: 's-status' }, h('option', { value: 'open', text: 'Open: customers can order', ...(s.siteStatus === 'open' ? { selected: true } : {}) }), h('option', { value: 'maintenance', text: 'Maintenance: ordering paused', ...(s.siteStatus === 'maintenance' ? { selected: true } : {}) }));
      const minDep = h('input', { class: 'input', id: 's-mindep', inputmode: 'decimal', value: koboToInput(s.minDepositKobo) });

      const sErr = h('p', { class: 'field-error' });
      const otp = h('input', { class: 'input', id: 's-otp', inputmode: 'numeric', value: String(s.otpTtlMinutes) });
      const hours = h('input', { class: 'input', id: 's-hours', inputmode: 'numeric', value: String(s.adminSessionHours) });

      const pErr = h('p', { class: 'field-error' });
      const cur = h('input', { class: 'input', id: 'p-cur', type: 'password', autocomplete: 'current-password' });
      const nw = h('input', { class: 'input', id: 'p-new', type: 'password', autocomplete: 'new-password' });
      const nw2 = h('input', { class: 'input', id: 'p-new2', type: 'password', autocomplete: 'new-password' });

      const auditBox = h('div', { class: 'list tight' });
      const auditMore = h('div', { class: 'more' });
      let auditOffset = 0;
      async function loadAudit() {
        try {
          const r = await api(`/audit?limit=15&offset=${auditOffset}`);
          r.entries.forEach((e) => auditBox.append(h('div', { class: 'ledger' }, h('div', null, h('div', { class: 'item-title', text: e.action }), h('div', { class: 'item-sub', text: `${e.adminEmail || 'unknown'}${e.resourceType ? ` · ${e.resourceType}${e.resourceId ? ' #' + e.resourceId : ''}` : ''}` }), h('div', { class: 'item-sub', text: when(e.createdAt) })))));
          auditOffset += r.entries.length;
          if (!auditOffset) auditBox.append(h('p', { class: 'hint', text: 'No activity yet.' }));
          auditMore.replaceChildren(auditOffset < r.total ? h('button', { class: 'btn btn-secondary btn-sm', type: 'button', text: 'Load more', onclick: loadAudit }) : '');
        } catch (e) { toast(e.message, 'err'); }
      }

      let ai = null;
      try { ai = await api('/ai/settings'); } catch (e) { toast(e.message, 'err'); }

      function aiCard() {
        if (!ai) return h('p', { class: 'hint', text: 'Could not load AI Assistant settings.' });
        const enabledBox = h('input', { type: 'checkbox', id: 'ai-enabled', checked: ai.enabled });
        const name = h('input', { class: 'input', id: 'ai-name', value: ai.assistantName, maxlength: '40' });
        const provider = h('select', { class: 'input', id: 'ai-provider' }, ai.availableProviders.map((p) => h('option', { value: p, text: p, ...(p === ai.provider ? { selected: true } : {}) })));
        const model = h('input', { class: 'input', id: 'ai-model', value: ai.model, maxlength: '100' });
        const apiKey = h('input', { class: 'input', id: 'ai-key', type: 'password', autocomplete: 'off', placeholder: ai.apiKeyConfigured ? `•••••••••••• ${ai.apiKeyLast4}` : 'No API key set' });
        const sys = h('textarea', { class: 'input', id: 'ai-sys', rows: '3', maxlength: '4000', placeholder: 'Optional extra instructions for EL (cannot override its security rules).' });
        sys.value = ai.systemInstructions || '';
        const perms = {};
        const permRow = (key, label) => { perms[key] = h('input', { type: 'checkbox', checked: ai.toolPermissions[key] !== false }); return h('label', { class: 'check perm-row' }, perms[key], h('span', { text: label })); };
        // Opt-in capabilities are unchecked unless the server says they are explicitly on.
        const capRow = (key, id, label) => { perms[key] = h('input', { type: 'checkbox', id, checked: ai.toolPermissions[key] === true }); return h('label', { class: 'check perm-row', for: id }, perms[key], h('span', { text: label })); };
        // Live web search: which service answers, the Exa key (write-only: only "saved or not" is ever shown) and the size limits.
    const sc = ai.search || { provider: 'exa', availableProviders: ['exa'], maxResults: 5, resultChars: 4000, exaConfigured: false };
    const sLim = (ai.limits.webSearch && ai.limits.webSearch.maxResults) || { min: 1, max: 10 };
    const cLim = (ai.limits.webSearch && ai.limits.webSearch.resultChars) || { min: 500, max: 8000 };
    const searchProvider = h('select', { class: 'input', id: 'ai-search-provider' }, sc.availableProviders.map((p) => h('option', { value: p, text: p === 'exa' ? 'Exa (recommended)' : 'Groq browser search', ...(p === sc.provider ? { selected: true } : {}) })));
    const exaKey = h('input', { class: 'input', id: 'ai-exa-key', type: 'password', autocomplete: 'off', placeholder: sc.exaConfigured ? 'Exa key saved (hidden)' : 'No Exa key set' });
    const exaClear = h('input', { type: 'checkbox', id: 'ai-exa-clear' });
    const maxResults = h('input', { class: 'input', id: 'ai-search-results', type: 'number', inputmode: 'numeric', min: String(sLim.min), max: String(sLim.max), value: String(sc.maxResults) });
    const resultChars = h('input', { class: 'input', id: 'ai-search-chars', type: 'number', inputmode: 'numeric', min: String(cLim.min), max: String(cLim.max), value: String(sc.resultChars) });
    const visionModel = h('input', { class: 'input', id: 'ai-vision-model', value: ai.visionModel, maxlength: '100' });
        const visionPending = ai.capabilityAvailable && ai.capabilityAvailable.vision === false;
        const pw = h('input', { class: 'input', id: 'ai-pw', type: 'password', autocomplete: 'current-password', placeholder: 'Required to save any change below' });
        const aiErr = h('p', { class: 'field-error' });

        const save = async (extra, label) => {
          aiErr.textContent = '';
          if (!pw.value) { aiErr.textContent = 'Enter your admin password to save AI settings.'; return; }
          try {
            ai = await api('/ai/settings', { method: 'PATCH', body: { ...extra, currentPassword: pw.value } });
            pw.value = '';
            toast(`${label} saved`);
            pageSettings();
          } catch (e) { aiErr.textContent = e.message; toast(e.message, 'err'); }
        };

        return h('div', null,
          h('div', { class: 'form' },
            h('label', { class: 'check', for: 'ai-enabled' }, enabledBox, h('span', { text: `Enable ${ai.assistantName}` })),
            h('div', { class: 'field' }, h('label', { for: 'ai-name', text: 'Assistant name' }), name),
            h('div', { class: 'two' }, h('div', { class: 'field' }, h('label', { for: 'ai-provider', text: 'Provider' }), provider), h('div', { class: 'field' }, h('label', { for: 'ai-model', text: 'Model' }), model)),
            h('div', { class: 'field' }, h('label', { for: 'ai-key', text: 'API key' }), apiKey, h('p', { class: 'hint', text: ai.apiKeyConfigured ? 'Leave blank to keep the current key.' : 'The key is stored encrypted and is never shown again.' })),
            h('div', { class: 'field' }, h('label', { for: 'ai-sys', text: 'System instructions' }), sys),
            h('div', { class: 'field' }, h('label', { text: 'Tool permissions (read-only)' }),
              h('div', { class: 'perm-grid' },
                permRow('read_dashboard', 'Dashboard statistics'), permRow('read_orders', 'Orders'), permRow('read_services', 'Services'),
                permRow('read_customers', 'Customers'), permRow('read_wallet', 'Wallet transaction history'), permRow('read_audit', 'Audit logs'))),
            h('div', { class: 'field' }, h('label', { text: 'Optional capabilities (off by default)' }),
              h('div', { class: 'perm-grid' }, capRow('web_search', 'ai-cap-web-search', 'Web search'), capRow('vision', 'ai-cap-vision', 'Image analysis (vision)')),
              h('p', { class: 'hint', text: `Web search sends only a short text query to the search service chosen below, Exa or Groq (queries that look like personal data or secrets are refused), and is limited to a few searches per minute. Image analysis sends the images you attach to a chat message, once, to your AI provider to be described (they are resized in your browser and never saved). Search text is limited to ${ai.limits.webSearch.maxQueryChars} characters; images to ${ai.limits.vision.maxImages} per message, ${Math.round(ai.limits.vision.maxImageBytes / 1048576)} MB each. What comes back is treated as untrusted data and never gives ${ai.assistantName} extra authority.${visionPending ? ' Image analysis is not active in this version yet: its switch only records your choice.' : ''}` })),
            h('h3', { class: 'sub-title', text: 'Live web search' }),
      h('p', { class: 'hint', text: 'Switch on "Web search" above to let the assistant look things up on the public web and cite the real links it finds. Only a short text query leaves the server (queries that look like personal data or secrets are refused). The assistant never sees your keys, and search results are treated as untrusted data.' }),
      h('div', { class: 'field' }, h('label', { for: 'ai-search-provider', text: 'Search service' }), searchProvider),
      h('div', { class: 'field' }, h('label', { for: 'ai-exa-key', text: 'Exa API key' }), exaKey,
        h('p', { class: 'hint', text: sc.exaConfigured ? 'A key is saved. Leave blank to keep it, or type a new one to replace it. It is stored encrypted and never shown again.' : 'Create a key at dashboard.exa.ai/api-keys. It is stored encrypted and never shown again.' }),
        sc.exaConfigured ? h('label', { class: 'check', for: 'ai-exa-clear' }, exaClear, h('span', { text: 'Remove the saved Exa key' })) : null),
      h('div', { class: 'two' }, h('div', { class: 'field' }, h('label', { for: 'ai-search-results', text: `Results per search (${sLim.min}-${sLim.max})` }), maxResults), h('div', { class: 'field' }, h('label', { for: 'ai-search-chars', text: `Excerpt text limit (${cLim.min}-${cLim.max})` }), resultChars)),
      h('div', { class: 'field' }, h('label', { for: 'ai-vision-model', text: 'Vision model' }), visionModel, h('p', { class: 'hint', text: 'Only used to describe images. The main model above still does the reasoning and tool use.' })),
            h('div', { class: 'field' }, h('label', { text: 'Financial actions' }), h('span', { class: 'badge b-suspended', text: 'Permanently disabled' })),
            h('div', { class: 'field' }, h('label', { text: 'Write actions' }), h('span', { class: 'badge b-pending', text: 'Disabled for now' })),
            h('h3', { class: 'sub-title', text: 'Confirm to save' }),
            h('div', { class: 'field' }, pw), aiErr,
            h('button', { class: 'btn btn-primary', type: 'button', text: 'Save AI Assistant settings', onclick: () => save({
              enabled: enabledBox.checked, assistantName: name.value.trim(), provider: provider.value, model: model.value.trim(), visionModel: visionModel.value.trim(),
        searchProvider: searchProvider.value, searchMaxResults: Number(maxResults.value), searchResultChars: Number(resultChars.value),
              systemInstructions: sys.value.trim(), toolPermissions: Object.fromEntries(Object.entries(perms).map(([k, el]) => [k, el.checked])),
              ...(apiKey.value ? { apiKey: apiKey.value } : {}),
        ...(exaKey.value ? { exaApiKey: exaKey.value } : exaClear.checked ? { exaApiKey: null } : {}),
            }, 'AI Assistant settings') })));
      }

      view.replaceChildren(
        h('h1', { class: 'page-title', text: 'Settings' }),
        h('section', { class: 'card' }, h('h2', { class: 'card-title', text: 'General' }),
          h('div', { class: 'form' }, h('div', { class: 'field' }, h('label', { for: 's-name', text: 'Site name' }), siteName), h('div', { class: 'field' }, h('label', { for: 's-status', text: 'Site status' }), siteStatus),
            h('div', { class: 'field' }, h('label', { text: 'Currency' }), h('input', { class: 'input', value: s.currency, disabled: true })),
            h('div', { class: 'field' }, h('label', { for: 's-mindep', text: 'Minimum wallet deposit (₦)' }), minDep), gErr,
            h('button', { class: 'btn btn-primary', type: 'button', text: 'Save general settings', onclick: () => {
              const kobo = parseNaira(minDep.value); if (kobo === null) { gErr.textContent = 'Enter a valid deposit amount.'; return; }
              saveGroup({ siteName: siteName.value.trim(), siteStatus: siteStatus.value, minDepositKobo: kobo }, 'General settings', gErr);
            } }))),
        h('section', { class: 'card' }, h('h2', { class: 'card-title', text: 'Integrations' }), integrationsCard(),
          h('p', { class: 'hint', text: 'Keys are write-only: they are stored encrypted and never shown again. Each service\'s provider service ID and cost are set on the Services page.' })),
        h('section', { class: 'card' }, h('h2', { class: 'card-title', text: 'Security' }),
          kv('Admin email', d.security.adminEmail), kv('Last sign-in', when(d.security.lastLoginAt)), kv('Password changed', when(d.security.passwordChangedAt)), kv('Email code (OTP)', h('span', { class: 'badge b-completed', text: 'Always required' })),
          kv('Code delivery', yes(d.integrations.email.configured, d.integrations.email.transport, 'Not configured')),
          h('div', { class: 'form top-gap' }, h('div', { class: 'two' }, h('div', { class: 'field' }, h('label', { for: 's-otp', text: 'Code lifetime (minutes)' }), otp), h('div', { class: 'field' }, h('label', { for: 's-hours', text: 'Session length (hours)' }), hours)), sErr,
            h('button', { class: 'btn btn-secondary', type: 'button', text: 'Save security settings', onclick: () => {
              const a = Number(otp.value); const b = Number(hours.value);
              if (!Number.isInteger(a) || !Number.isInteger(b)) { sErr.textContent = 'Use whole numbers.'; return; }
              saveGroup({ otpTtlMinutes: a, adminSessionHours: b }, 'Security settings', sErr);
            } })),
          h('h3', { class: 'sub-title', text: 'Change admin password' }),
          h('div', { class: 'form' }, h('div', { class: 'field' }, h('label', { for: 'p-cur', text: 'Current password' }), cur), h('div', { class: 'field' }, h('label', { for: 'p-new', text: 'New password (12+ characters)' }), nw), h('div', { class: 'field' }, h('label', { for: 'p-new2', text: 'Repeat new password' }), nw2), pErr,
            h('button', { class: 'btn btn-secondary', type: 'button', text: 'Change password', onclick: async () => {
              pErr.textContent = '';
              if (nw.value.length < 12) return void (pErr.textContent = 'Use at least 12 characters.');
              if (nw.value !== nw2.value) return void (pErr.textContent = 'The new passwords do not match.');
              try { await api('/password', { method: 'POST', body: { currentPassword: cur.value, newPassword: nw.value } }); cur.value = nw.value = nw2.value = ''; toast('Password changed. Other devices were signed out.'); } catch (e) { pErr.textContent = e.message; toast(e.message, 'err'); }
            } }))),
        h('section', { class: 'card' }, h('h2', { class: 'card-title', text: 'AI Assistant' }), aiCard()),
        h('section', { class: 'card' }, h('h2', { class: 'card-title', text: 'Admin activity log' }), auditBox, auditMore));
      loadAudit();
    } catch (e) { fail(e); }
  }

  // ===================================================================
  //  EL ASSISTANT (chat)
  // ===================================================================
  async function pageAssistant() {
    let convId = null;
    let sending = false;
    const thread = h('div', { class: 'chat-thread', id: 'chat-thread' });
    const statusPill = h('span', { class: 'badge b-pending', text: 'Checking…' });
    const input = h('textarea', { class: 'input chat-input', id: 'chat-input', rows: '1', placeholder: 'Ask about orders, services, customers…', 'aria-label': 'Message' });
    const sendBtn = h('button', { class: 'btn btn-primary', type: 'button', text: 'Send' });
    const newChatBtn = h('button', { class: 'btn btn-secondary btn-sm', type: 'button', text: 'New chat' });
    const clearBtn = h('button', { class: 'btn btn-secondary btn-sm', type: 'button', text: 'Clear conversation' });
    const historyList = h('div', { class: 'list tight' });

    // ----- image attachments: offered only when an admin has switched image analysis on (see /ai/status) -----
    // The server enforces the real limits (3 images, 2 MB each, 2.5 MB together); these mirror them so the admin
    // gets a clear message before uploading. Every image is re-encoded here: that resizes it and drops all
    // metadata (camera, GPS location) before anything leaves the device.
    const MAX_ATTACH = 3;
    const ATTACH_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
    const TOTAL_BUDGET = 2.3 * 1048576;
    let attachments = []; // { mediaType, data (base64), bytes, thumb (data: URL) }: kept in memory only, cleared on send
    let preparing = false;
    const attachInput = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp', multiple: true, id: 'chat-attach-input', class: 'chat-attach-input', 'aria-label': 'Attach images' });
    const attachBtn = h('button', { class: 'btn btn-secondary btn-sm', type: 'button', id: 'chat-attach-btn', text: 'Attach image' });
    const attachNote = h('span', { class: 'hint', id: 'chat-attach-note' });
    const thumbs = h('div', { class: 'chat-thumbs', id: 'chat-thumbs' });
    const attachRow = h('div', { class: 'chat-attach-row', id: 'chat-attach-row', hidden: true }, attachBtn, attachNote, attachInput);

    function renderThumbs() {
      thumbs.replaceChildren(...attachments.map((a, i) => h('div', { class: 'chat-thumb' },
        h('img', { src: a.thumb, alt: `Attached image ${i + 1}` }),
        h('button', { type: 'button', class: 'chat-thumb-x', 'aria-label': `Remove image ${i + 1}`, text: '×', onclick: () => { attachments.splice(i, 1); renderThumbs(); } }))));
      attachNote.textContent = attachments.length ? `${attachments.length} of ${MAX_ATTACH} attached. Resized here, sent once to your AI provider, never saved.` : '';
    }
    const blobToBase64 = (blob) => new Promise((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(String(r.result).split(',')[1] || ''); r.onerror = () => reject(new Error('Could not read the image.')); r.readAsDataURL(blob); });
    const toBlob = (canvas, type, q) => new Promise((resolve) => canvas.toBlob(resolve, type, q));
    async function prepareImage(file, budget) {
      if (!ATTACH_TYPES.includes(file.type)) throw new Error('Only JPEG, PNG and WebP images can be attached.');
      if (file.size > 25 * 1048576) throw new Error('That image is too large (25 MB at most, before it is resized).');
      if (budget < 50 * 1024) throw new Error('The attached images are already at the size limit. Remove one first.');
      if (typeof createImageBitmap !== 'function') throw new Error('This browser cannot prepare images for upload.');
      let bmp;
      try { bmp = await createImageBitmap(file); } catch { throw new Error('That file could not be read as an image.'); }
      try {
        const tries = [...(file.type === 'image/png' ? [['image/png', 1600]] : []), ['image/jpeg', 1600, 0.85], ['image/jpeg', 1280, 0.75], ['image/jpeg', 1024, 0.65]];
        for (const [type, maxSide, q] of tries) {
          const scale = Math.min(1, maxSide / Math.max(bmp.width, bmp.height));
          const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(bmp.width * scale)); c.height = Math.max(1, Math.round(bmp.height * scale));
          const g = c.getContext('2d'); if (type === 'image/jpeg') { g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); } g.drawImage(bmp, 0, 0, c.width, c.height);
          const blob = await toBlob(c, type, q);
          if (blob && blob.size <= budget) {
            const ts = Math.min(1, 96 / Math.max(c.width, c.height)); const t = document.createElement('canvas'); t.width = Math.max(1, Math.round(c.width * ts)); t.height = Math.max(1, Math.round(c.height * ts));
            t.getContext('2d').drawImage(c, 0, 0, t.width, t.height);
            return { mediaType: type, data: await blobToBase64(blob), bytes: blob.size, thumb: t.toDataURL('image/jpeg', 0.7) };
          }
        }
        throw new Error('That image is still too large after resizing. Try a smaller one.');
      } finally { if (bmp.close) bmp.close(); }
    }
    attachBtn.addEventListener('click', () => attachInput.click());
    attachInput.addEventListener('change', async () => {
      const files = [...attachInput.files]; attachInput.value = '';
      preparing = true; sendBtn.disabled = true;
      for (const f of files) {
        if (attachments.length >= MAX_ATTACH) { toast(`You can attach up to ${MAX_ATTACH} images.`, 'err'); break; }
        try { attachments.push(await prepareImage(f, Math.min(1.5 * 1048576, TOTAL_BUDGET - attachments.reduce((n, a) => n + a.bytes, 0)))); renderThumbs(); } catch (e) { toast(e.message, 'err'); }
      }
      preparing = false; sendBtn.disabled = sending;
    });

    // Plain text with tappable links. Only http(s) URLs become links; they are built as DOM nodes (never HTML) and open in a
    // new tab with no opener or referrer. The server has already removed any link that was not a real search result.
    function fillBubble(el, text) {
      const s = String(text); const nodes = []; let last = 0; let m;
      const re = /https?:\/\/[^\s<>"'`()[\]{}]+/gi;
      while ((m = re.exec(s))) {
        const url = m[0].replace(/[.,;:!?*_]+$/, '');
        let href = null; try { const u = new URL(url); if (u.protocol === 'https:' || u.protocol === 'http:') href = u.href; } catch { /* not a link */ }
        if (!href) continue;
        if (m.index > last) nodes.push(document.createTextNode(s.slice(last, m.index)));
        nodes.push(h('a', { href, target: '_blank', rel: 'noopener noreferrer nofollow', class: 'chat-link', text: url }));
        last = m.index + url.length; re.lastIndex = last;
      }
      if (last < s.length) nodes.push(document.createTextNode(s.slice(last)));
      el.replaceChildren(...nodes);
    }
    function bubble(role, text) {
      const b = h('div', { class: 'chat-bubble' }); fillBubble(b, text);
      return h('div', { class: `chat-msg chat-${role}` }, b);
    }
    function scrollDown() { thread.scrollTop = thread.scrollHeight; }
    function addBubble(role, text) { thread.append(bubble(role, text)); scrollDown(); return thread.lastChild; }

    async function loadHistory() {
      historyList.replaceChildren(loading());
      try {
        const r = await api('/ai/conversations?limit=10');
        if (!r.conversations.length) { historyList.replaceChildren(h('p', { class: 'hint', text: 'No previous chats yet.' })); return; }
        historyList.replaceChildren(...r.conversations.map((c) => h('div', { class: 'ledger' },
          h('a', { href: '#/assistant', class: 'item-title break', text: c.title, onclick: (e) => { e.preventDefault(); openConversation(c.id); } }),
          h('button', { class: 'link-btn', type: 'button', text: 'Delete', onclick: async () => { await api(`/ai/conversations/${c.id}`, { method: 'DELETE' }); if (convId === c.id) startNew(); loadHistory(); } }))));
      } catch (e) { historyList.replaceChildren(h('p', { class: 'error-text', text: e.message })); }
    }

    async function openConversation(id) {
      convId = id; thread.replaceChildren(loading());
      try {
        const r = await api(`/ai/conversations/${id}/messages`);
        thread.replaceChildren();
        if (!r.messages.length) thread.append(bubble('assistant', "Hi, I'm EL. Ask me about your orders, services or customers."));
        r.messages.forEach((m) => addBubble(m.role, m.content));
      } catch (e) { thread.replaceChildren(h('div', { class: 'empty', text: e.message })); }
    }
    function startNew() { convId = null; thread.replaceChildren(bubble('assistant', "Hi, I'm EL. Ask me about your orders, services or customers.")); input.focus(); }

    async function send() {
      const text = input.value.trim() || (attachments.length ? 'Please describe the attached image(s).' : '');
      if (!text || sending || preparing) return;
      const images = attachments; attachments = []; renderThumbs(); // the images leave this page with this one message
      sending = true; sendBtn.disabled = true; input.value = ''; input.style.height = 'auto';
      addBubble('user', images.length ? `${text}\n\n[${images.length} image${images.length === 1 ? '' : 's'} attached]` : text);
      const working = addBubble('assistant', images.length ? 'Looking at the image…' : 'Thinking…');
      working.classList.add('chat-working');
      try {
        const r = images.length
          ? await api('/ai/chat/images', { method: 'POST', body: { message: text, conversationId: convId, images: images.map(({ mediaType, data }) => ({ mediaType, data })) } })
          : await api('/ai/chat', { method: 'POST', body: { message: text, conversationId: convId } });
        convId = r.conversationId || convId;
        working.classList.remove('chat-working');
        fillBubble(working.querySelector('.chat-bubble'), r.content);
        if (r.toolsUsed && r.toolsUsed.length) working.append(h('div', { class: 'chat-tool-note', text: `Checked: ${r.toolsUsed.join(', ').replaceAll('_', ' ')}` }));
        loadHistory();
      } catch (e) {
        working.classList.remove('chat-working');
        working.querySelector('.chat-bubble').textContent = e.message;
        working.classList.add('chat-error');
      }
      sending = false; sendBtn.disabled = false; input.focus();
    }
    sendBtn.addEventListener('click', send);
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
    input.addEventListener('input', () => { input.style.height = 'auto'; input.style.height = Math.min(140, input.scrollHeight) + 'px'; });
    newChatBtn.addEventListener('click', startNew);
    clearBtn.addEventListener('click', async () => {
      const ok = await confirmDialog({ title: 'Clear this conversation?', message: 'This chat will be deleted. This cannot be undone.', confirmLabel: 'Clear', danger: true });
      if (!ok) return;
      if (convId) { try { await api(`/ai/conversations/${convId}`, { method: 'DELETE' }); } catch { /* already gone */ } }
      startNew(); loadHistory();
    });

    view.replaceChildren(
      h('div', { class: 'page-head' }, h('h1', { class: 'page-title', text: 'EL Assistant' }), statusPill),
      h('p', { class: 'hint', text: 'Read-only for now: EL can look things up, but cannot change anything or move money.' }),
      h('section', { class: 'card chat-card' },
        h('div', { class: 'chat-toolbar' }, newChatBtn, clearBtn),
        thread,
        attachRow, thumbs,
        h('div', { class: 'chat-composer' }, input, sendBtn)),
      h('section', { class: 'card' }, h('h2', { class: 'card-title', text: 'Recent chats' }), historyList));

    try {
      const s = await api('/ai/status');
      statusPill.className = `badge ${s.enabled && s.configured ? 'b-active' : 'b-suspended'}`;
      statusPill.textContent = !s.enabled ? `${s.assistantName} is disabled` : !s.configured ? 'Not configured' : 'Online';
      if (!s.enabled || !s.configured) input.disabled = sendBtn.disabled = true;
      else if (s.vision) attachRow.removeAttribute('hidden');
    } catch { statusPill.textContent = 'Unavailable'; }
    startNew();
    loadHistory();
    input.focus();
  }


  // ===================================================================
  //  ROUTER + SHELL
  // ===================================================================
  const TITLES = { overview: 'Overview', services: 'Services', orders: 'Orders', customers: 'Customers', settings: 'Settings', assistant: 'EL Assistant' };
  function route() {
    const raw = window.location.hash.replace(/^#\/?/, '');
    const [path, query = ''] = raw.split('?');
    const [section = 'overview', id] = path.split('/');
    const params = new URLSearchParams(query);
    const name = TITLES[section] ? section : 'overview';
    document.querySelectorAll('.nav-link').forEach((a) => a.classList.toggle('is-current', a.dataset.route === name));
    $('#page-title').textContent = TITLES[name];
    document.title = `${TITLES[name]} · HYPERBOOSTER Admin`;
    closeNav();
    window.scrollTo(0, 0);
    if (name === 'services') return pageServices();
    if (name === 'orders') return /^\d+$/.test(id || '') ? pageOrderDetail(Number(id)) : pageOrders(params);
    if (name === 'customers') return /^\d+$/.test(id || '') ? pageCustomerDetail(Number(id)) : pageCustomers();
    if (name === 'settings') return pageSettings();
    if (name === 'assistant') return pageAssistant();
    return pageOverview();
  }

  function setNav(open) {
    document.body.classList.toggle('nav-open', open);
    $('#menu-btn').setAttribute('aria-expanded', String(open));
  }
  const closeNav = () => setNav(false);

  async function start() {
    $('#menu-btn').addEventListener('click', () => setNav(!document.body.classList.contains('nav-open')));
    $('#nav-close').addEventListener('click', closeNav);
    $('#nav-backdrop').addEventListener('click', closeNav);
    $('#logout-btn').addEventListener('click', async () => {
      try { await api('/logout', { method: 'POST', body: {} }); } catch { /* fall through to the login page */ }
      window.location.href = '/admin/login';
    });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeNav(); });
    try {
      const s = await api('/session');
      csrf = s.csrfToken; me = s.admin;
      $('#admin-email').textContent = me.email;
    } catch { return; }
    window.addEventListener('hashchange', route);
    route();
  }
  start();
})();
