'use strict';

// Integer-only maths: charge = ceil(quantity * pricePer1000 / 1000), in kobo.
// BigInt makes the multiplication exact even for very large values.
function calcCharge(pricePer1000Kobo, quantity) {
  return Number((BigInt(pricePer1000Kobo) * BigInt(quantity) + 999n) / 1000n);
}

// What customers are allowed to see. provider_service_id is deliberately NOT included:
// resellers keep their supplier private.
function publicService(row, tags = []) {
  return {
    id: row.id,
    name: row.name,
    platform: row.platform,
    serviceType: row.service_type,
    pricePer1000Kobo: row.price_per_1000_kobo,
    minQuantity: row.min_quantity,
    maxQuantity: row.max_quantity,
    refillAvailable: row.refill_available === 1,
    dropRate: row.drop_rate ?? null,
    averageCompletionTime: row.average_completion_time ?? null,
    description: row.description ?? null,
    notes: row.notes ? row.notes.split('\n').map((s) => s.trim()).filter(Boolean) : [],
    tags,
  };
}

function publicOrder(row) {
  return {
    id: row.id,
    serviceId: row.service_id,
    serviceName: row.service_name,
    platform: row.platform,
    serviceType: row.service_type,
    link: row.link,
    quantity: row.quantity,
    chargeKobo: row.charge_kobo,
    status: row.status,
    createdAt: row.created_at,
  };
}

module.exports = { calcCharge, publicService, publicOrder };
