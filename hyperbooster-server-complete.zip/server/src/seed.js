'use strict';

// Placeholder catalogue so the API can be tested. Prices are PLACEHOLDERS (NGN 1,000 per 1,000).
// provider_service_id is left empty until an SMM provider is connected.
const NOTES_ACCOUNT = 'Make sure the account is public.\nDo not change the username while the order is running.';
const NOTES_CHANNEL = 'Make sure the channel or group is accessible.\nDo not change the username while the order is running.';
const PRICE = 100000; // kobo per 1,000 = NGN 1,000

const CATALOGUE = [
  ['instagram', 'followers', 'Instagram Followers', 100, 100000, NOTES_ACCOUNT],
  ['instagram', 'likes', 'Instagram Likes', 50, 50000, NOTES_ACCOUNT],
  ['instagram', 'views', 'Instagram Views', 500, 1000000, NOTES_ACCOUNT],
  ['tiktok', 'followers', 'TikTok Followers', 100, 100000, NOTES_ACCOUNT],
  ['tiktok', 'likes', 'TikTok Likes', 50, 50000, NOTES_ACCOUNT],
  ['tiktok', 'views', 'TikTok Views', 500, 1000000, NOTES_ACCOUNT],
  ['facebook', 'followers', 'Facebook Followers', 100, 100000, NOTES_ACCOUNT],
  ['facebook', 'likes', 'Facebook Likes', 50, 50000, NOTES_ACCOUNT],
  ['youtube', 'subscribers', 'YouTube Subscribers', 100, 100000, NOTES_ACCOUNT],
  ['youtube', 'views', 'YouTube Views', 500, 1000000, NOTES_ACCOUNT],
  ['youtube', 'likes', 'YouTube Likes', 50, 50000, NOTES_ACCOUNT],
  ['telegram', 'members', 'Telegram Members', 100, 100000, NOTES_CHANNEL],
  ['telegram', 'views', 'Telegram Post Views', 500, 1000000, NOTES_CHANNEL],
  ['whatsapp', 'members', 'WhatsApp Channel Members', 100, 100000, NOTES_CHANNEL],
  ['twitter', 'followers', 'X (Twitter) Followers', 100, 100000, NOTES_ACCOUNT],
  ['twitter', 'likes', 'X (Twitter) Likes', 50, 50000, NOTES_ACCOUNT],
];

// Safe to run repeatedly: existing (platform, name) rows are left untouched. Returns rows inserted.
function seedServices(db) {
  const stmt = db.prepare(
    `INSERT OR IGNORE INTO services
       (name, platform, category, service_type, provider_service_id, price_per_1000_kobo, min_quantity, max_quantity,
        refill_available, drop_rate, average_completion_time, description, notes, is_active, sort_order)
     VALUES (?,?,?,?,NULL,?,?,?,0,NULL,'4 hours',?,?,1,?)`
  );
  let inserted = 0;
  CATALOGUE.forEach(([platform, type, name, min, max, notes], i) => {
    const r = stmt.run(name, platform, type.charAt(0).toUpperCase() + type.slice(1), type, PRICE, min, max, `${name}.`, notes, i);
    inserted += Number(r.changes);
  });
  return inserted;
}

module.exports = { seedServices };
