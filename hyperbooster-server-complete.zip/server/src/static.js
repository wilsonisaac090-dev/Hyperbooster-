'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { pipeline } = require('node:stream');

// Only these file types are ever served. Everything else (json, env, db, txt, md...) is a 404.
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.webmanifest': 'application/manifest+json',
};

function isInside(child, parent) {
  const rel = path.relative(parent, child);
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function notFound(res) {
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end('Not found');
}

async function serveStatic(cfg, req, res, pathname) {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405, { Allow: 'GET, HEAD', 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end('Method not allowed');
  }

  let rel;
  try {
    rel = decodeURIComponent(pathname);
  } catch {
    return notFound(res);
  }
  if (rel.includes('\0') || rel.includes('\\')) return notFound(res);
  if (rel.endsWith('/')) rel += 'index.html';

  const segments = rel.split('/').filter(Boolean);
  if (segments.some((s) => s.startsWith('.') || s === 'node_modules')) return notFound(res);

  const ext = path.extname(rel).toLowerCase();
  if (!MIME[ext]) return notFound(res);

  const root = cfg.staticDir;
  const full = path.resolve(root, '.' + rel);
  if (!isInside(full, root)) return notFound(res);

  // Never serve the backend's own folder or the database folder, even if they sit inside the web root.
  const protectedDirs = [cfg.serverDir];
  if (cfg.databasePath !== ':memory:') protectedDirs.push(path.dirname(cfg.databasePath));
  const blocked = protectedDirs.filter((d) => d !== root && isInside(d, root));

  let real;
  try {
    real = await fs.promises.realpath(full);
    const realRoot = await fs.promises.realpath(root);
    if (!isInside(real, realRoot)) return notFound(res); // symlink escape
    if (blocked.some((d) => isInside(real, d) || isInside(full, d))) return notFound(res);
    const stat = await fs.promises.stat(real);
    if (!stat.isFile()) return notFound(res);

    res.writeHead(200, {
      'Content-Type': MIME[ext],
      'Content-Length': stat.size,
      'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300',
    });
    if (req.method === 'HEAD') return res.end();
    pipeline(fs.createReadStream(real), res, (err) => {
      if (err) res.destroy();
    });
  } catch {
    if (!res.headersSent) notFound(res);
  }
}

module.exports = { serveStatic };
