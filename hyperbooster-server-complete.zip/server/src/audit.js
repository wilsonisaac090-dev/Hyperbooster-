'use strict';

// Every important admin action is written here. Call it inside the same transaction as the change,
// so a change can never be committed without its audit record.
function writeAudit(db, { admin = null, adminId, adminEmail, action, resourceType = null, resourceId = null, details = null, ip = null }) {
  db.prepare(
    `INSERT INTO audit_logs (admin_id, admin_email, action, resource_type, resource_id, details, ip)
     VALUES (?,?,?,?,?,?,?)`
  ).run(
    admin ? admin.id : adminId ?? null,
    admin ? admin.email : adminEmail ?? null,
    action,
    resourceType,
    resourceId === null || resourceId === undefined ? null : String(resourceId),
    details ? JSON.stringify(details) : null,
    ip
  );
}

module.exports = { writeAudit };
