'use strict';
const { encryptSecret, decryptSecret } = require('./ai/crypto');
const { writeAudit } = require('./audit');

// Admin-managed integration secrets (NigeriaSMM, Kora). Same AES-256-GCM helper and same key
// (AI_ENCRYPTION_KEY) as the existing EL Assistant key store — no new crypto invented.
//
// Precedence: a key saved through the Admin Panel wins; otherwise the environment variable that
// already worked keeps working unchanged (so existing deployments and tests are unaffected).
// Decryption happens only here, only server-side, only at the moment a provider request is built.
// Groq/EL Assistant keeps its existing store (ai_settings) rather than getting a second, duplicate one.
const NAMES = ['kora', 'provider'];

const getRow = (db, name) => db.prepare('SELECT * FROM integration_credentials WHERE name = ?').get(name);
const maskLast4 = (last4) => (last4 ? `••••••••••••${last4}` : null);

function storedSecret(cfg, db, name) {
  const row = getRow(db, name);
  return row ? decryptSecret(cfg.aiEncryptionKey, row.ciphertext) : null; // null if unreadable (wrong/ephemeral key)
}

// Full cfg clones whose kora/provider block carries the effective secret. Client modules keep their
// existing signatures and simply receive this instead of the raw cfg.
function withEffectiveKora(cfg, db) {
  const stored = storedSecret(cfg, db, 'kora');
  const secretKey = stored || cfg.kora.secretKey;
  return { ...cfg, kora: { ...cfg.kora, secretKey, configured: Boolean(secretKey) } };
}
function withEffectiveProvider(cfg, db) {
  const stored = storedSecret(cfg, db, 'provider');
  const apiKey = stored || cfg.provider.apiKey;
  return { ...cfg, provider: { ...cfg.provider, apiKey, configured: Boolean(apiKey) } };
}

function saveCredential(ctx, { name, apiKey, admin, ip }) {
  const { cfg, db } = ctx;
  if (!NAMES.includes(name)) throw new Error('unknown integration');
  db.prepare(
    `INSERT INTO integration_credentials (name, ciphertext, last4, updated_by_admin_id) VALUES (?,?,?,?)
     ON CONFLICT(name) DO UPDATE SET ciphertext = excluded.ciphertext, last4 = excluded.last4,
       updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), updated_by_admin_id = excluded.updated_by_admin_id`
  ).run(name, encryptSecret(cfg.aiEncryptionKey, apiKey), apiKey.slice(-4), admin.id);
  // The audit record names the integration and the LAST FOUR characters only — never the secret.
  writeAudit(db, { admin, action: 'INTEGRATION_KEY_UPDATED', resourceType: 'integration', resourceId: name, ip, details: { integration: name, last4: apiKey.slice(-4) } });
}

module.exports = { NAMES, getRow, maskLast4, withEffectiveKora, withEffectiveProvider, saveCredential };
