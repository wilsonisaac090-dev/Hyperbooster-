'use strict';

class ApiError extends Error {
  constructor(status, message, extra = {}) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.field = extra.field;
    this.headers = extra.headers;
  }
}

module.exports = { ApiError };
