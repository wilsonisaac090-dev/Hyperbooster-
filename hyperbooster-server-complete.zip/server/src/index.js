'use strict';
const path = require('node:path');

// Load server/.env if it exists (values already set in the real environment win).
try {
  process.loadEnvFile(path.join(__dirname, '..', '.env'));
} catch {
  /* no .env file: use defaults / real environment */
}

const { loadConfig } = require('./config');
const { createApp } = require('./app');

const cfg = loadConfig();
const app = createApp(cfg);

app.server.listen(cfg.port, cfg.host, () => {
  console.log(`HYPERBOOSTER server listening on http://${cfg.host}:${cfg.port} (${cfg.env})`);
  console.log(`Serving frontend from: ${cfg.staticDir}`);
  console.log(`Database: ${cfg.databasePath}`);
  if (cfg.isProd && !cfg.trustProxy) {
    console.log('Note: TRUST_PROXY is off. If you are behind a proxy/load balancer, set TRUST_PROXY=1.');
  }
});

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, async () => {
    console.log(`${signal} received, shutting down...`);
    await app.close();
    process.exit(0);
  });
}
