'use strict';
const { ApiError } = require('./errors');

const CONTROL = /[\u0000-\u001f\u007f]/;
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const bad = (message, field) => new ApiError(400, message, { field });

function normalizeEmail(value) {
  if (typeof value !== 'string') throw bad('Please enter a valid email address.', 'email');
  const email = value.trim().toLowerCase();
  if (email.length > 254 || !EMAIL.test(email)) throw bad('Please enter a valid email address.', 'email');
  return email;
}

function cleanFullName(value) {
  if (typeof value !== 'string') throw bad('Please enter your full name.', 'fullName');
  const name = value.trim().replace(/\s+/g, ' ');
  if (!name || name.length > 100 || CONTROL.test(name)) throw bad('Please enter your full name.', 'fullName');
  return name;
}

function checkPassword(value) {
  if (typeof value !== 'string' || value.length < 8) throw bad('Use at least 8 characters.', 'password');
  if (value.length > 128) throw bad('Password must be 128 characters or fewer.', 'password');
  return value;
}

// Accepts an http(s) link, a bare domain/path, or a @username.
function cleanLink(value) {
  const invalid = () => bad('Enter a valid account link or username.', 'link');
  if (typeof value !== 'string') throw invalid();
  const link = value.trim();
  if (link.length < 2 || link.length > 500 || /\s/.test(link) || CONTROL.test(link)) throw invalid();

  if (/^[a-z][a-z0-9+.-]*:/i.test(link)) {
    if (!/^https?:\/\//i.test(link)) throw invalid();
    try {
      new URL(link);
    } catch {
      throw invalid();
    }
    return link;
  }
  if (/^@?[A-Za-z0-9._-]{1,100}$/.test(link)) return link;
  if (/^[a-z0-9-]+(\.[a-z0-9-]+)*\.[a-z]{2,}(\/\S*)?$/i.test(link)) return link;
  throw invalid();
}

function parseInteger(value, field, label) {
  let n = value;
  if (typeof value === 'string' && /^\d{1,9}$/.test(value.trim())) n = Number(value.trim());
  if (typeof n !== 'number' || !Number.isSafeInteger(n) || n <= 0) throw bad(`Enter a valid ${label}.`, field);
  return n;
}

function parsePaging(searchParams) {
  const limit = Math.min(100, Math.max(1, Number.parseInt(searchParams.get('limit'), 10) || 20));
  const offset = Math.max(0, Number.parseInt(searchParams.get('offset'), 10) || 0);
  return { limit, offset };
}

module.exports = { normalizeEmail, cleanFullName, checkPassword, cleanLink, parseInteger, parsePaging };
