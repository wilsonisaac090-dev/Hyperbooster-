'use strict';
const { ApiError } = require('./errors');

// The ONLY place wallet balances change. Must be called inside transaction() (see db.js).
// Every change writes a ledger row, and idempotencyKey makes a repeat call a harmless no-op
// (used later so a payment webhook that arrives twice cannot credit twice).
function applyLedger(
  db,
  { userId, deltaKobo, type, referenceType = null, referenceId = null, idempotencyKey = null, description = null, adminId = null }
) {
  if (db.isTransaction === false) throw new Error('applyLedger must run inside a transaction');
  if (!Number.isSafeInteger(deltaKobo) || deltaKobo === 0) {
    throw new Error('applyLedger: deltaKobo must be a non-zero integer');
  }

  if (idempotencyKey) {
    const existing = db
      .prepare('SELECT id, balance_after_kobo FROM wallet_ledger WHERE idempotency_key = ?')
      .get(idempotencyKey);
    if (existing) return { duplicate: true, entryId: existing.id, balanceKobo: existing.balance_after_kobo };
  }

  const user = db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(userId);
  if (!user) throw new Error('applyLedger: unknown user');

  const next = user.balance_kobo + deltaKobo;
  if (next < 0) throw new ApiError(402, 'Insufficient wallet balance.');

  db.prepare("UPDATE users SET balance_kobo = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?").run(
    next,
    userId
  );
  const res = db
    .prepare(
      `INSERT INTO wallet_ledger
         (user_id, entry_type, amount_kobo, balance_after_kobo, reference_type, reference_id, idempotency_key, description, admin_id)
       VALUES (?,?,?,?,?,?,?,?,?)`
    )
    .run(userId, type, deltaKobo, next, referenceType, referenceId, idempotencyKey, description, adminId);

  return { duplicate: false, entryId: Number(res.lastInsertRowid), balanceKobo: next };
}

module.exports = { applyLedger };
