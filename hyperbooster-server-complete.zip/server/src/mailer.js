'use strict';

// Sends the admin one-time codes. Transports:
//   resend  - real delivery through the Resend HTTPS API (needs RESEND_API_KEY + MAIL_FROM on the server)
//   console - development only: prints the email (including the code) to the server log
//   memory  - tests
//   none    - nothing configured: admin sign-in is refused instead of silently skipping the code
function createMailer(cfg, fetchImpl = globalThis.fetch) {
  const outbox = [];
  return {
    outbox,
    async send({ to, subject, text }) {
      switch (cfg.mailTransport) {
        case 'memory':
          outbox.push({ to, subject, text });
          return;
        case 'console':
          console.log(`[mail:console] to=${to} subject=${subject}\n${text}`);
          return;
        case 'resend': {
          const res = await fetchImpl('https://api.resend.com/emails', {
            method: 'POST',
            headers: { Authorization: `Bearer ${cfg.resendApiKey}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({ from: cfg.mailFrom, to: [to], subject, text }),
          });
          if (!res.ok) throw new Error(`mail provider responded ${res.status}`);
          return;
        }
        default:
          throw new Error('mail transport is not configured');
      }
    },
  };
}

module.exports = { createMailer };
