'use strict';

// "Do not fabricate citations", enforced by the server rather than merely requested of the model. After a turn in
// which EL searched the web, every http(s) link in its final answer must be one of: a result the search really
// returned, a link the administrator themselves wrote, or one that came from another tool this turn. Any other
// link is replaced, so a made-up or remembered URL can never be shown to the admin as if it were a source.
//
// Limits, stated plainly: this checks links written with http:// or https://. It cannot tell whether the model
// summarised a real page faithfully, and a bare "example.com/page" without a scheme is not inspected.

const URL_RE = /https?:\/\/[^\s<>"'`()[\]{}]+/gi;
const TRAILING = /[.,;:!?*_]+$/;
const REMOVED = '[link removed: not from the search results]';

function normUrl(raw) {
  const trimmed = String(raw).replace(TRAILING, '');
  try {
    const u = new URL(trimmed);
    u.hash = '';
    return u.href.replace(/\/$/, '');
  } catch {
    return trimmed;
  }
}

function extractUrls(text) {
  return typeof text === 'string' ? (text.match(URL_RE) || []).map((u) => u.replace(TRAILING, '')) : [];
}

// allowed: a Set of normUrl() values.
function guardCitations(text, allowed) {
  if (typeof text !== 'string') return text;
  return text.replace(URL_RE, (match) => {
    const url = match.replace(TRAILING, '');
    const tail = match.slice(url.length);
    return allowed.has(normUrl(url)) ? match : `${REMOVED}${tail}`;
  });
}

module.exports = { guardCitations, extractUrls, normUrl, REMOVED };
