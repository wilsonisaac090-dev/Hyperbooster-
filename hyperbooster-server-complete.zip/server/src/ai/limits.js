'use strict';

// One place for EL Assistant safety limits, so no magic numbers are scattered through the code.

const MAX_IMAGES = 3;                    // images per chat request
const MAX_IMAGE_BYTES = 2 * 1024 * 1024; // ~2 MB per image, measured on the decoded bytes
// All images of one request together. Some Groq documentation caps a base64 request at 4 MB, and base64 inflates
// data by 4/3, so 2.5 MiB of image bytes (about 3.5 MB once encoded) keeps the whole request safely under that.
const MAX_TOTAL_IMAGE_BYTES = 2.5 * 1024 * 1024;
// The extra 64 KiB covers the JSON wrapper, media types and the message text.
const BODY_OVERHEAD_BYTES = 64 * 1024;

const AI_LIMITS = Object.freeze({
  // ---- Step 1: untrusted-content hardening ----
  // Any single text value inside a tool result is cut to this many characters before the model sees it.
  // Customer-entered fields (names, order links) are the usual source of long or hostile text.
  MAX_UNTRUSTED_STRING_CHARS: 500,

  // Failsafe on a whole tool result (as JSON text). Tools already clamp their row counts, so a normal
  // result never comes near this; if one ever does, the model gets a plain error instead.
  MAX_TOOL_RESULT_CHARS: 40000,

  // ---- Step 2: web search (the tool itself arrives in a later step) ----
  WEB_SEARCH_MAX_QUERY_CHARS: 200,
  WEB_SEARCH_RATE: Object.freeze({ max: 10, windowMs: 60 * 1000 }), // per admin
  // Cap on the search result text handed to EL (delivered as passages of at most MAX_UNTRUSTED_STRING_CHARS each).
  WEB_SEARCH_MAX_RESULT_CHARS: 6000,
  WEB_SEARCH_TIMEOUT_MS: 30 * 1000,
  WEB_SEARCH_REASONING_EFFORT: 'low', // Groq recommends low effort for browser search (quality vs. tokens/latency)
  // Groq's built-in browser search only works on these models; on any other model the tool is silently
  // ignored, so EL refuses to search rather than present un-searched model output as web results.
  WEB_SEARCH_SUPPORTED_MODELS: Object.freeze(['openai/gpt-oss-20b', 'openai/gpt-oss-120b', 'openai/gpt-oss-safeguard-20b']),

  // ---- Step 2 + 4: vision (image analysis) ----
  DEFAULT_VISION_MODEL: 'qwen/qwen3.8-27b', // must equal the v6 migration's column default
  VISION_MAX_IMAGES: MAX_IMAGES,            // Groq: at most 3 images per request
  VISION_MAX_IMAGE_BYTES: MAX_IMAGE_BYTES,
  VISION_MAX_TOTAL_IMAGE_BYTES: MAX_TOTAL_IMAGE_BYTES,
  // Only these are accepted; the file's own first bytes must agree with the type the browser declared.
  VISION_ALLOWED_TYPES: Object.freeze(['image/jpeg', 'image/png', 'image/webp']),
  // Largest JSON body the image-carrying chat route may accept (base64 of the total cap, plus a little for each
  // image's padding, plus the wrapper). Applies to that one route only; every other route keeps its 16 KB limit.
  VISION_MAX_BODY_BYTES: Math.ceil(MAX_TOTAL_IMAGE_BYTES / 3) * 4 + 16 + BODY_OVERHEAD_BYTES,
  VISION_RATE: Object.freeze({ max: 10, windowMs: 60 * 1000 }), // per admin; one analysis = one hit, however many images
  VISION_TIMEOUT_MS: 45 * 1000,
  VISION_MAX_OUTPUT_TOKENS: 1024,        // Groq's own vision example uses 1024; bounds cost per analysis
  // Groq documents "none" as instruct mode for Qwen 3.8: no hidden reasoning, so the description is not eaten by
  // thinking tokens, and it is faster and cheaper. Describing an image is not a reasoning task.
  VISION_REASONING_EFFORT: 'none',
  VISION_MAX_QUESTION_CHARS: 500,        // the admin's question is passed along so the description can focus on it
  VISION_MAX_DESCRIPTION_CHARS: 6000,    // cap on the description handed to EL (as passages of MAX_UNTRUSTED_STRING_CHARS)

  // ---- Step 5: live web search through Exa ----
  SEARCH_PROVIDERS: Object.freeze(['exa', 'groq']), // 'exa' = Exa Search API (default); 'groq' = Groq's built-in browser_search (kept)
  DEFAULT_SEARCH_PROVIDER: 'exa',                   // must equal the v7 migration's column default
  SEARCH_MAX_RESULTS: Object.freeze({ min: 1, max: 10, default: 5 }),          // results asked of Exa (admin setting)
  SEARCH_RESULT_CHARS: Object.freeze({ min: 500, max: 8000, default: 4000 }),  // total excerpt text handed to EL per search (admin setting)
  EXA_TIMEOUT_MS: 15 * 1000,             // Exa documents ~1 s for type "auto"
  EXA_MAX_TITLE_CHARS: 200,
  EXA_MAX_URL_CHARS: 500,
  EXA_MAX_ITEMS_PARSED: 25,              // never look at more than this many items of a response, whatever it claims
  EXA_KEY_PATTERN: /^[A-Za-z0-9._-]{8,300}$/, // letters, digits . _ - only: no whitespace or control characters can ever reach a header
});

module.exports = { AI_LIMITS };
