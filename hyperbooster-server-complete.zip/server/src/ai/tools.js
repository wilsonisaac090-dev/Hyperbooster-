'use strict';

// ===========================================================================
// EL Assistant's ENTIRE reach into HYPERBOOSTER. Every function here is read-only
// and returns a small, purpose-built shape — never a raw database row, and never
// anything from <never-send> below. The model cannot run SQL, call any function not
// listed here, or pass through an unrecognized name; assistant.js enforces that.
//
// `permission` names the on/off switch in ai_settings.tool_permissions that must be
// true for the tool to run (checked in assistant.js before the handler is called).
// There is no permission that unlocks money movement, secrets, or writes — those
// tools simply do not exist yet (see the project's Phase 1 read-only scope).
// ===========================================================================

const { webSearchTool } = require('./webSearch');

const NEVER_SEND = /password|password_hash|token|token_hash|secret|api_?key|ciphertext|csrf/i;

// Defence in depth: even though the handlers below only select safe columns, this
// strips anything secret-shaped from a tool result before it is stored or sent to
// the model, recursively, in case a handler is ever extended carelessly.
function stripSecrets(value) {
  if (Array.isArray(value)) return value.map(stripSecrets);
  if (value && typeof value === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(value)) if (!NEVER_SEND.test(k)) out[k] = stripSecrets(v);
    return out;
  }
  return value;
}

const naira = (kobo) => Math.round(kobo) / 100;
const clampLimit = (n, def, max) => { const v = Number.parseInt(n, 10); return Number.isFinite(v) && v > 0 ? Math.min(v, max) : def; };

function buildTools(db) {
  const orderRow = (o) => ({ id: o.id, customerEmail: o.email, serviceName: o.service_name, platform: o.platform, quantity: o.quantity, amountNaira: naira(o.charge_kobo), status: o.status, link: o.link, createdAt: o.created_at, updatedAt: o.updated_at });
  const ORDER_JOIN = 'FROM orders o JOIN users u ON u.id = o.user_id';

  return {
    get_dashboard_stats: {
      permission: 'read_dashboard',
      description: 'Overall platform statistics: customers, orders by status, wallet balance held, customer spending, active services.',
      parameters: { type: 'object', properties: {} },
      handler: () => {
        const one = (sql) => db.prepare(sql).get().n;
        const by = Object.fromEntries(db.prepare('SELECT status, COUNT(*) AS n FROM orders GROUP BY status').all().map((r) => [r.status, r.n]));
        return {
          totalCustomers: one('SELECT COUNT(*) AS n FROM users'),
          totalOrders: one('SELECT COUNT(*) AS n FROM orders'),
          ordersByStatus: { pending: by.pending || 0, processing: (by.processing || 0) + (by.in_progress || 0), completed: by.completed || 0, canceled: by.canceled || 0, failed: by.failed || 0 },
          totalWalletBalanceNaira: naira(one('SELECT COALESCE(SUM(balance_kobo),0) AS n FROM users')),
          totalCustomerSpendingNaira: naira(one("SELECT COALESCE(-SUM(amount_kobo),0) AS n FROM wallet_ledger WHERE entry_type IN ('order_charge','order_refund')")),
          activeServices: one('SELECT COUNT(*) AS n FROM services WHERE is_active = 1'),
          totalServices: one('SELECT COUNT(*) AS n FROM services'),
        };
      },
    },

    get_orders: {
      permission: 'read_orders',
      description: 'List recent orders, optionally filtered by status (pending, processing, completed, canceled, failed).',
      parameters: { type: 'object', properties: { status: { type: 'string', enum: ['pending', 'processing', 'completed', 'canceled', 'failed'] }, limit: { type: 'integer', description: 'Max rows, default 15, max 30' } } },
      handler: ({ status, limit } = {}) => {
        const where = status ? 'WHERE o.status = ?' : '';
        const rows = db.prepare(`SELECT o.*, u.email ${ORDER_JOIN} ${where} ORDER BY o.id DESC LIMIT ?`).all(...(status ? [status] : []), clampLimit(limit, 15, 30));
        return { orders: rows.map(orderRow) };
      },
    },

    get_pending_orders: {
      permission: 'read_orders',
      description: 'List orders that are still pending (not yet processing).',
      parameters: { type: 'object', properties: { limit: { type: 'integer' } } },
      handler: ({ limit } = {}) => ({ orders: db.prepare(`SELECT o.*, u.email ${ORDER_JOIN} WHERE o.status = 'pending' ORDER BY o.id ASC LIMIT ?`).all(clampLimit(limit, 15, 30)).map(orderRow) }),
    },

    get_order: {
      permission: 'read_orders',
      description: 'Full detail for one order by its ID, including its wallet ledger entries and any provider status.',
      parameters: { type: 'object', properties: { orderId: { type: 'integer' } }, required: ['orderId'] },
      handler: ({ orderId } = {}) => {
        const o = db.prepare(`SELECT o.*, u.email, u.full_name ${ORDER_JOIN} WHERE o.id = ?`).get(Number(orderId));
        if (!o) return { found: false };
        const ledger = db.prepare("SELECT entry_type, amount_kobo, created_at FROM wallet_ledger WHERE reference_type = 'order' AND reference_id = ? ORDER BY id").all(o.id);
        return { found: true, ...orderRow(o), customerName: o.full_name, pricePer1000Naira: naira(o.price_per_1000_kobo), providerOrderId: o.provider_order_id, providerStatus: o.provider_status, errorMessage: o.error_message, completedAt: o.completed_at,
          ledger: ledger.map((l) => ({ type: l.entry_type, amountNaira: naira(l.amount_kobo), at: l.created_at })) };
      },
    },

    get_services: {
      permission: 'read_services',
      description: 'List services, optionally filtered by platform or active/inactive status.',
      parameters: { type: 'object', properties: { platform: { type: 'string' }, status: { type: 'string', enum: ['active', 'inactive'] }, limit: { type: 'integer' } } },
      handler: ({ platform, status, limit } = {}) => {
        const where = []; const params = [];
        if (platform) { where.push('platform = ?'); params.push(String(platform).toLowerCase()); }
        if (status === 'active') where.push('is_active = 1'); if (status === 'inactive') where.push('is_active = 0');
        const clause = where.length ? 'WHERE ' + where.join(' AND ') : '';
        const rows = db.prepare(`SELECT id, name, platform, service_type, price_per_1000_kobo, min_quantity, max_quantity, is_active, (SELECT COUNT(*) FROM orders o WHERE o.service_id = services.id) AS order_count FROM services ${clause} ORDER BY platform, sort_order LIMIT ?`).all(...params, clampLimit(limit, 30, 60));
        return { services: rows.map((s) => ({ id: s.id, name: s.name, platform: s.platform, serviceType: s.service_type, pricePer1000Naira: naira(s.price_per_1000_kobo), minQuantity: s.min_quantity, maxQuantity: s.max_quantity, isActive: s.is_active === 1, orderCount: s.order_count })) };
      },
    },

    get_service: {
      permission: 'read_services',
      description: 'Full detail for one service by its ID (does not include the provider service ID or provider cost).',
      parameters: { type: 'object', properties: { serviceId: { type: 'integer' } }, required: ['serviceId'] },
      handler: ({ serviceId } = {}) => {
        const s = db.prepare('SELECT * FROM services WHERE id = ?').get(Number(serviceId));
        if (!s) return { found: false };
        return { found: true, id: s.id, name: s.name, platform: s.platform, serviceType: s.service_type, category: s.category, pricePer1000Naira: naira(s.price_per_1000_kobo), minQuantity: s.min_quantity, maxQuantity: s.max_quantity, refillAvailable: s.refill_available === 1, dropRate: s.drop_rate, averageCompletionTime: s.average_completion_time, isActive: s.is_active === 1, orderCount: db.prepare('SELECT COUNT(*) AS n FROM orders WHERE service_id = ?').get(s.id).n };
      },
    },

    get_customers: {
      permission: 'read_customers',
      description: 'List customers with their wallet balance and order count, optionally filtered by account status.',
      parameters: { type: 'object', properties: { status: { type: 'string', enum: ['active', 'suspended'] }, limit: { type: 'integer' } } },
      handler: ({ status, limit } = {}) => {
        const where = status ? 'WHERE status = ?' : '';
        const rows = db.prepare(`SELECT id, full_name, email, status, balance_kobo, created_at, (SELECT COUNT(*) FROM orders o WHERE o.user_id = users.id) AS order_count FROM users ${where} ORDER BY id DESC LIMIT ?`).all(...(status ? [status] : []), clampLimit(limit, 20, 40));
        return { customers: rows.map((c) => ({ id: c.id, name: c.full_name, email: c.email, status: c.status, walletBalanceNaira: naira(c.balance_kobo), orderCount: c.order_count, createdAt: c.created_at })) };
      },
    },

    get_customer: {
      permission: 'read_customers',
      description: 'Profile for one customer by their ID: account status, wallet balance, order count.',
      parameters: { type: 'object', properties: { customerId: { type: 'integer' } }, required: ['customerId'] },
      handler: ({ customerId } = {}) => {
        const c = db.prepare('SELECT * FROM users WHERE id = ?').get(Number(customerId));
        if (!c) return { found: false };
        return { found: true, id: c.id, name: c.full_name, email: c.email, status: c.status, walletBalanceNaira: naira(c.balance_kobo), orderCount: db.prepare('SELECT COUNT(*) AS n FROM orders WHERE user_id = ?').get(c.id).n, createdAt: c.created_at, lastLoginAt: c.last_login_at };
      },
    },

    get_customer_orders: {
      permission: 'read_customers',
      description: "One customer's recent orders, by their customer ID.",
      parameters: { type: 'object', properties: { customerId: { type: 'integer' }, limit: { type: 'integer' } }, required: ['customerId'] },
      handler: ({ customerId, limit } = {}) => {
        const c = db.prepare('SELECT id FROM users WHERE id = ?').get(Number(customerId));
        if (!c) return { found: false };
        const rows = db.prepare('SELECT id, service_name, platform, quantity, charge_kobo, status, created_at FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT ?').all(c.id, clampLimit(limit, 15, 30));
        return { found: true, orders: rows.map((o) => ({ id: o.id, serviceName: o.service_name, platform: o.platform, quantity: o.quantity, amountNaira: naira(o.charge_kobo), status: o.status, createdAt: o.created_at })) };
      },
    },

    get_customer_wallet_history: {
      permission: 'read_wallet',
      description: "One customer's wallet transaction history, by their customer ID.",
      parameters: { type: 'object', properties: { customerId: { type: 'integer' }, limit: { type: 'integer' } }, required: ['customerId'] },
      handler: ({ customerId, limit } = {}) => {
        const c = db.prepare('SELECT id, balance_kobo FROM users WHERE id = ?').get(Number(customerId));
        if (!c) return { found: false };
        const rows = db.prepare('SELECT entry_type, amount_kobo, balance_after_kobo, description, created_at FROM wallet_ledger WHERE user_id = ? ORDER BY id DESC LIMIT ?').all(c.id, clampLimit(limit, 20, 40));
        return { found: true, currentBalanceNaira: naira(c.balance_kobo), entries: rows.map((l) => ({ type: l.entry_type, amountNaira: naira(l.amount_kobo), balanceAfterNaira: naira(l.balance_after_kobo), description: l.description, at: l.created_at })) };
      },
    },

    get_system_status: {
      permission: 'read_dashboard',
      description: 'Whether the site is open or in maintenance, and whether payment/provider integrations are configured (never their credentials).',
      parameters: { type: 'object', properties: {} },
      handler: (_args, ctx) => {
        const row = db.prepare("SELECT value FROM settings WHERE key = 'site_status'").get();
        return { siteStatus: row ? row.value : 'open', koraConfigured: ctx.cfg.integrations.koraConfigured, providerApiConfigured: ctx.cfg.integrations.providerConfigured, emailConfigured: ctx.cfg.mailTransport !== 'none' };
      },
    },

    get_audit_logs: {
      permission: 'read_audit',
      description: 'Recent admin activity log entries, optionally filtered by action name (e.g. "order.status_change").',
      parameters: { type: 'object', properties: { action: { type: 'string' }, limit: { type: 'integer' } } },
      handler: ({ action, limit } = {}) => {
        const where = action ? 'WHERE action = ?' : '';
        const rows = db.prepare(`SELECT admin_email, action, resource_type, resource_id, created_at FROM audit_logs ${where} ORDER BY id DESC LIMIT ?`).all(...(action ? [action] : []), clampLimit(limit, 15, 30));
        return { entries: rows.map((r) => ({ admin: r.admin_email, action: r.action, resourceType: r.resource_type, resourceId: r.resource_id, at: r.created_at })) };
      },
    },

    get_recent_activity: {
      permission: 'read_dashboard',
      description: 'A quick combined snapshot of the newest orders and the newest admin actions.',
      parameters: { type: 'object', properties: {} },
      handler: () => ({
        recentOrders: db.prepare(`SELECT o.*, u.email ${ORDER_JOIN} ORDER BY o.id DESC LIMIT 5`).all().map(orderRow),
        recentAuditEntries: db.prepare('SELECT admin_email, action, created_at FROM audit_logs ORDER BY id DESC LIMIT 5').all().map((r) => ({ admin: r.admin_email, action: r.action, at: r.created_at })),
      }),
    },

    // The only tool that reaches outside the platform. Off unless the admin turns on the web_search capability.
    web_search: webSearchTool(),
  };
}

module.exports = { buildTools, stripSecrets };
