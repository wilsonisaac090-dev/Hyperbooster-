'use strict';
const { AI_LIMITS } = require('../limits');

// Exa Search API (https://exa.ai/docs/reference/search-api-guide-for-coding-agents, read 2026-10-12).
//   POST https://api.exa.ai/search      Authorization: Bearer <key>   (the docs also allow x-api-key)
//   body: { query, type: "auto", numResults, contents: { highlights: { maxCharacters } } }
//   response: { requestId, results: [{ id, title, url, publishedDate?, highlights: [string], image?, favicon? }], searchTime, costDollars }
// Highlights are the documented, recommended output for agents. summary and outputSchema are NOT used: each adds a
// language-model call (cost and latency) and would put a second model between the web and EL.
//
// This is the only file that talks to Exa. It can do exactly one thing: search for a text query. Errors are reduced to
// short codes so neither Exa's wording nor anything echoing the key can reach EL, the browser, or the audit log.
const ENDPOINT = 'https://api.exa.ai/search';

// Private, loopback and link-local hosts are never real search results; a link to one would be a lure aimed at
// whoever opens it from the admin panel.
const PRIVATE_HOST = /^(?:localhost|.*\.localhost|.*\.local|.*\.internal|.*\.lan|0\.0\.0\.0|127\.\d+\.\d+\.\d+|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(?:1[6-9]|2\d|3[01])\.\d+\.\d+|169\.254\.\d+\.\d+|\[?::1?\]?|\[?f[cd][0-9a-f]{2}:.*)$/i;

// Returns a clean absolute http(s) URL string, or null. Rejects other schemes (javascript:, data:, file:, ftp:...),
// embedded credentials, whitespace or control characters, private hosts and over-long values.
function safeUrl(value) {
  if (typeof value !== 'string') return null;
  const raw = value.trim();
  if (!raw || raw.length > AI_LIMITS.EXA_MAX_URL_CHARS) return null;
  if (/[\u0000-\u0020\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u2064\ufeff"'<>\\^`{|}]/.test(raw)) return null;
  let u;
  try { u = new URL(raw); } catch { return null; }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
  if (u.username || u.password) return null;
  if (!u.hostname || PRIVATE_HOST.test(u.hostname)) return null;
  if (u.href.length > AI_LIMITS.EXA_MAX_URL_CHARS) return null;
  return u.href;
}

// One search. Returns { results: [{ title, url, publishedDate?, highlights: [string] }] } (possibly empty).
async function search({ apiKey, query, maxResults, maxChars, timeoutMs = AI_LIMITS.EXA_TIMEOUT_MS }, fetchImpl = globalThis.fetch) {
  const n = Math.min(AI_LIMITS.SEARCH_MAX_RESULTS.max, Math.max(AI_LIMITS.SEARCH_MAX_RESULTS.min, Number.isInteger(maxResults) ? maxResults : AI_LIMITS.SEARCH_MAX_RESULTS.default));
  const total = Number.isInteger(maxChars) ? maxChars : AI_LIMITS.SEARCH_RESULT_CHARS.default;
  let res;
  try {
    res = await fetchImpl(ENDPOINT, {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query,
        type: 'auto',
        numResults: n,
        // The documented object form caps each result's excerpt; the total is also enforced again on our side.
        contents: { highlights: { maxCharacters: Math.max(100, Math.floor(total / n)) } },
      }),
      signal: AbortSignal.timeout(timeoutMs),
    });
  } catch (err) {
    throw new Error(err && (err.name === 'TimeoutError' || err.name === 'AbortError') ? 'timeout' : 'network');
  }
  if (res.status === 401 || res.status === 403) throw new Error('auth');
  if (res.status === 402) throw new Error('quota');
  if (res.status === 429) throw new Error('rate_limited');
  if (res.status === 400 || res.status === 404 || res.status === 422) throw new Error('rejected');
  if (!res.ok) throw new Error('provider_error');
  let data;
  try { data = await res.json(); } catch { throw new Error('provider_error'); }
  if (!data || typeof data !== 'object' || !Array.isArray(data.results)) throw new Error('provider_error');

  const results = [];
  for (const item of data.results.slice(0, AI_LIMITS.EXA_MAX_ITEMS_PARSED)) {
    if (!item || typeof item !== 'object') continue;
    const url = safeUrl(item.url);
    if (!url) continue; // no usable, safe link: no result (never a fabricated or "fixed" one)
    const highlights = Array.isArray(item.highlights) ? item.highlights.filter((h) => typeof h === 'string') : (typeof item.text === 'string' ? [item.text] : []);
    results.push({
      title: typeof item.title === 'string' ? item.title : '',
      url,
      ...(typeof item.publishedDate === 'string' && /^\d{4}-\d{2}-\d{2}/.test(item.publishedDate) ? { publishedDate: item.publishedDate.slice(0, 10) } : {}),
      highlights,
    });
  }
  return { results };
}

module.exports = { search, safeUrl, id: 'exa', ENDPOINT };
