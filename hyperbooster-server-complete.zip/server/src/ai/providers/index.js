'use strict';
const groq = require('./groq');

// Provider registry. Storing the provider name as a string in ai_settings (rather than code paths)
// is what lets the admin switch models/providers from Settings without any redeploy — adding a new
// provider later is just another module registered here, with the same chat({apiKey, model, messages, tools}) shape.
const PROVIDERS = { groq };

function getProvider(name) {
  return PROVIDERS[name] || null;
}

module.exports = { getProvider, PROVIDER_NAMES: Object.keys(PROVIDERS) };
