'use strict';
const crypto = require('node:crypto');

// AES-256-GCM. Format stored in the database: "iv:tag:ciphertext", each base64.
// The key never leaves the server (see config.js aiEncryptionKey) and is never logged.
function encryptSecret(key, plaintext) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const enc = Buffer.concat([cipher.update(String(plaintext), 'utf8'), cipher.final()]);
  return [iv.toString('base64'), cipher.getAuthTag().toString('base64'), enc.toString('base64')].join(':');
}

function decryptSecret(key, stored) {
  if (!stored) return null;
  const [ivB64, tagB64, dataB64] = String(stored).split(':');
  if (!ivB64 || !tagB64 || !dataB64) return null;
  try {
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(ivB64, 'base64'));
    decipher.setAuthTag(Buffer.from(tagB64, 'base64'));
    return Buffer.concat([decipher.update(Buffer.from(dataB64, 'base64')), decipher.final()]).toString('utf8');
  } catch {
    return null; // wrong key (e.g. server restarted without AI_ENCRYPTION_KEY) or corrupted value
  }
}

module.exports = { encryptSecret, decryptSecret };
