'use strict';
const crypto = require('node:crypto');
const { promisify } = require('node:util');

const scrypt = promisify(crypto.scrypt);

// scrypt cost parameters (OWASP-recommended profile). They are stored inside every hash,
// so they can be raised later without breaking existing passwords.
const SCRYPT = { N: 32768, r: 8, p: 3, keylen: 64 };
const MAXMEM = 256 * 1024 * 1024;

async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(password, salt, SCRYPT.keylen, { N: SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p, maxmem: MAXMEM });
  return ['scrypt', SCRYPT.N, SCRYPT.r, SCRYPT.p, salt.toString('base64'), key.toString('base64')].join('$');
}

async function verifyPassword(password, stored) {
  const parts = String(stored).split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const [N, r, p] = parts.slice(1, 4).map(Number);
  if (![N, r, p].every(Number.isInteger) || N < 2 || N > 2 ** 20 || r < 1 || p < 1) return false;
  const salt = Buffer.from(parts[4], 'base64');
  const expected = Buffer.from(parts[5], 'base64');
  if (!expected.length) return false;
  const key = await scrypt(password, salt, expected.length, { N, r, p, maxmem: MAXMEM });
  return crypto.timingSafeEqual(key, expected);
}

// Login for an unknown email still burns the same CPU time, so response timing
// does not reveal which emails have accounts.
let dummyHash;
async function verifyDummy(password) {
  dummyHash ??= await hashPassword('hyperbooster-timing-equalizer');
  await verifyPassword(password, dummyHash);
}

function sha256(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function newSessionToken() {
  const token = crypto.randomBytes(32).toString('base64url');
  return { token, hash: sha256(token) };
}

// Small in-memory fixed-window limiter. Fine for a single server process.
// If you ever run several instances, move this to Redis or the database.
class RateLimiter {
  constructor() {
    this.entries = new Map();
  }

  hit(key, max, windowMs, now = Date.now()) {
    let e = this.entries.get(key);
    if (!e || e.reset <= now) {
      e = { count: 0, reset: now + windowMs };
      this.entries.set(key, e);
    }
    e.count += 1;
    if (this.entries.size > 100000) this.sweep(now);
    return { allowed: e.count <= max, retryAfterSec: Math.max(1, Math.ceil((e.reset - now) / 1000)) };
  }

  isBlocked(key, max, now = Date.now()) {
    const e = this.entries.get(key);
    if (!e || e.reset <= now) return { blocked: false, retryAfterSec: 0 };
    return { blocked: e.count >= max, retryAfterSec: Math.max(1, Math.ceil((e.reset - now) / 1000)) };
  }

  clear(key) {
    this.entries.delete(key);
  }

  sweep(now = Date.now()) {
    for (const [k, e] of this.entries) if (e.reset <= now) this.entries.delete(k);
  }
}

module.exports = { hashPassword, verifyPassword, verifyDummy, sha256, newSessionToken, RateLimiter };
