'use strict';
const { ApiError } = require('./errors');
const { readJson } = require('./http');
const { hashPassword, verifyPassword, verifyDummy } = require('./security');
const { transaction } = require('./db');
const { applyLedger } = require('./wallet');
const { calcCharge, publicService, publicOrder } = require('./pricing');
const { createSession, destroySession, pruneExpiredSessions } = require('./auth');
const V = require('./validate');
const { getSettings } = require('./settings');
const { createDeposit, resolveByQuery, depositPayload } = require('./kora/deposits');
const { verifyKoraSignature } = require('./kora/signature');
const { forwardOrderToProvider } = require('./provider/orders');
const { withEffectiveKora } = require('./credentials');

const CURRENCY = 'NGN';

const userPayload = (u) => ({ id: u.id, fullName: u.full_name, email: u.email, role: u.role });
const walletPayload = (u) => ({ balanceKobo: u.balance_kobo, currency: CURRENCY });
const tooMany = (rl, msg = 'Too many attempts. Please try again later.') =>
  new ApiError(429, msg, { headers: { 'Retry-After': String(rl.retryAfterSec) } });

function buildRoutes(ctx) {
  const { cfg, db, limiter } = ctx;

  function findActiveService(serviceId, quantity) {
    const svc = db.prepare('SELECT * FROM services WHERE id = ? AND is_active = 1').get(serviceId);
    if (!svc) throw new ApiError(404, 'This service is not available.', { field: 'serviceId' });
    if (quantity < svc.min_quantity || quantity > svc.max_quantity) {
      throw new ApiError(
        400,
        `Quantity must be between ${svc.min_quantity.toLocaleString('en-US')} and ${svc.max_quantity.toLocaleString('en-US')}.`,
        { field: 'quantity' }
      );
    }
    return svc;
  }

  return [
    // ---------- health ----------
    {
      method: 'GET',
      re: /^\/api\/health$/,
      auth: 'none',
      handler: () => {
        db.prepare('SELECT 1').get();
        return { body: { ok: true } };
      },
    },

    // ---------- auth ----------
    {
      method: 'POST',
      re: /^\/api\/register$/,
      auth: 'none',
      handler: async ({ req, ip }) => {
        const l = cfg.limits.registerPerIp;
        const rl = limiter.hit(`register:${ip}`, l.max, l.windowMs);
        if (!rl.allowed) throw tooMany(rl, 'Too many sign-ups from this network. Please try again later.');

        const body = await readJson(req);
        const fullName = V.cleanFullName(body.fullName);
        const email = V.normalizeEmail(body.email);
        const password = V.checkPassword(body.password);
        const passwordHash = await hashPassword(password);

        let userId;
        try {
          const r = db
            .prepare('INSERT INTO users (email, full_name, password_hash) VALUES (?,?,?)')
            .run(email, fullName, passwordHash);
          userId = Number(r.lastInsertRowid);
        } catch (err) {
          if (/UNIQUE constraint failed/i.test(String(err.message))) {
            throw new ApiError(409, 'An account with this email already exists.', { field: 'email' });
          }
          throw err;
        }

        const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
        const cookie = createSession(ctx, req, userId, ip);
        return {
          status: 201,
          headers: { 'Set-Cookie': cookie },
          body: { user: userPayload(user), wallet: walletPayload(user) },
        };
      },
    },
    {
      method: 'POST',
      re: /^\/api\/login$/,
      auth: 'none',
      handler: async ({ req, ip }) => {
        const ipLimit = cfg.limits.loginPerIp;
        const rlIp = limiter.hit(`login:ip:${ip}`, ipLimit.max, ipLimit.windowMs);
        if (!rlIp.allowed) throw tooMany(rlIp);

        const body = await readJson(req);
        if (typeof body.email !== 'string' || typeof body.password !== 'string' || !body.email || !body.password) {
          throw new ApiError(400, 'Email and password are required.');
        }
        const email = body.email.trim().toLowerCase().slice(0, 254);
        const password = body.password.slice(0, 129);

        const acctLimit = cfg.limits.loginPerAccount;
        const acctKey = `login:acct:${ip}|${email}`;
        const blocked = limiter.isBlocked(acctKey, acctLimit.max);
        if (blocked.blocked) throw tooMany(blocked);

        const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
        let ok = false;
        if (user) ok = await verifyPassword(password, user.password_hash);
        else await verifyDummy(password);

        if (!ok) {
          limiter.hit(acctKey, acctLimit.max, acctLimit.windowMs);
          throw new ApiError(401, 'Invalid email or password.');
        }
        if (user.status !== 'active') throw new ApiError(403, 'This account has been suspended.');

        limiter.clear(acctKey);
        pruneExpiredSessions(db);
        db.prepare("UPDATE users SET last_login_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?").run(user.id);
        const cookie = createSession(ctx, req, user.id, ip);
        return { headers: { 'Set-Cookie': cookie }, body: { user: userPayload(user), wallet: walletPayload(user) } };
      },
    },
    {
      method: 'POST',
      re: /^\/api\/logout$/,
      auth: 'none',
      handler: ({ req }) => ({ headers: { 'Set-Cookie': destroySession(ctx, req) }, body: { ok: true } }),
    },
    {
      method: 'GET',
      re: /^\/api\/me$/,
      auth: 'required',
      handler: ({ user }) => ({ body: { user: userPayload(user), wallet: walletPayload(user) } }),
    },

    // ---------- wallet ----------
    {
      method: 'GET',
      re: /^\/api\/wallet$/,
      auth: 'required',
      handler: ({ user, url }) => {
        const { limit, offset } = V.parsePaging(url.searchParams);
        const rows = db
          .prepare(
            `SELECT id, entry_type, amount_kobo, balance_after_kobo, description, created_at
               FROM wallet_ledger WHERE user_id = ? ORDER BY id DESC LIMIT ? OFFSET ?`
          )
          .all(user.id, limit, offset);
        return {
          body: {
            ...walletPayload(user),
            entries: rows.map((r) => ({
              id: r.id,
              type: r.entry_type,
              amountKobo: r.amount_kobo,
              balanceAfterKobo: r.balance_after_kobo,
              description: r.description,
              createdAt: r.created_at,
            })),
          },
        };
      },
    },

    // ---------- public settings (minimal: only what the deposit form needs to show honestly) ----------
    {
      method: 'GET',
      re: /^\/api\/settings$/,
      auth: 'none',
      handler: () => {
        const { minDepositKobo, currency } = getSettings(db);
        return { body: { minDepositKobo, currency } };
      },
    },

    // ---------- deposits (Kora) ----------
    {
      method: 'POST',
      re: /^\/api\/deposits$/,
      auth: 'required',
      handler: async ({ req, user, ip }) => {
        const l = cfg.limits.depositCreatePerUser;
        const rlUser = limiter.hit(`deposit:user:${user.id}`, l.max, l.windowMs);
        if (!rlUser.allowed) throw new ApiError(429, 'Too many deposit attempts. Please wait a moment.', { headers: { 'Retry-After': String(rlUser.retryAfterSec) } });
        const li = cfg.limits.depositCreatePerIp;
        const rlIp = limiter.hit(`deposit:ip:${ip}`, li.max, li.windowMs);
        if (!rlIp.allowed) throw new ApiError(429, 'Too many deposit attempts. Please wait a moment.', { headers: { 'Retry-After': String(rlIp.retryAfterSec) } });

        const body = await readJson(req);
        const amount = V.parseInteger(body.amountKobo, 'amountKobo', 'amount');
        const { reference, checkoutUrl } = await createDeposit(ctx, { req, user, amountKobo: amount, ip });
        return { status: 201, body: { reference, checkoutUrl } };
      },
    },
    {
      method: 'GET',
      re: /^\/api\/deposits\/([A-Z0-9-]{1,80})$/i,
      auth: 'required',
      handler: async ({ match, user, ip }) => {
        const reference = match[1];
        const deposit = db.prepare('SELECT * FROM deposits WHERE reference = ? AND user_id = ?').get(reference, user.id);
        if (!deposit) throw new ApiError(404, 'Deposit not found.');
        // If the customer lands back before the webhook arrives, self-heal with one live check.
        if (deposit.status === 'pending') {
          const { deposit: updated } = await resolveByQuery(ctx, deposit, { source: 'status_check', ip });
          return { body: { deposit: depositPayload(updated), wallet: { balanceKobo: db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(user.id).balance_kobo, currency: CURRENCY } } };
        }
        return { body: { deposit: depositPayload(deposit), wallet: { balanceKobo: db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(user.id).balance_kobo, currency: CURRENCY } } };
      },
    },

    // ---------- services (public) ----------
    {
      method: 'GET',
      re: /^\/api\/services$/,
      auth: 'none',
      handler: ({ url }) => {
        const platform = url.searchParams.get('platform');
        let rows;
        if (platform !== null) {
          if (!/^[a-z0-9_-]{1,32}$/.test(platform)) throw new ApiError(400, 'Invalid platform.', { field: 'platform' });
          rows = db
            .prepare('SELECT * FROM services WHERE is_active = 1 AND platform = ? ORDER BY sort_order, id')
            .all(platform);
        } else {
          rows = db.prepare('SELECT * FROM services WHERE is_active = 1 ORDER BY platform, sort_order, id').all();
        }
        const tagMap = new Map();
        if (rows.length) {
          db.prepare(`SELECT l.service_id, t.name FROM service_tag_links l JOIN service_tags t ON t.id = l.tag_id WHERE l.service_id IN (${rows.map(() => '?').join(',')}) ORDER BY t.name COLLATE NOCASE`)
            .all(...rows.map((r) => r.id))
            .forEach((t) => tagMap.set(t.service_id, [...(tagMap.get(t.service_id) || []), t.name]));
        }
        return { body: { currency: CURRENCY, services: rows.map((r) => publicService(r, tagMap.get(r.id) || [])) } };
      },
    },

    // ---------- Kora webhook (public: no session, authenticated by HMAC signature instead) ----------
    {
      method: 'POST',
      re: /^\/api\/webhooks\/kora$/,
      auth: 'none',
      handler: async ({ req, ip }) => {
        const rl = limiter.hit(`kora-webhook:${ip}`, cfg.limits.koraWebhookPerIp.max, cfg.limits.koraWebhookPerIp.windowMs);
        if (!rl.allowed) throw new ApiError(429, 'Too many requests.');
        const kcfg = withEffectiveKora(cfg, db);
        if (!kcfg.kora.configured) throw new ApiError(503, 'Not configured.');

        const body = await readJson(req, 64 * 1024);
        if (!body || typeof body.event !== 'string' || !body.data || typeof body.data !== 'object') {
          throw new ApiError(400, 'Malformed payload.');
        }
        const signature = req.headers['x-korapay-signature'];
        if (!verifyKoraSignature(kcfg.kora.secretKey, body.data, signature)) {
          throw new ApiError(401, 'Invalid signature.');
        }

        const reference = body.data.reference;
        if (typeof reference !== 'string' || !reference) return { body: { received: true } };
        const deposit = db.prepare("SELECT * FROM deposits WHERE reference = ? AND gateway = 'kora'").get(reference);
        if (!deposit) return { body: { received: true } }; // unknown/foreign reference: quietly acknowledge, nothing to do

        if (body.event === 'charge.success' || body.event === 'charge.failed') {
          // Never trust the webhook's own amount for crediting: always re-verify server-to-server
          // (Kora's own guidance) via the Charge Query endpoint before touching the wallet.
          const { queryFailed } = await resolveByQuery(ctx, deposit, { source: 'webhook', ip });
          if (queryFailed) throw new ApiError(502, 'Could not verify with Kora.'); // triggers a Kora retry later
        }
        return { body: { received: true } };
      },
    },

    // ---------- orders ----------
    {
      method: 'POST',
      re: /^\/api\/orders\/quote$/,
      auth: 'optional',
      handler: async ({ req, user }) => {
        const body = await readJson(req);
        const serviceId = V.parseInteger(body.serviceId, 'serviceId', 'service');
        const quantity = V.parseInteger(body.quantity, 'quantity', 'quantity');
        const svc = findActiveService(serviceId, quantity);
        const chargeKobo = calcCharge(svc.price_per_1000_kobo, quantity);
        return {
          body: {
            quote: {
              serviceId: svc.id,
              quantity,
              pricePer1000Kobo: svc.price_per_1000_kobo,
              chargeKobo,
              currency: CURRENCY,
              averageCompletionTime: svc.average_completion_time ?? null,
            },
            canAfford: user ? user.balance_kobo >= chargeKobo : undefined,
          },
        };
      },
    },
    {
      method: 'POST',
      re: /^\/api\/orders$/,
      auth: 'required',
      handler: async ({ req, user }) => {
        if (getSettings(db).siteStatus === 'maintenance') {
          throw new ApiError(503, 'Ordering is temporarily paused for maintenance. Please try again soon.');
        }
        const l = cfg.limits.orderPerUser;
        const rl = limiter.hit(`order:${user.id}`, l.max, l.windowMs);
        if (!rl.allowed) throw tooMany(rl, 'You are placing orders too quickly. Please wait a moment.');

        const body = await readJson(req);
        const serviceId = V.parseInteger(body.serviceId, 'serviceId', 'service');
        const quantity = V.parseInteger(body.quantity, 'quantity', 'quantity');
        const link = V.cleanLink(body.link);

        // Everything below happens in ONE database transaction. If the balance is too low the
        // whole thing (including the inserted order row) is rolled back: no free orders, ever.
        const { order, balanceKobo } = transaction(db, () => {
          const svc = findActiveService(serviceId, quantity);
          const chargeKobo = calcCharge(svc.price_per_1000_kobo, quantity);
          const ins = db
            .prepare(
              `INSERT INTO orders
                 (user_id, service_id, service_name, platform, service_type, link, quantity, price_per_1000_kobo, charge_kobo, status)
               VALUES (?,?,?,?,?,?,?,?,?,'pending')`
            )
            .run(user.id, svc.id, svc.name, svc.platform, svc.service_type, link, quantity, svc.price_per_1000_kobo, chargeKobo);
          const orderId = Number(ins.lastInsertRowid);

          let balance;
          if (chargeKobo > 0) {
            balance = applyLedger(db, {
              userId: user.id,
              deltaKobo: -chargeKobo,
              type: 'order_charge',
              referenceType: 'order',
              referenceId: orderId,
              idempotencyKey: `order_charge:${orderId}`,
              description: `Order #${orderId} - ${svc.name}`,
            }).balanceKobo;
          } else {
            balance = db.prepare('SELECT balance_kobo FROM users WHERE id = ?').get(user.id).balance_kobo;
          }
          return { order: db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId), balanceKobo: balance };
        });

        // The DB transaction above already committed (order row + wallet charge). Forwarding to the
        // provider is a network call, so it happens here, outside that transaction, with its own
        // compensating refund-exactly-once if the provider rejects it (see provider/orders.js).
        const forward = await forwardOrderToProvider(ctx, order.id);
        const finalOrder = forward.forwarded || forward.failed ? db.prepare('SELECT * FROM orders WHERE id = ?').get(order.id) : order;
        const finalBalance = forward.failed && forward.refunded ? forward.balanceKobo : balanceKobo;
        return { status: 201, body: { order: publicOrder(finalOrder), wallet: { balanceKobo: finalBalance, currency: CURRENCY } } };
      },
    },
    {
      method: 'GET',
      re: /^\/api\/orders$/,
      auth: 'required',
      handler: ({ user, url }) => {
        const { limit, offset } = V.parsePaging(url.searchParams);
        const rows = db
          .prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT ? OFFSET ?')
          .all(user.id, limit, offset);
        return { body: { orders: rows.map(publicOrder) } };
      },
    },
    {
      method: 'GET',
      re: /^\/api\/orders\/(\d{1,12})$/,
      auth: 'required',
      handler: ({ user, match }) => {
        const row = db.prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?').get(Number(match[1]), user.id);
        if (!row) throw new ApiError(404, 'Order not found.');
        return { body: { order: publicOrder(row) } };
      },
    },
  ];
}

module.exports = { buildRoutes };
