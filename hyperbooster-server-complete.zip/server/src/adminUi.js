'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { getAdminSession } = require('./admin/auth');

const UI_DIR = path.resolve(__dirname, '..', 'admin-ui');
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' };

// Which admin files exist, and which of them need a valid admin session.
const FILES = {
  '/admin/login': { file: 'login.html', gated: false },
  '/admin/assets/login.js': { file: 'login.js', gated: false },
  '/admin/assets/admin.css': { file: 'admin.css', gated: false },
  '/admin': { file: 'app.html', gated: true },
  '/admin/': { file: 'app.html', gated: true },
  '/admin/assets/admin.js': { file: 'admin.js', gated: true },
};

function redirect(res, to) {
  res.writeHead(302, { Location: to, 'Cache-Control': 'no-store' });
  res.end();
}

// The admin app itself is only ever sent to a signed-in admin. Anyone else is redirected to the admin login.
function serveAdminUi(ctx, req, res, pathname) {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405, { Allow: 'GET, HEAD' });
    return res.end();
  }
  const entry = FILES[pathname];
  if (!entry) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end('Not found');
  }
  const session = getAdminSession(ctx, req);
  if (pathname === '/admin/login' && session) return redirect(res, '/admin');
  if (entry.gated && !session) {
    if (entry.file === 'admin.js') {
      res.writeHead(401, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Unauthorized');
    }
    return redirect(res, '/admin/login');
  }
  let body;
  try {
    body = fs.readFileSync(path.join(UI_DIR, entry.file));
  } catch {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end('Not found');
  }
  res.writeHead(200, {
    'Content-Type': TYPES[path.extname(entry.file)],
    'Content-Length': body.length,
    'Cache-Control': 'no-store',
    'X-Robots-Tag': 'noindex, nofollow',
  });
  res.end(req.method === 'HEAD' ? undefined : body);
}

module.exports = { serveAdminUi };
