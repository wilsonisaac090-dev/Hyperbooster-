'use strict';
const { ApiError } = require('./errors');

const MAX_BODY_BYTES = 16 * 1024;

function applySecurityHeaders(cfg, res) {
  const scriptSrc = cfg.allowInlineScripts ? "'self' 'unsafe-inline'" : "'self'";
  res.setHeader(
    'Content-Security-Policy',
    [
      "default-src 'self'",
      `script-src ${scriptSrc}`,
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data:",
      "font-src 'self'",
      "connect-src 'self'",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      "frame-ancestors 'none'",
    ].join('; ')
  );
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  if (cfg.cookieSecure) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
}

function sendJson(res, status, body, extraHeaders = {}) {
  const payload = body === undefined ? '' : JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(payload),
    'Cache-Control': 'no-store',
    ...extraHeaders,
  });
  res.end(payload);
}

function readJson(req, limit = MAX_BODY_BYTES) {
  return new Promise((resolve, reject) => {
    const type = String(req.headers['content-type'] || '').toLowerCase();
    if (!type.startsWith('application/json')) {
      req.resume();
      return reject(new ApiError(415, 'Content-Type must be application/json.'));
    }
    const declared = Number(req.headers['content-length']);
    if (Number.isFinite(declared) && declared > limit) {
      req.resume();
      return reject(new ApiError(413, 'Request body too large.'));
    }

    const chunks = [];
    let size = 0;
    let failed = false;

    req.on('data', (chunk) => {
      if (failed) return; // keep draining, discard
      size += chunk.length;
      if (size > limit) {
        failed = true;
        chunks.length = 0;
        reject(new ApiError(413, 'Request body too large.'));
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (failed) return;
      try {
        const text = Buffer.concat(chunks).toString('utf8');
        const parsed = text ? JSON.parse(text) : {};
        if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('not an object');
        resolve(parsed);
      } catch {
        reject(new ApiError(400, 'Request body must be a valid JSON object.'));
      }
    });
    req.on('error', () => reject(new ApiError(400, 'Could not read request body.')));
  });
}

function parseCookies(header) {
  const out = Object.create(null);
  if (!header) return out;
  for (const part of String(header).split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    const name = part.slice(0, i).trim();
    const value = part.slice(i + 1).trim();
    if (name && !(name in out)) out[name] = value;
  }
  return out;
}

function serializeCookie(name, value, { maxAgeSec, secure, sameSite = 'Lax' }) {
  return [
    `${name}=${value}`,
    'Path=/',
    'HttpOnly',
    `SameSite=${sameSite}`,
    `Max-Age=${maxAgeSec}`,
    secure ? 'Secure' : null,
  ]
    .filter(Boolean)
    .join('; ');
}

function clientIp(cfg, req) {
  if (cfg.trustProxy) {
    const fwd = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (fwd) return fwd;
  }
  return req.socket.remoteAddress || 'unknown';
}

// CSRF defence in depth (the session cookie is also SameSite=Lax): browsers always send
// Origin on cross-site POSTs, so a foreign Origin is rejected.
function checkOrigin(cfg, req) {
  const origin = req.headers.origin;
  if (!origin) return; // non-browser clients (curl, server-to-server)
  let originHost;
  try {
    originHost = new URL(origin).host;
  } catch {
    throw new ApiError(403, 'Cross-origin request blocked.');
  }
  const fwdHost = cfg.trustProxy ? String(req.headers['x-forwarded-host'] || '').split(',')[0].trim() : '';
  const host = fwdHost || req.headers.host;
  if (originHost === host || cfg.allowedOrigins.includes(origin)) return;
  throw new ApiError(403, 'Cross-origin request blocked.');
}

module.exports = {
  applySecurityHeaders,
  sendJson,
  readJson,
  parseCookies,
  serializeCookie,
  clientIp,
  checkOrigin,
};
