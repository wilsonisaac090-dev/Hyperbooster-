'use strict';
const http = require('node:http');
const { openDatabase } = require('./db');
const { RateLimiter } = require('./security');
const { ApiError } = require('./errors');
const { applySecurityHeaders, sendJson, clientIp, checkOrigin } = require('./http');
const { getSessionUser, pruneExpiredSessions } = require('./auth');
const { buildRoutes } = require('./routes');
const { buildAdminRoutes } = require('./admin');
const { getAdminSession, requireCsrf } = require('./admin/auth');
const { createMailer } = require('./mailer');
const { syncProviderOrders } = require('./provider/orders');
const { withEffectiveProvider } = require('./credentials');
const { serveStatic } = require('./static');
const { serveAdminUi } = require('./adminUi');

function findRoute(routes, req, pathname) {
  let pathMatched = false;
  for (const r of routes) {
    const m = r.re.exec(pathname);
    if (!m) continue;
    pathMatched = true;
    if (r.method === req.method) return { route: r, match: m };
  }
  throw new ApiError(pathMatched ? 405 : 404, pathMatched ? 'Method not allowed.' : 'Not found.');
}

function rateLimit(ctx, key, limit) {
  const rl = ctx.limiter.hit(key, limit.max, limit.windowMs);
  if (!rl.allowed) {
    throw new ApiError(429, 'Too many requests. Please slow down.', { headers: { 'Retry-After': String(rl.retryAfterSec) } });
  }
}

async function handleApi(ctx, routes, req, res, url, ip) {
  rateLimit(ctx, `api:${ip}`, ctx.cfg.limits.apiPerIp);
  const { route, match } = findRoute(routes, req, url.pathname);
  if (req.method !== 'GET') checkOrigin(ctx.cfg, req);

  const user = route.auth === 'none' ? null : getSessionUser(ctx, req);
  if (route.auth === 'required' && !user) throw new ApiError(401, 'Please sign in to continue.');

  const out = await route.handler({ req, url, match, user, ip });
  sendJson(res, out.status || 200, out.body, out.headers);
}

// Admin API: separate cookie, separate session table, CSRF token on every change, never trusts the browser.
async function handleAdminApi(ctx, routes, req, res, url, ip) {
  rateLimit(ctx, `adm-api:${ip}`, ctx.cfg.limits.adminApiPerIp);
  const { route, match } = findRoute(routes, req, url.pathname);
  if (req.method !== 'GET') checkOrigin(ctx.cfg, req);

  let admin = null;
  if (route.auth === 'admin') {
    admin = getAdminSession(ctx, req);
    if (!admin) throw new ApiError(401, 'Please sign in to continue.');
    if (req.method !== 'GET') requireCsrf(admin, req);
  }
  const out = await route.handler({ req, url, match, admin, ip });
  sendJson(res, out.status || 200, out.body, out.headers);
}

function createApp(cfg, deps = {}) {
  const db = openDatabase(cfg.databasePath);
  const limiter = new RateLimiter();
  const mailer = deps.mailer || createMailer(cfg, deps.fetch);
  // aiFetch is how tests substitute a fake Groq server; production uses the real fetch (default).
  // koraFetch is how tests substitute a fake Kora server; production uses the real fetch (default).
  // providerFetch is how tests substitute a fake NigeriaSMM server; production uses the real fetch (default).
  const ctx = { cfg, db, limiter, mailer, aiFetch: deps.aiFetch || deps.fetch, koraFetch: deps.koraFetch || deps.fetch, providerFetch: deps.providerFetch || deps.fetch };
  const routes = buildRoutes(ctx);
  const adminRoutes = buildAdminRoutes(ctx);

  const server = http.createServer(async (req, res) => {
    const started = Date.now();
    const ip = clientIp(cfg, req);
    applySecurityHeaders(cfg, res);
    if (cfg.logRequests) {
      res.on('finish', () => {
        const path = String(req.url || '').split('?')[0].slice(0, 200);
        console.log(`${new Date().toISOString()} ${ip} ${req.method} ${path} ${res.statusCode} ${Date.now() - started}ms`);
      });
    }

    try {
      let url;
      try {
        url = new URL(req.url, 'http://localhost');
      } catch {
        throw new ApiError(400, 'Bad request.');
      }
      const p = url.pathname;
      if (p.startsWith('/api/admin/')) await handleAdminApi(ctx, adminRoutes, req, res, url, ip);
      else if (p === '/api' || p.startsWith('/api/')) await handleApi(ctx, routes, req, res, url, ip);
      else if (p === '/admin' || p.startsWith('/admin/')) serveAdminUi(ctx, req, res, p);
      else await serveStatic(cfg, req, res, p);
    } catch (err) {
      if (res.headersSent) return res.destroy();
      if (err instanceof ApiError) {
        const body = { error: err.message };
        if (err.field) body.field = err.field;
        return sendJson(res, err.status, body, err.headers);
      }
      console.error('Unhandled error:', err);
      sendJson(res, 500, { error: 'Something went wrong. Please try again.' });
    }
  });

  let providerSyncRunning = false; // overlap guard: a slow run is simply skipped, not queued twice
  const providerSyncTimer = setInterval(async () => {
    if (providerSyncRunning || !withEffectiveProvider(cfg, db).provider.configured) return;
    providerSyncRunning = true;
    try {
      await syncProviderOrders(ctx);
    } catch (err) {
      console.error('Provider sync failed:', err.message);
    } finally {
      providerSyncRunning = false;
    }
  }, cfg.providerSyncIntervalMs);
  providerSyncTimer.unref();

  const timer = setInterval(() => {
    try {
      pruneExpiredSessions(db);
      db.prepare('DELETE FROM admin_sessions WHERE expires_at <= ?').run(Date.now());
      db.prepare('DELETE FROM admin_login_challenges WHERE expires_at <= ?').run(Date.now());
      limiter.sweep();
    } catch (err) {
      console.error('Cleanup failed:', err);
    }
  }, 10 * 60 * 1000);
  timer.unref();

  return {
    server,
    db,
    limiter,
    mailer,
    close: () =>
      new Promise((resolve) => {
        clearInterval(timer);
        clearInterval(providerSyncTimer);
        server.close(() => {
          try {
            db.close();
          } catch {
            /* already closed */
          }
          resolve();
        });
        server.closeAllConnections?.();
      }),
  };
}

module.exports = { createApp };
