'use strict';
const { parseCookies, serializeCookie } = require('./http');
const { sha256, newSessionToken } = require('./security');

// Returns the signed-in, active user for this request, or null.
function getSessionUser(ctx, req) {
  const token = parseCookies(req.headers.cookie)[ctx.cfg.cookieName];
  if (!token || token.length > 100) return null;
  const row = ctx.db
    .prepare(
      `SELECT u.id, u.email, u.full_name, u.role, u.status, u.balance_kobo
         FROM sessions s JOIN users u ON u.id = s.user_id
        WHERE s.token_hash = ? AND s.expires_at > ?`
    )
    .get(sha256(token), Date.now());
  if (!row || row.status !== 'active') return null;
  return row;
}

// Always issues a brand-new random token (prevents session fixation). Returns the Set-Cookie value.
function createSession(ctx, req, userId, ip) {
  const { token, hash } = newSessionToken();
  const maxAgeSec = ctx.cfg.sessionDays * 86400;
  ctx.db
    .prepare('INSERT INTO sessions (user_id, token_hash, expires_at, ip, user_agent) VALUES (?,?,?,?,?)')
    .run(userId, hash, Date.now() + maxAgeSec * 1000, ip ?? null, String(req.headers['user-agent'] || '').slice(0, 255));
  return serializeCookie(ctx.cfg.cookieName, token, { maxAgeSec, secure: ctx.cfg.cookieSecure });
}

function destroySession(ctx, req) {
  const token = parseCookies(req.headers.cookie)[ctx.cfg.cookieName];
  if (token && token.length <= 100) ctx.db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
  return serializeCookie(ctx.cfg.cookieName, '', { maxAgeSec: 0, secure: ctx.cfg.cookieSecure });
}

function pruneExpiredSessions(db) {
  db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(Date.now());
}

module.exports = { getSessionUser, createSession, destroySession, pruneExpiredSessions };
