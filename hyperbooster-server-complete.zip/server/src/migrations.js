'use strict';

// Timestamps are UTC ISO-8601 text. Money is stored as INTEGER kobo (1 NGN = 100 kobo)
// so there are never floating point rounding problems.
const NOW = "(strftime('%Y-%m-%dT%H:%M:%fZ','now'))";

const MIGRATIONS = [
  {
    version: 1,
    sql: `
CREATE TABLE users (
  id            INTEGER PRIMARY KEY,
  email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
  full_name     TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'user'   CHECK (role   IN ('user','admin')),
  status        TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended')),
  balance_kobo  INTEGER NOT NULL DEFAULT 0 CHECK (balance_kobo >= 0),
  created_at    TEXT NOT NULL DEFAULT ${NOW},
  updated_at    TEXT NOT NULL DEFAULT ${NOW},
  last_login_at TEXT
);

CREATE TABLE sessions (
  id         INTEGER PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL DEFAULT ${NOW},
  expires_at INTEGER NOT NULL,
  ip         TEXT,
  user_agent TEXT
);
CREATE INDEX idx_sessions_user    ON sessions(user_id);
CREATE INDEX idx_sessions_expires ON sessions(expires_at);

CREATE TABLE services (
  id                      INTEGER PRIMARY KEY,
  name                    TEXT NOT NULL,
  platform                TEXT NOT NULL CHECK (length(platform) BETWEEN 1 AND 32 AND platform = lower(platform)),
  service_type            TEXT NOT NULL CHECK (length(service_type) BETWEEN 1 AND 32 AND service_type = lower(service_type)),
  provider_service_id     TEXT,
  price_per_1000_kobo     INTEGER NOT NULL CHECK (price_per_1000_kobo BETWEEN 0 AND 10000000000),
  min_quantity            INTEGER NOT NULL CHECK (min_quantity > 0),
  max_quantity            INTEGER NOT NULL CHECK (max_quantity <= 10000000),
  refill_available        INTEGER NOT NULL DEFAULT 0 CHECK (refill_available IN (0,1)),
  drop_rate               TEXT,
  average_completion_time TEXT,
  description             TEXT,
  notes                   TEXT,
  is_active               INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  sort_order              INTEGER NOT NULL DEFAULT 0,
  created_at              TEXT NOT NULL DEFAULT ${NOW},
  updated_at              TEXT NOT NULL DEFAULT ${NOW},
  CHECK (max_quantity >= min_quantity),
  UNIQUE (platform, name)
);
CREATE INDEX idx_services_platform ON services(platform, is_active, sort_order);

CREATE TABLE wallet_ledger (
  id                 INTEGER PRIMARY KEY,
  user_id            INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  entry_type         TEXT NOT NULL CHECK (entry_type IN ('deposit','order_charge','order_refund','adjustment')),
  amount_kobo        INTEGER NOT NULL CHECK (amount_kobo != 0),
  balance_after_kobo INTEGER NOT NULL CHECK (balance_after_kobo >= 0),
  reference_type     TEXT,
  reference_id       INTEGER,
  idempotency_key    TEXT UNIQUE,
  description        TEXT,
  created_at         TEXT NOT NULL DEFAULT ${NOW},
  CHECK (
    (entry_type IN ('deposit','order_refund') AND amount_kobo > 0) OR
    (entry_type = 'order_charge' AND amount_kobo < 0) OR
    entry_type = 'adjustment'
  )
);
CREATE INDEX idx_ledger_user ON wallet_ledger(user_id, id DESC);

CREATE TABLE deposits (
  id                INTEGER PRIMARY KEY,
  user_id           INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  reference         TEXT NOT NULL UNIQUE,
  amount_kobo       INTEGER NOT NULL CHECK (amount_kobo > 0),
  currency          TEXT NOT NULL DEFAULT 'NGN',
  status            TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending','successful','failed','cancelled','expired')),
  gateway           TEXT NOT NULL DEFAULT 'kora',
  gateway_reference TEXT,
  gateway_payload   TEXT,
  created_at        TEXT NOT NULL DEFAULT ${NOW},
  updated_at        TEXT NOT NULL DEFAULT ${NOW},
  paid_at           TEXT
);
CREATE INDEX idx_deposits_user   ON deposits(user_id, id DESC);
CREATE INDEX idx_deposits_status ON deposits(status);

CREATE TABLE orders (
  id                  INTEGER PRIMARY KEY,
  user_id             INTEGER NOT NULL REFERENCES users(id)    ON DELETE RESTRICT,
  service_id          INTEGER NOT NULL REFERENCES services(id) ON DELETE RESTRICT,
  service_name        TEXT NOT NULL,
  platform            TEXT NOT NULL,
  service_type        TEXT NOT NULL,
  link                TEXT NOT NULL,
  quantity            INTEGER NOT NULL CHECK (quantity > 0),
  price_per_1000_kobo INTEGER NOT NULL,
  charge_kobo         INTEGER NOT NULL CHECK (charge_kobo >= 0),
  status              TEXT NOT NULL DEFAULT 'pending'
                      CHECK (status IN ('pending','processing','in_progress','completed','partial','canceled','failed','refunded')),
  provider_order_id   TEXT,
  provider_status     TEXT,
  start_count         INTEGER,
  remains             INTEGER,
  error_message       TEXT,
  created_at          TEXT NOT NULL DEFAULT ${NOW},
  updated_at          TEXT NOT NULL DEFAULT ${NOW},
  completed_at        TEXT
);
CREATE INDEX idx_orders_user   ON orders(user_id, id DESC);
CREATE INDEX idx_orders_status ON orders(status);
`,
  },
  {
    version: 2,
    sql: `
CREATE TABLE admins (
  id                  INTEGER PRIMARY KEY,
  email               TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name                TEXT,
  password_hash       TEXT NOT NULL,
  role                TEXT NOT NULL DEFAULT 'owner'  CHECK (role   IN ('owner','admin')),
  status              TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','disabled')),
  created_at          TEXT NOT NULL DEFAULT ${NOW},
  updated_at          TEXT NOT NULL DEFAULT ${NOW},
  last_login_at       TEXT,
  password_changed_at TEXT
);

-- step 2 of admin sign-in: a one-time email code tied to a random challenge token (stored hashed)
CREATE TABLE admin_login_challenges (
  id           INTEGER PRIMARY KEY,
  admin_id     INTEGER NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  token_hash   TEXT NOT NULL UNIQUE,
  code_hash    TEXT NOT NULL,
  attempts     INTEGER NOT NULL DEFAULT 0,
  resends      INTEGER NOT NULL DEFAULT 0,
  last_sent_at INTEGER NOT NULL,
  expires_at   INTEGER NOT NULL,
  created_at   TEXT NOT NULL DEFAULT ${NOW},
  ip           TEXT
);
CREATE INDEX idx_admin_challenges_admin ON admin_login_challenges(admin_id);

CREATE TABLE admin_sessions (
  id         INTEGER PRIMARY KEY,
  admin_id   INTEGER NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  csrf_token TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT ${NOW},
  expires_at INTEGER NOT NULL,
  ip         TEXT,
  user_agent TEXT
);
CREATE INDEX idx_admin_sessions_admin   ON admin_sessions(admin_id);
CREATE INDEX idx_admin_sessions_expires ON admin_sessions(expires_at);

CREATE TABLE service_tags (
  id         INTEGER PRIMARY KEY,
  name       TEXT NOT NULL UNIQUE COLLATE NOCASE,
  created_at TEXT NOT NULL DEFAULT ${NOW}
);
CREATE TABLE service_tag_links (
  service_id INTEGER NOT NULL REFERENCES services(id)     ON DELETE CASCADE,
  tag_id     INTEGER NOT NULL REFERENCES service_tags(id) ON DELETE CASCADE,
  PRIMARY KEY (service_id, tag_id)
);
CREATE INDEX idx_tag_links_tag ON service_tag_links(tag_id);

CREATE TABLE settings (
  key                 TEXT PRIMARY KEY,
  value               TEXT NOT NULL,
  updated_at          TEXT NOT NULL DEFAULT ${NOW},
  updated_by_admin_id INTEGER REFERENCES admins(id) ON DELETE SET NULL
);

CREATE TABLE audit_logs (
  id            INTEGER PRIMARY KEY,
  admin_id      INTEGER REFERENCES admins(id) ON DELETE SET NULL,
  admin_email   TEXT,                    -- snapshot, so the log stays readable if an admin is removed
  action        TEXT NOT NULL,
  resource_type TEXT,
  resource_id   TEXT,
  details       TEXT,                    -- JSON
  ip            TEXT,
  created_at    TEXT NOT NULL DEFAULT ${NOW}
);
CREATE INDEX idx_audit_created ON audit_logs(id DESC);
CREATE INDEX idx_audit_action  ON audit_logs(action);

ALTER TABLE services ADD COLUMN category TEXT NOT NULL DEFAULT 'General';
ALTER TABLE services ADD COLUMN provider_cost_kobo INTEGER NOT NULL DEFAULT 0
  CHECK (provider_cost_kobo BETWEEN 0 AND 10000000000);
UPDATE services SET category = upper(substr(service_type, 1, 1)) || substr(service_type, 2);
CREATE INDEX idx_services_category ON services(category);
CREATE INDEX idx_services_active   ON services(is_active);

-- manual wallet changes record which admin made them
ALTER TABLE wallet_ledger ADD COLUMN admin_id INTEGER REFERENCES admins(id) ON DELETE SET NULL;

CREATE INDEX idx_orders_created ON orders(created_at);
CREATE INDEX idx_users_created  ON users(created_at);
`,
  },
  {
    version: 3,
    sql: `
CREATE TABLE ai_settings (
  id                   INTEGER PRIMARY KEY CHECK (id = 1),
  enabled              INTEGER NOT NULL DEFAULT 0 CHECK (enabled IN (0,1)),
  provider             TEXT NOT NULL DEFAULT 'groq',
  model                TEXT NOT NULL DEFAULT 'openai/gpt-oss-120b',
  assistant_name       TEXT NOT NULL DEFAULT 'EL Assistant',
  system_instructions  TEXT,
  api_key_ciphertext   TEXT,             -- AES-256-GCM, base64 iv:tag:ciphertext. NEVER the plaintext key.
  api_key_last4        TEXT,             -- last 4 characters only, for display ("configured" indicator)
  tool_permissions     TEXT NOT NULL DEFAULT '{}',  -- JSON of read-only tool toggles; write/financial are not columns here (see below)
  updated_at           TEXT NOT NULL DEFAULT ${NOW},
  updated_by_admin_id  INTEGER REFERENCES admins(id) ON DELETE SET NULL
);
INSERT INTO ai_settings (id) VALUES (1);

CREATE TABLE ai_conversations (
  id         INTEGER PRIMARY KEY,
  admin_id   INTEGER NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  title      TEXT NOT NULL DEFAULT 'New chat',
  created_at TEXT NOT NULL DEFAULT ${NOW},
  updated_at TEXT NOT NULL DEFAULT ${NOW}
);
CREATE INDEX idx_ai_conv_admin ON ai_conversations(admin_id, id DESC);

CREATE TABLE ai_messages (
  id              INTEGER PRIMARY KEY,
  conversation_id INTEGER NOT NULL REFERENCES ai_conversations(id) ON DELETE CASCADE,
  role            TEXT NOT NULL CHECK (role IN ('user','assistant','tool')),
  content         TEXT,
  tool_name       TEXT,                  -- set when role = 'tool'
  created_at      TEXT NOT NULL DEFAULT ${NOW}
);
CREATE INDEX idx_ai_msg_conv ON ai_messages(conversation_id, id);
`,
  },
  {
    version: 4,
    sql: `
ALTER TABLE deposits ADD COLUMN verified_amount_kobo INTEGER;  -- what Kora actually confirms was paid (may differ from amount_kobo)
ALTER TABLE deposits ADD COLUMN failure_reason TEXT;
`,
  },
  {
    version: 5,
    sql: `
-- Admin-managed integration secrets. Ciphertext only (AES-256-GCM, key from env, see src/ai/crypto.js).
CREATE TABLE integration_credentials (
  name                TEXT PRIMARY KEY CHECK (name IN ('kora','provider')),
  ciphertext          TEXT NOT NULL,
  last4               TEXT NOT NULL,
  updated_at          TEXT NOT NULL DEFAULT ${NOW},
  updated_by_admin_id INTEGER REFERENCES admins(id) ON DELETE SET NULL
);
`,
  },
  {
    version: 6,
    sql: `
-- EL Assistant: which model describes images (vision). The text/tool model stays in ai_settings.model.
-- Model ids change over time, so this is a setting rather than a constant. Default must match
-- DEFAULT_VISION_MODEL in src/ai/limits.js (a test enforces that).
-- Web-search and vision on/off live in the existing tool_permissions JSON (default OFF), so they need no column.
ALTER TABLE ai_settings ADD COLUMN vision_model TEXT NOT NULL DEFAULT 'qwen/qwen3.8-27b';
`,
  },
  {
    version: 7,
    sql: `
-- EL Assistant: live web search through Exa (the AI provider stays Groq).
-- exa_api_key_ciphertext: AES-256-GCM like api_key_ciphertext. NEVER the plaintext key, and no "last 4" hint is kept.
-- search_provider: 'exa' (default) or 'groq' (Groq's built-in browser search, kept as an alternative).
-- search_max_results / search_result_chars: how many results are asked for and how much excerpt text EL receives.
-- Whether live search is ON stays in the existing tool_permissions JSON (web_search, default OFF): no column.
ALTER TABLE ai_settings ADD COLUMN exa_api_key_ciphertext TEXT;
ALTER TABLE ai_settings ADD COLUMN search_provider TEXT NOT NULL DEFAULT 'exa' CHECK (search_provider IN ('exa','groq'));
ALTER TABLE ai_settings ADD COLUMN search_max_results INTEGER NOT NULL DEFAULT 5 CHECK (search_max_results BETWEEN 1 AND 10);
ALTER TABLE ai_settings ADD COLUMN search_result_chars INTEGER NOT NULL DEFAULT 4000 CHECK (search_result_chars BETWEEN 500 AND 8000);
`,
  },
];

module.exports = { MIGRATIONS };
