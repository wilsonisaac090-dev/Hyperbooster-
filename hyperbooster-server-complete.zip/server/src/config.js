'use strict';
const fs = require('node:fs');
const path = require('node:path');

const SERVER_DIR = path.resolve(__dirname, '..');
const MINUTE = 60 * 1000;

const int = (v, d) => {
  const n = Number.parseInt(v, 10);
  return Number.isFinite(n) ? n : d;
};
const bool = (v, d = false) =>
  v === undefined || v === '' ? d : ['1', 'true', 'yes', 'on'].includes(String(v).toLowerCase());

function defaultStaticDir() {
  const publicDir = path.resolve(SERVER_DIR, '..', 'public');
  return fs.existsSync(publicDir) ? publicDir : path.resolve(SERVER_DIR, '..');
}

function loadConfig(env = process.env, overrides = {}) {
  const isProd = env.NODE_ENV === 'production';
  const cookieSecure = bool(env.COOKIE_SECURE, isProd);

  // Email delivery for admin one-time codes. 'console' (dev only) prints the code to the server log.
  let mailTransport = String(env.MAIL_TRANSPORT || (isProd ? 'none' : 'console')).toLowerCase();
  if (!['console', 'memory', 'resend', 'none'].includes(mailTransport)) mailTransport = 'none';
  if (isProd && (mailTransport === 'console' || mailTransport === 'memory')) mailTransport = 'none';
  if (mailTransport === 'resend' && (!env.RESEND_API_KEY || !env.MAIL_FROM)) mailTransport = 'none';

  const cfg = {
    env: env.NODE_ENV || 'development',
    isProd,
    port: int(env.PORT, 3000),
    host: env.HOST || '0.0.0.0',
    serverDir: SERVER_DIR,
    databasePath:
      env.DATABASE_PATH === ':memory:'
        ? ':memory:'
        : path.resolve(SERVER_DIR, env.DATABASE_PATH || './data/hyperbooster.db'),
    staticDir: env.STATIC_DIR ? path.resolve(SERVER_DIR, env.STATIC_DIR) : defaultStaticDir(),
    trustProxy: bool(env.TRUST_PROXY),
    sessionDays: int(env.SESSION_DAYS, 14),
    cookieSecure,
    cookieName: cookieSecure ? '__Host-hb_session' : 'hb_session',
    allowedOrigins: String(env.ALLOWED_ORIGINS || '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean),
    allowInlineScripts: bool(env.ALLOW_INLINE_SCRIPTS),
    providerSyncIntervalMs: 5 * MINUTE,
    providerSyncStaleMs: 3 * MINUTE, // don't re-check an order sooner than this
    adminCookieName: cookieSecure ? '__Host-hb_admin' : 'hb_admin',
    adminChallengeCookieName: cookieSecure ? '__Host-hb_admin_ch' : 'hb_admin_ch',
    mailTransport,
    mailFrom: env.MAIL_FROM || '',
    resendApiKey: env.RESEND_API_KEY || '', // secret: read only by mailer.js, never sent to any browser
    // Only "is it set" is ever exposed to the admin UI, never the values themselves.
    integrations: {
      koraConfigured: Boolean(env.KORA_SECRET_KEY),
      providerConfigured: Boolean(env.NIGERIASMMPANEL_API_KEY),
    },
    // NigeriaSMM (and any future provider using the same "SMM Panel v2 API" shape). Server-side only —
    // never sent to the browser, never logged. NIGERIASMMPANEL_API_URL defaults to NigeriaSMM's own
    // documented base URL, so only the key needs to be set for the common case.
    provider: {
      apiKey: env.NIGERIASMMPANEL_API_KEY || '',
      apiUrl: env.NIGERIASMMPANEL_API_URL || 'https://nigeriasmm.com/api/v2',
      configured: Boolean(env.NIGERIASMMPANEL_API_KEY),
    },
    kora: {
      secretKey: env.KORA_SECRET_KEY || '',   // server-side only; never sent to any browser
      publicKey: env.KORA_PUBLIC_KEY || '',   // not currently used server-side, kept for completeness/future client widget use
      baseUrl: (env.KORA_BASE_URL || 'https://api.korapay.com').replace(/\/+$/, ''),
      configured: Boolean(env.KORA_SECRET_KEY),
    },
    // Encrypts the AI provider's API key at rest (see src/ai/crypto.js). Set AI_ENCRYPTION_KEY (32
    // random bytes, hex-encoded = 64 hex characters) so the saved key survives a restart. Without it,
    // a key is generated for this process only: any saved AI API key becomes unreadable after a
    // restart and must be re-entered — the app still starts, since the AI assistant is optional.
    aiEncryptionKey: /^[0-9a-fA-F]{64}$/.test(env.AI_ENCRYPTION_KEY || '')
      ? Buffer.from(env.AI_ENCRYPTION_KEY, 'hex')
      : require('node:crypto').randomBytes(32),
    logRequests: bool(env.LOG_REQUESTS, true),
    limits: {
      apiPerIp: { max: 300, windowMs: MINUTE },
      loginPerIp: { max: 30, windowMs: 15 * MINUTE },
      loginPerAccount: { max: 8, windowMs: 15 * MINUTE },
      registerPerIp: { max: 10, windowMs: 60 * MINUTE },
      orderPerUser: { max: 30, windowMs: MINUTE },
      adminLoginPerIp: { max: 10, windowMs: 15 * MINUTE },
      adminLoginPerAccount: { max: 5, windowMs: 15 * MINUTE },
      adminOtpPerIp: { max: 20, windowMs: 15 * MINUTE },
      adminApiPerIp: { max: 600, windowMs: MINUTE },
      adminAiChatPerAdmin: { max: 20, windowMs: MINUTE },
      adminAiChatPerIp: { max: 40, windowMs: MINUTE },
      adminAiSettingsPerIp: { max: 10, windowMs: 15 * MINUTE },
      depositCreatePerUser: { max: 10, windowMs: 15 * MINUTE },
      depositCreatePerIp: { max: 20, windowMs: 15 * MINUTE },
      koraWebhookPerIp: { max: 120, windowMs: MINUTE },
    },
  };
  return { ...cfg, ...overrides };
}

module.exports = { loadConfig, SERVER_DIR };
