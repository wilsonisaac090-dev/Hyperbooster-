'use strict';
const { ApiError } = require('./errors');

// Platform settings live in the database so the admin can change them without editing code.
const DEFAULTS = {
  site_name: 'HYPERBOOSTER',
  site_status: 'open', // 'open' | 'maintenance'
  currency: 'NGN',
  min_deposit_kobo: '100000', // NGN 1,000; used by the wallet-deposit flow when Kora is connected
  otp_ttl_minutes: '10',
  admin_session_hours: '8',
};

function getSettings(db) {
  const raw = { ...DEFAULTS };
  for (const row of db.prepare('SELECT key, value FROM settings').all()) {
    if (row.key in DEFAULTS) raw[row.key] = row.value;
  }
  return {
    siteName: raw.site_name,
    siteStatus: raw.site_status,
    currency: raw.currency,
    minDepositKobo: Number(raw.min_deposit_kobo),
    otpTtlMinutes: Number(raw.otp_ttl_minutes),
    adminSessionHours: Number(raw.admin_session_hours),
  };
}

const bad = (message, field) => new ApiError(400, message, { field });
const intIn = (v, min, max, field, label) => {
  if (typeof v !== 'number' || !Number.isSafeInteger(v) || v < min || v > max) throw bad(`${label} must be a whole number from ${min} to ${max}.`, field);
  return v;
};

// Validates a partial update and returns { dbKey: 'string value' } plus a camelCase view for the audit log.
function validateSettingsPatch(patch) {
  const out = {};
  const view = {};
  const set = (key, camel, value) => { out[key] = String(value); view[camel] = value; };

  if ('siteName' in patch) {
    const v = typeof patch.siteName === 'string' ? patch.siteName.trim() : '';
    if (!v || v.length > 60 || /[\u0000-\u001f\u007f]/.test(v)) throw bad('Site name must be 1 to 60 characters.', 'siteName');
    set('site_name', 'siteName', v);
  }
  if ('siteStatus' in patch) {
    if (!['open', 'maintenance'].includes(patch.siteStatus)) throw bad('Site status must be open or maintenance.', 'siteStatus');
    set('site_status', 'siteStatus', patch.siteStatus);
  }
  if ('currency' in patch) {
    if (patch.currency !== 'NGN') throw bad('Only NGN is supported right now.', 'currency');
    set('currency', 'currency', 'NGN');
  }
  if ('minDepositKobo' in patch) set('min_deposit_kobo', 'minDepositKobo', intIn(patch.minDepositKobo, 0, 1000000000, 'minDepositKobo', 'Minimum deposit'));
  if ('otpTtlMinutes' in patch) set('otp_ttl_minutes', 'otpTtlMinutes', intIn(patch.otpTtlMinutes, 5, 30, 'otpTtlMinutes', 'Code lifetime (minutes)'));
  if ('adminSessionHours' in patch) set('admin_session_hours', 'adminSessionHours', intIn(patch.adminSessionHours, 1, 24, 'adminSessionHours', 'Admin session length (hours)'));

  if (!Object.keys(out).length) throw new ApiError(400, 'No valid settings were provided.');
  return { out, view };
}

function saveSettings(db, out, adminId) {
  const stmt = db.prepare(
    `INSERT INTO settings (key, value, updated_by_admin_id) VALUES (?,?,?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), updated_by_admin_id = excluded.updated_by_admin_id`
  );
  for (const [key, value] of Object.entries(out)) stmt.run(key, value, adminId);
}

module.exports = { getSettings, validateSettingsPatch, saveSettings };
