'use strict';
const { ApiError } = require('../errors');

const bad = (message, field) => new ApiError(400, message, { field });

const CONTROL = /[\u0000-\u001f\u007f]/;

function text(value, field, label, { min = 1, max, required = true, multiline = false } = {}) {
  if (value === undefined || value === null || value === '') {
    if (required) throw bad(`${label} is required.`, field);
    return null;
  }
  if (typeof value !== 'string') throw bad(`${label} must be text.`, field);
  const v = value.trim();
  if (!v && required) throw bad(`${label} is required.`, field);
  if (!v) return null;
  if (v.length < min || v.length > max) throw bad(`${label} must be ${min === 1 ? 'up to' : `${min} to`} ${max} characters.`, field);
  if ((multiline ? /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/ : CONTROL).test(v)) throw bad(`${label} contains invalid characters.`, field);
  return v;
}

function int(value, field, label, { min, max, required = true, fallback = null }) {
  if (value === undefined || value === null || value === '') {
    if (required) throw bad(`${label} is required.`, field);
    return fallback;
  }
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < min || value > max) {
    throw bad(`${label} must be a whole number from ${min.toLocaleString('en-US')} to ${max.toLocaleString('en-US')}.`, field);
  }
  return value;
}

function bool(value, field, label, fallback) {
  if (value === undefined || value === null) return fallback;
  if (typeof value !== 'boolean') throw bad(`${label} must be true or false.`, field);
  return value;
}

const parseId = (match) => Number(match[1]);
const likeEscape = (s) => String(s).replace(/[\\%_]/g, '\\$&');

function paging(searchParams, defaultLimit = 20) {
  const limit = Math.min(100, Math.max(1, Number.parseInt(searchParams.get('limit'), 10) || defaultLimit));
  const offset = Math.max(0, Number.parseInt(searchParams.get('offset'), 10) || 0);
  return { limit, offset };
}

module.exports = { bad, text, int, bool, parseId, likeEscape, paging };
