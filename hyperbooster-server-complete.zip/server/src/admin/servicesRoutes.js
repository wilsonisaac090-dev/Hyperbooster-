'use strict';
const { ApiError } = require('../errors');
const { readJson } = require('../http');
const { transaction } = require('../db');
const { writeAudit } = require('../audit');
const H = require('./helpers');

const SLUG = /^[a-z0-9][a-z0-9_-]{0,31}$/;
const FIELDS = ['name', 'category', 'platform', 'serviceType', 'providerServiceId', 'providerCostKobo', 'pricePer1000Kobo', 'minQuantity', 'maxQuantity', 'refillAvailable', 'dropRate', 'averageCompletionTime', 'description', 'notes', 'isActive', 'sortOrder', 'tags'];

function slug(value, field, label) {
  const v = H.text(value, field, label, { max: 32 }).toLowerCase();
  if (!SLUG.test(v)) throw H.bad(`${label} can only use lowercase letters, numbers, - and _.`, field);
  return v;
}

function tagNames(value) {
  if (value === undefined || value === null) return [];
  if (!Array.isArray(value) || value.length > 10) throw H.bad('Use up to 10 tags.', 'tags');
  const seen = new Map();
  for (const t of value) {
    const name = H.text(t, 'tags', 'Tag', { max: 30 }).replace(/\s+/g, ' ');
    if (!seen.has(name.toLowerCase())) seen.set(name.toLowerCase(), name);
  }
  return [...seen.values()];
}

function notesText(value) {
  if (value === undefined || value === null || value === '') return null;
  if (typeof value !== 'string') throw H.bad('Notes must be text.', 'notes');
  const lines = value.split('\n').map((l) => l.trim()).filter(Boolean);
  if (lines.length > 10 || lines.some((l) => l.length > 200)) throw H.bad('Use up to 10 notes of 200 characters each (one per line).', 'notes');
  return lines.length ? lines.join('\n') : null;
}

function parseServiceBody(b) {
  const minQuantity = H.int(b.minQuantity, 'minQuantity', 'Minimum quantity', { min: 1, max: 10000000 });
  return {
    name: H.text(b.name, 'name', 'Service name', { max: 80 }),
    category: H.text(b.category, 'category', 'Category', { max: 40 }),
    platform: slug(b.platform, 'platform', 'Platform'),
    serviceType: slug(b.serviceType, 'serviceType', 'Service type'),
    providerServiceId: H.text(b.providerServiceId, 'providerServiceId', 'Provider service ID', { max: 64, required: false }),
    providerCostKobo: H.int(b.providerCostKobo, 'providerCostKobo', 'Provider cost', { min: 0, max: 10000000000, required: false, fallback: 0 }),
    pricePer1000Kobo: H.int(b.pricePer1000Kobo, 'pricePer1000Kobo', 'Customer price', { min: 0, max: 10000000000 }),
    minQuantity,
    maxQuantity: H.int(b.maxQuantity, 'maxQuantity', 'Maximum quantity', { min: minQuantity, max: 10000000 }),
    refillAvailable: H.bool(b.refillAvailable, 'refillAvailable', 'Refill', false),
    dropRate: H.text(b.dropRate, 'dropRate', 'Drop rate', { max: 40, required: false }),
    averageCompletionTime: H.text(b.averageCompletionTime, 'averageCompletionTime', 'Completion time', { max: 40, required: false }),
    description: H.text(b.description, 'description', 'Description', { max: 500, required: false, multiline: true }),
    notes: notesText(b.notes),
    isActive: H.bool(b.isActive, 'isActive', 'Status', true),
    sortOrder: H.int(b.sortOrder, 'sortOrder', 'Sort order', { min: 0, max: 100000, required: false, fallback: 0 }),
    tags: tagNames(b.tags),
  };
}

function buildServicesRoutes(ctx) {
  const { db } = ctx;

  function tagsFor(ids) {
    const map = new Map(ids.map((id) => [id, []]));
    if (!ids.length) return map;
    const rows = db
      .prepare(`SELECT l.service_id, t.name FROM service_tag_links l JOIN service_tags t ON t.id = l.tag_id WHERE l.service_id IN (${ids.map(() => '?').join(',')}) ORDER BY t.name COLLATE NOCASE`)
      .all(...ids);
    rows.forEach((r) => map.get(r.service_id).push(r.name));
    return map;
  }

  const shape = (r, tags) => ({
    id: r.id,
    name: r.name,
    category: r.category,
    platform: r.platform,
    serviceType: r.service_type,
    providerServiceId: r.provider_service_id,
    providerCostKobo: r.provider_cost_kobo,
    pricePer1000Kobo: r.price_per_1000_kobo,
    marginKobo: r.price_per_1000_kobo - r.provider_cost_kobo,
    minQuantity: r.min_quantity,
    maxQuantity: r.max_quantity,
    refillAvailable: r.refill_available === 1,
    dropRate: r.drop_rate,
    averageCompletionTime: r.average_completion_time,
    description: r.description,
    notes: r.notes || '',
    tags: tags || [],
    isActive: r.is_active === 1,
    sortOrder: r.sort_order,
    orderCount: r.order_count ?? undefined,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  });

  const ORDER_COUNT = '(SELECT COUNT(*) FROM orders o WHERE o.service_id = s.id) AS order_count';

  function load(id) {
    const row = db.prepare(`SELECT s.*, ${ORDER_COUNT} FROM services s WHERE s.id = ?`).get(id);
    if (!row) throw new ApiError(404, 'Service not found.');
    return shape(row, tagsFor([id]).get(id));
  }

  function setTags(serviceId, names) {
    db.prepare('DELETE FROM service_tag_links WHERE service_id = ?').run(serviceId);
    for (const name of names) {
      db.prepare('INSERT OR IGNORE INTO service_tags (name) VALUES (?)').run(name);
      const tag = db.prepare('SELECT id FROM service_tags WHERE name = ?').get(name);
      db.prepare('INSERT OR IGNORE INTO service_tag_links (service_id, tag_id) VALUES (?,?)').run(serviceId, tag.id);
    }
  }

  const dbValues = (v) => [v.name, v.platform, v.category, v.serviceType, v.providerServiceId, v.providerCostKobo, v.pricePer1000Kobo, v.minQuantity, v.maxQuantity, v.refillAvailable ? 1 : 0, v.dropRate, v.averageCompletionTime, v.description, v.notes, v.isActive ? 1 : 0, v.sortOrder];

  const duplicate = (err) => {
    if (/UNIQUE constraint failed: services\.platform, services\.name/i.test(String(err.message))) {
      throw new ApiError(409, 'A service with this name already exists on this platform.', { field: 'name' });
    }
    throw err;
  };

  const changes = (before, after) => {
    const out = {};
    for (const f of FIELDS) {
      const norm = (x) => (f === 'tags' ? [...x].map((t) => t.toLowerCase()).sort() : x);
      const a = JSON.stringify(norm(before[f]));
      const b = JSON.stringify(norm(after[f]));
      if (a !== b) out[f] = [before[f], after[f]];
    }
    return out;
  };

  return [
    {
      method: 'GET',
      re: /^\/api\/admin\/services$/,
      auth: 'admin',
      handler: ({ url }) => {
        const q = url.searchParams;
        const where = [];
        const params = [];
        const term = (q.get('q') || '').trim().slice(0, 80);
        if (term) {
          where.push("(s.name LIKE ? ESCAPE '\\' OR s.provider_service_id LIKE ? ESCAPE '\\')");
          params.push(`%${H.likeEscape(term)}%`, `%${H.likeEscape(term)}%`);
        }
        if (q.get('platform')) { where.push('s.platform = ?'); params.push(q.get('platform')); }
        if (q.get('category')) { where.push('s.category = ? COLLATE NOCASE'); params.push(q.get('category')); }
        if (q.get('status') === 'active') where.push('s.is_active = 1');
        if (q.get('status') === 'inactive') where.push('s.is_active = 0');
        if (q.get('tag')) {
          where.push('EXISTS (SELECT 1 FROM service_tag_links l JOIN service_tags t ON t.id = l.tag_id WHERE l.service_id = s.id AND t.name = ?)');
          params.push(q.get('tag'));
        }
        const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
        const { limit, offset } = H.paging(q, 50);
        const total = db.prepare(`SELECT COUNT(*) AS n FROM services s ${clause}`).get(...params).n;
        const rows = db.prepare(`SELECT s.*, ${ORDER_COUNT} FROM services s ${clause} ORDER BY s.platform, s.sort_order, s.id LIMIT ? OFFSET ?`).all(...params, limit, offset);
        const tags = tagsFor(rows.map((r) => r.id));
        return {
          body: {
            total,
            services: rows.map((r) => shape(r, tags.get(r.id))),
            filters: {
              platforms: db.prepare('SELECT DISTINCT platform AS v FROM services ORDER BY 1').all().map((r) => r.v),
              categories: db.prepare('SELECT DISTINCT category AS v FROM services ORDER BY 1 COLLATE NOCASE').all().map((r) => r.v),
              tags: db.prepare('SELECT name FROM service_tags ORDER BY name COLLATE NOCASE').all().map((r) => r.name),
            },
          },
        };
      },
    },
    { method: 'GET', re: /^\/api\/admin\/services\/(\d{1,12})$/, auth: 'admin', handler: ({ match }) => ({ body: { service: load(H.parseId(match)) } }) },

    {
      method: 'POST',
      re: /^\/api\/admin\/services$/,
      auth: 'admin',
      handler: async ({ req, admin, ip }) => {
        const v = parseServiceBody(await readJson(req));
        const id = transaction(db, () => {
          let newId;
          try {
            newId = Number(
              db
                .prepare(`INSERT INTO services (name, platform, category, service_type, provider_service_id, provider_cost_kobo, price_per_1000_kobo, min_quantity, max_quantity, refill_available, drop_rate, average_completion_time, description, notes, is_active, sort_order) VALUES (${new Array(16).fill('?').join(',')})`)
                .run(...dbValues(v)).lastInsertRowid
            );
          } catch (err) { duplicate(err); }
          setTags(newId, v.tags);
          writeAudit(db, { admin, action: 'service.create', resourceType: 'service', resourceId: newId, ip, details: { name: v.name, platform: v.platform, serviceType: v.serviceType, pricePer1000Kobo: v.pricePer1000Kobo, isActive: v.isActive } });
          return newId;
        });
        return { status: 201, body: { service: load(id) } };
      },
    },

    {
      method: 'PUT',
      re: /^\/api\/admin\/services\/(\d{1,12})$/,
      auth: 'admin',
      handler: async ({ req, match, admin, ip }) => {
        const id = H.parseId(match);
        const v = parseServiceBody(await readJson(req));
        transaction(db, () => {
          const before = load(id);
          try {
            db.prepare(`UPDATE services SET name=?, platform=?, category=?, service_type=?, provider_service_id=?, provider_cost_kobo=?, price_per_1000_kobo=?, min_quantity=?, max_quantity=?, refill_available=?, drop_rate=?, average_completion_time=?, description=?, notes=?, is_active=?, sort_order=?, updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?`).run(...dbValues(v), id);
          } catch (err) { duplicate(err); }
          setTags(id, v.tags);
          const diff = changes(before, { ...v, notes: v.notes || '' });
          if (Object.keys(diff).length) {
            writeAudit(db, { admin, action: 'service.update', resourceType: 'service', resourceId: id, ip, details: { name: v.name, changes: diff } });
          }
        });
        return { body: { service: load(id) } };
      },
    },

    {
      method: 'POST',
      re: /^\/api\/admin\/services\/(\d{1,12})\/status$/,
      auth: 'admin',
      handler: async ({ req, match, admin, ip }) => {
        const id = H.parseId(match);
        const body = await readJson(req);
        if (typeof body.active !== 'boolean') throw H.bad('Status must be true or false.', 'active');
        transaction(db, () => {
          const before = load(id);
          db.prepare("UPDATE services SET is_active = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?").run(body.active ? 1 : 0, id);
          if (before.isActive !== body.active) {
            writeAudit(db, { admin, action: body.active ? 'service.enable' : 'service.disable', resourceType: 'service', resourceId: id, ip, details: { name: before.name } });
          }
        });
        return { body: { service: load(id) } };
      },
    },

    {
      method: 'DELETE',
      re: /^\/api\/admin\/services\/(\d{1,12})$/,
      auth: 'admin',
      handler: async ({ req, match, admin, ip }) => {
        const id = H.parseId(match);
        const body = await readJson(req);
        if (body.confirm !== true) throw new ApiError(400, 'Deleting a service must be confirmed.');
        transaction(db, () => {
          const svc = load(id);
          if (svc.orderCount > 0) {
            throw new ApiError(409, `This service has ${svc.orderCount} order${svc.orderCount === 1 ? '' : 's'} so it cannot be deleted. Disable it instead to hide it from customers.`);
          }
          db.prepare('DELETE FROM services WHERE id = ?').run(id);
          writeAudit(db, { admin, action: 'service.delete', resourceType: 'service', resourceId: id, ip, details: { name: svc.name, platform: svc.platform, serviceType: svc.serviceType } });
        });
        return { body: { ok: true } };
      },
    },

    // ---------- tags ----------
    {
      method: 'GET',
      re: /^\/api\/admin\/tags$/,
      auth: 'admin',
      handler: () => ({
        body: { tags: db.prepare('SELECT t.id, t.name, (SELECT COUNT(*) FROM service_tag_links l WHERE l.tag_id = t.id) AS service_count FROM service_tags t ORDER BY t.name COLLATE NOCASE').all().map((t) => ({ id: t.id, name: t.name, serviceCount: t.service_count })) },
      }),
    },
    {
      method: 'POST',
      re: /^\/api\/admin\/tags$/,
      auth: 'admin',
      handler: async ({ req, admin, ip }) => {
        const name = H.text((await readJson(req)).name, 'name', 'Tag', { max: 30 }).replace(/\s+/g, ' ');
        const id = transaction(db, () => {
          let newId;
          try { newId = Number(db.prepare('INSERT INTO service_tags (name) VALUES (?)').run(name).lastInsertRowid); }
          catch (err) { if (/UNIQUE/i.test(err.message)) throw new ApiError(409, 'That tag already exists.', { field: 'name' }); throw err; }
          writeAudit(db, { admin, action: 'tag.create', resourceType: 'tag', resourceId: newId, ip, details: { name } });
          return newId;
        });
        return { status: 201, body: { tag: { id, name, serviceCount: 0 } } };
      },
    },
    {
      method: 'PATCH',
      re: /^\/api\/admin\/tags\/(\d{1,12})$/,
      auth: 'admin',
      handler: async ({ req, match, admin, ip }) => {
        const id = H.parseId(match);
        const name = H.text((await readJson(req)).name, 'name', 'Tag', { max: 30 }).replace(/\s+/g, ' ');
        transaction(db, () => {
          const old = db.prepare('SELECT name FROM service_tags WHERE id = ?').get(id);
          if (!old) throw new ApiError(404, 'Tag not found.');
          try { db.prepare('UPDATE service_tags SET name = ? WHERE id = ?').run(name, id); }
          catch (err) { if (/UNIQUE/i.test(err.message)) throw new ApiError(409, 'That tag already exists.', { field: 'name' }); throw err; }
          writeAudit(db, { admin, action: 'tag.rename', resourceType: 'tag', resourceId: id, ip, details: { from: old.name, to: name } });
        });
        return { body: { tag: { id, name } } };
      },
    },
    {
      method: 'DELETE',
      re: /^\/api\/admin\/tags\/(\d{1,12})$/,
      auth: 'admin',
      handler: ({ match, admin, ip }) => {
        const id = H.parseId(match);
        transaction(db, () => {
          const old = db.prepare('SELECT name FROM service_tags WHERE id = ?').get(id);
          if (!old) throw new ApiError(404, 'Tag not found.');
          db.prepare('DELETE FROM service_tags WHERE id = ?').run(id);
          writeAudit(db, { admin, action: 'tag.delete', resourceType: 'tag', resourceId: id, ip, details: { name: old.name } });
        });
        return { body: { ok: true } };
      },
    },
  ];
}

module.exports = { buildServicesRoutes };
