'use strict';
const { ApiError } = require('../errors');
const { readJson } = require('../http');
const { transaction } = require('../db');
const { verifyPassword } = require('../security');
const { writeAudit } = require('../audit');
const { encryptSecret } = require('../ai/crypto');
const { runAssistant } = require('../ai/assistant');
const { validateImages, auditVision } = require('../ai/vision');
const { buildTools } = require('../ai/tools');
const { AI_LIMITS } = require('../ai/limits');
const { getProvider, PROVIDER_NAMES } = require('../ai/providers');
const H = require('./helpers');

const READ_PERMISSIONS = ['read_dashboard', 'read_orders', 'read_services', 'read_customers', 'read_wallet', 'read_audit'];
const DEFAULT_PERMISSIONS = Object.fromEntries(READ_PERMISSIONS.map((k) => [k, true]));

// Opt-in capabilities: data leaves the server (to the AI provider) when they are used, so unlike the read
// permissions above they are OFF unless an admin explicitly turns them on (stored value must be exactly true).
const CAPABILITY_PERMISSIONS = ['web_search', 'vision'];
const ALL_PERMISSIONS = [...READ_PERMISSIONS, ...CAPABILITY_PERMISSIONS];
// Whether the capability is actually implemented in this build. The switches existed first (plumbing); the
// steps that built the web_search tool and image analysis flipped these to true.
const CAPABILITY_AVAILABLE = { web_search: true, vision: true };

function getRow(db) {
  return db.prepare('SELECT * FROM ai_settings WHERE id = 1').get();
}

function permissions(row) {
  let stored = {};
  try { stored = JSON.parse(row.tool_permissions || '{}'); } catch { stored = {}; }
  return {
    ...Object.fromEntries(READ_PERMISSIONS.map((k) => [k, stored[k] !== false])), // default on, explicit false turns a tool off
    ...Object.fromEntries(CAPABILITY_PERMISSIONS.map((k) => [k, stored[k] === true])), // default OFF, only explicit true turns it on
  };
}

// What the browser is allowed to see. The key itself never appears here — only whether one is set,
// and its last 4 characters, exactly as the spec requires ("•••• 1234").
function settingsPayload(row) {
  return {
    enabled: row.enabled === 1,
    provider: row.provider,
    availableProviders: PROVIDER_NAMES,
    model: row.model,
    assistantName: row.assistant_name,
    systemInstructions: row.system_instructions || '',
    apiKeyConfigured: Boolean(row.api_key_ciphertext),
    apiKeyLast4: row.api_key_last4,
    toolPermissions: permissions(row),
    visionModel: row.vision_model,
    // Live web search. Whether it is ON is toolPermissions.web_search (default off). The Exa key itself is never returned,
    // not even its last characters: only whether one is saved.
    search: {
      provider: row.search_provider,
      availableProviders: [...AI_LIMITS.SEARCH_PROVIDERS],
      maxResults: row.search_max_results,
      resultChars: row.search_result_chars,
      exaConfigured: Boolean(row.exa_api_key_ciphertext),
    },
    capabilityAvailable: { ...CAPABILITY_AVAILABLE },
    limits: {
      webSearch: { maxQueryChars: AI_LIMITS.WEB_SEARCH_MAX_QUERY_CHARS, maxResults: AI_LIMITS.SEARCH_MAX_RESULTS, resultChars: AI_LIMITS.SEARCH_RESULT_CHARS },
      vision: { maxImages: AI_LIMITS.VISION_MAX_IMAGES, maxImageBytes: AI_LIMITS.VISION_MAX_IMAGE_BYTES },
    },
    financialActionsPermanentlyDisabled: true,
    writeActionsDisabled: true,
    updatedAt: row.updated_at,
  };
}

// Sensitive AI settings changes re-verify the admin's password on every call — a stolen session
// cookie alone is not enough (this mirrors the existing admin password-change endpoint).
async function requireReauth(db, admin, currentPassword, what = 'AI settings') {
  // 403, not 401: this admin IS authenticated, just re-confirming for a sensitive change. The admin
  // panel treats any 401 as "session expired" and force-logs-out; that must never fire here.
  if (typeof currentPassword !== 'string' || !currentPassword) throw new ApiError(403, `Re-enter your admin password to change ${what}.`, { field: 'currentPassword' });
  const row = db.prepare('SELECT password_hash FROM admins WHERE id = ?').get(admin.id);
  if (!(await verifyPassword(currentPassword, row.password_hash))) throw new ApiError(403, 'Your current password is incorrect.', { field: 'currentPassword' });
}

function buildAiRoutes(ctx) {
  const { cfg, db, limiter } = ctx;

  function ownedConversation(id, admin) {
    const row = db.prepare('SELECT * FROM ai_conversations WHERE id = ? AND admin_id = ?').get(id, admin.id);
    if (!row) throw new ApiError(404, 'Conversation not found.');
    return row;
  }

  return [
    // ---------- status (cheap, no reauth — just "is it usable") ----------
    {
      method: 'GET',
      re: /^\/api\/admin\/ai\/status$/,
      auth: 'admin',
      handler: () => {
        const row = getRow(db);
        // vision: whether the chat page should offer "attach image" (assistant on, key set, and image analysis switched on by an admin).
        const vision = row.enabled === 1 && Boolean(row.api_key_ciphertext) && CAPABILITY_AVAILABLE.vision && permissions(row).vision === true;
        return { body: { enabled: row.enabled === 1, configured: Boolean(row.api_key_ciphertext), assistantName: row.assistant_name, vision } };
      },
    },

    // ---------- settings ----------
    { method: 'GET', re: /^\/api\/admin\/ai\/settings$/, auth: 'admin', handler: () => ({ body: settingsPayload(getRow(db)) }) },
    {
      method: 'PATCH',
      re: /^\/api\/admin\/ai\/settings$/,
      auth: 'admin',
      handler: async ({ req, admin, ip }) => {
        const rl = limiter.hit(`ai-settings:${ip}`, cfg.limits.adminAiSettingsPerIp.max, cfg.limits.adminAiSettingsPerIp.windowMs);
        if (!rl.allowed) throw new ApiError(429, 'Too many settings changes. Please slow down.', { headers: { 'Retry-After': String(rl.retryAfterSec) } });

        const body = await readJson(req);
        await requireReauth(db, admin, body.currentPassword);

        const row = getRow(db);
        const next = {};
        const changes = {};
        const capabilityToggles = [];

        if ('enabled' in body) { if (typeof body.enabled !== 'boolean') throw H.bad('Enabled must be true or false.', 'enabled'); next.enabled = body.enabled ? 1 : 0; if ((row.enabled === 1) !== body.enabled) changes.enabled = [row.enabled === 1, body.enabled]; }
        if ('provider' in body) { if (!PROVIDER_NAMES.includes(body.provider)) throw H.bad(`Provider must be one of: ${PROVIDER_NAMES.join(', ')}.`, 'provider'); next.provider = body.provider; if (row.provider !== body.provider) changes.provider = [row.provider, body.provider]; }
        if ('model' in body) { const m = H.text(body.model, 'model', 'Model', { max: 100 }); next.model = m; if (row.model !== m) changes.model = [row.model, m]; }
        if ('visionModel' in body) {
          const vm = H.text(body.visionModel, 'visionModel', 'Vision model', { max: 100 });
          if (!/^[A-Za-z0-9][A-Za-z0-9._\/:-]*$/.test(vm)) throw H.bad('Vision model may only contain letters, numbers and . _ / : -', 'visionModel');
          next.vision_model = vm; if (row.vision_model !== vm) changes.visionModel = [row.vision_model, vm];
        }
        if ('searchProvider' in body) {
          if (!AI_LIMITS.SEARCH_PROVIDERS.includes(body.searchProvider)) throw H.bad(`Search provider must be one of: ${AI_LIMITS.SEARCH_PROVIDERS.join(', ')}.`, 'searchProvider');
          next.search_provider = body.searchProvider; if (row.search_provider !== body.searchProvider) changes.searchProvider = [row.search_provider, body.searchProvider];
        }
        for (const [field, col, lim, label] of [['searchMaxResults', 'search_max_results', AI_LIMITS.SEARCH_MAX_RESULTS, 'Search results'], ['searchResultChars', 'search_result_chars', AI_LIMITS.SEARCH_RESULT_CHARS, 'Search text limit']]) {
          if (!(field in body)) continue;
          const v = body[field];
          if (!Number.isInteger(v) || v < lim.min || v > lim.max) throw H.bad(`${label} must be a whole number from ${lim.min} to ${lim.max}.`, field);
          next[col] = v; if (row[col] !== v) changes[field] = [row[col], v];
        }
        if ('assistantName' in body) { const n = H.text(body.assistantName, 'assistantName', 'Assistant name', { max: 40 }); next.assistant_name = n; if (row.assistant_name !== n) changes.assistantName = [row.assistant_name, n]; }
        if ('systemInstructions' in body) { const t = H.text(body.systemInstructions, 'systemInstructions', 'System instructions', { max: 4000, required: false, multiline: true }); next.system_instructions = t; if ((row.system_instructions || '') !== (t || '')) changes.systemInstructions = true; }
        if ('toolPermissions' in body) {
          const patch = body.toolPermissions;
          if (!patch || typeof patch !== 'object' || Array.isArray(patch)) throw H.bad('Tool permissions must be an object.', 'toolPermissions');
          const bad = Object.keys(patch).find((k) => !ALL_PERMISSIONS.includes(k) || typeof patch[k] !== 'boolean');
          if (bad) throw H.bad(`"${bad}" is not a valid, togglable permission.`, 'toolPermissions');
          const before = permissions(row);
          const merged = { ...before, ...patch };
          next.tool_permissions = JSON.stringify(merged);
          changes.toolPermissions = merged;
          for (const k of CAPABILITY_PERMISSIONS) if (merged[k] !== before[k]) capabilityToggles.push({ capability: k, enabled: merged[k] });
        }

        let keyChanged = false;
        if ('apiKey' in body && body.apiKey !== null && body.apiKey !== '') {
          const key = H.text(body.apiKey, 'apiKey', 'API key', { min: 8, max: 300 });
          next.api_key_ciphertext = encryptSecret(cfg.aiEncryptionKey, key);
          next.api_key_last4 = key.slice(-4);
          keyChanged = true;
        } else if (body.apiKey === null) {
          next.api_key_ciphertext = null; next.api_key_last4 = null; keyChanged = true;
        }

        // The Exa key is its own secret, stored the same way as the AI provider key (encrypted, never returned, never audited).
        let exaKeyChanged = false;
        if ('exaApiKey' in body && body.exaApiKey !== null && body.exaApiKey !== '') {
          if (typeof body.exaApiKey !== 'string' || !AI_LIMITS.EXA_KEY_PATTERN.test(body.exaApiKey.trim())) throw H.bad('The Exa API key may only contain letters, numbers and . _ - (8 to 300 characters).', 'exaApiKey');
          next.exa_api_key_ciphertext = encryptSecret(cfg.aiEncryptionKey, body.exaApiKey.trim());
          exaKeyChanged = true;
        } else if (body.exaApiKey === null) {
          next.exa_api_key_ciphertext = null; exaKeyChanged = true;
        }

        if (!Object.keys(next).length) throw new ApiError(400, 'No valid settings were provided.');

        transaction(db, () => {
          const cols = Object.keys(next).map((c) => `${c} = ?`).join(', ');
          db.prepare(`UPDATE ai_settings SET ${cols}, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), updated_by_admin_id = ? WHERE id = 1`).run(...Object.values(next), admin.id);
          if (Object.keys(changes).length) writeAudit(db, { admin, action: 'AI_SETTINGS_CHANGED', resourceType: 'ai_settings', ip, details: changes });
          if (keyChanged) writeAudit(db, { admin, action: 'AI_API_KEY_UPDATED', resourceType: 'ai_settings', ip, details: { removed: next.api_key_ciphertext === null } });
          if (exaKeyChanged) writeAudit(db, { admin, action: 'AI_EXA_KEY_UPDATED', resourceType: 'ai_settings', ip, details: { removed: next.exa_api_key_ciphertext === null } });
          for (const t of capabilityToggles) writeAudit(db, { admin, action: t.enabled ? 'AI_CAPABILITY_ENABLED' : 'AI_CAPABILITY_DISABLED', resourceType: 'ai_settings', ip, details: { capability: t.capability } });
          if ('enabled' in next) writeAudit(db, { admin, action: next.enabled ? 'AI_ENABLED' : 'AI_DISABLED', resourceType: 'ai_settings', ip });
        });
        return { body: settingsPayload(getRow(db)) };
      },
    },

    // ---------- conversations (each admin sees only their own) ----------
    {
      method: 'GET',
      re: /^\/api\/admin\/ai\/conversations$/,
      auth: 'admin',
      handler: ({ admin, url }) => {
        const { limit, offset } = H.paging(url.searchParams, 20);
        const rows = db.prepare('SELECT id, title, created_at, updated_at FROM ai_conversations WHERE admin_id = ? ORDER BY id DESC LIMIT ? OFFSET ?').all(admin.id, limit, offset);
        return { body: { conversations: rows.map((r) => ({ id: r.id, title: r.title, createdAt: r.created_at, updatedAt: r.updated_at })) } };
      },
    },
    {
      method: 'POST',
      re: /^\/api\/admin\/ai\/conversations$/,
      auth: 'admin',
      handler: ({ admin }) => {
        const id = Number(db.prepare("INSERT INTO ai_conversations (admin_id, title) VALUES (?, 'New chat')").run(admin.id).lastInsertRowid);
        return { status: 201, body: { conversation: { id, title: 'New chat' } } };
      },
    },
    {
      method: 'GET',
      re: /^\/api\/admin\/ai\/conversations\/(\d{1,12})\/messages$/,
      auth: 'admin',
      handler: ({ match, admin }) => {
        const conv = ownedConversation(H.parseId(match), admin);
        const rows = db.prepare("SELECT role, content, tool_name, created_at FROM ai_messages WHERE conversation_id = ? AND role != 'tool' ORDER BY id").all(conv.id);
        return { body: { messages: rows.map((m) => ({ role: m.role, content: m.content, createdAt: m.created_at })) } };
      },
    },
    {
      method: 'DELETE',
      re: /^\/api\/admin\/ai\/conversations\/(\d{1,12})$/,
      auth: 'admin',
      handler: ({ match, admin, ip }) => {
        const conv = ownedConversation(H.parseId(match), admin);
        db.prepare('DELETE FROM ai_conversations WHERE id = ?').run(conv.id);
        writeAudit(db, { admin, action: 'AI_CONVERSATION_DELETED', resourceType: 'ai_conversation', resourceId: conv.id, ip });
        return { body: { ok: true } };
      },
    },

    // ---------- chat ----------
    // One handler, two routes. The text route is exactly what it always was (16 KB body limit). The image route
    // is the ONLY place images are accepted; it has its own larger body limit, refuses to read that body at all
    // unless image analysis is switched on, and validates every image before anything is sent anywhere.
    ...[{ withImages: false, re: /^\/api\/admin\/ai\/chat$/ }, { withImages: true, re: /^\/api\/admin\/ai\/chat\/images$/ }].map(({ withImages, re }) => ({
      method: 'POST',
      re,
      auth: 'admin',
      handler: async ({ req, admin, ip }) => {
        const perAdmin = limiter.hit(`ai-chat:admin:${admin.id}`, cfg.limits.adminAiChatPerAdmin.max, cfg.limits.adminAiChatPerAdmin.windowMs);
        if (!perAdmin.allowed) throw new ApiError(429, 'You are sending messages too quickly. Please wait a moment.', { headers: { 'Retry-After': String(perAdmin.retryAfterSec) } });
        const perIp = limiter.hit(`ai-chat:ip:${ip}`, cfg.limits.adminAiChatPerIp.max, cfg.limits.adminAiChatPerIp.windowMs);
        if (!perIp.allowed) throw new ApiError(429, 'Too many requests. Please slow down.', { headers: { 'Retry-After': String(perIp.retryAfterSec) } });

        const disabled = (r) => ({ body: { content: `${r.assistant_name} is currently disabled. An admin can turn it on in Settings.`, toolsUsed: [], conversationId: null } });
        const blocked = (reason, extra) => auditVision(db, { admin, ip, action: 'AI_VISION_BLOCKED', details: { reason, ...extra } });

        if (withImages) {
          // Decided BEFORE the (large) body is read, so an admin who may not use images cannot even make the server buffer them.
          const early = getRow(db);
          if (early.enabled !== 1) return disabled(early);
          if (!CAPABILITY_AVAILABLE.vision || permissions(early).vision !== true) {
            blocked('disabled');
            throw new ApiError(403, 'Image analysis is switched off. An admin can turn it on in Settings > AI Assistant.');
          }
        }

        let body;
        try {
          body = await readJson(req, withImages ? AI_LIMITS.VISION_MAX_BODY_BYTES : undefined);
        } catch (e) {
          if (withImages && e instanceof ApiError && e.status === 413) blocked('body_too_large');
          throw e;
        }
        if (!withImages && body.images !== undefined) throw new ApiError(400, 'Images must be sent through the image upload, not the text chat.');
        const message = H.text(body.message, 'message', 'Message', { max: 2000 });

        let images = null;
        if (withImages) {
          const v = validateImages(body.images);
          if (!v.ok) { blocked(v.reason); throw new ApiError(v.status, v.message, { field: 'images' }); }
          images = v.images;
        }

        const row = getRow(db);
        if (row.enabled !== 1) return disabled(row);

        let conv = body.conversationId ? ownedConversation(Number(body.conversationId), admin) : null;
        const isNew = !conv;
        if (!conv) {
          const title = message.length > 60 ? message.slice(0, 57) + '…' : message;
          const id = Number(db.prepare('INSERT INTO ai_conversations (admin_id, title) VALUES (?, ?)').run(admin.id, title).lastInsertRowid);
          conv = { id };
        }
        if (isNew) writeAudit(db, { admin, action: 'AI_CHAT_STARTED', resourceType: 'ai_conversation', resourceId: conv.id, ip });

        const history = db.prepare("SELECT role, content FROM ai_messages WHERE conversation_id = ? AND role != 'tool' ORDER BY id").all(conv.id);
        // Only the admin's own words and a note that images were attached are saved. The images themselves, and the description of them, never are.
        const saved = images ? `${message}\n\n[${images.length} image${images.length === 1 ? '' : 's'} attached: analysed once, never saved]` : message;
        db.prepare("INSERT INTO ai_messages (conversation_id, role, content) VALUES (?, 'user', ?)").run(conv.id, saved);

        let result;
        try {
          result = await runAssistant(ctx, { admin, settingsRow: row, history, userMessage: message, ip, images });
        } catch {
          result = { content: `${row.assistant_name} is temporarily unavailable.`, toolsUsed: [] };
        }

        db.prepare("INSERT INTO ai_messages (conversation_id, role, content) VALUES (?, 'assistant', ?)").run(conv.id, result.content);
        db.prepare("UPDATE ai_conversations SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?").run(conv.id);

        return { body: { content: result.content, toolsUsed: result.toolsUsed, conversationId: conv.id } };
      },
    })),
  ];
}

module.exports = { buildAiRoutes, buildTools, requireReauth };
