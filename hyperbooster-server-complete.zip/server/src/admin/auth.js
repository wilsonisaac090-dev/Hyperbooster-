'use strict';
const crypto = require('node:crypto');
const { ApiError } = require('../errors');
const { parseCookies, serializeCookie } = require('../http');
const { sha256 } = require('../security');
const { getSettings } = require('../settings');

const MAX_OTP_ATTEMPTS = 5;
const MAX_OTP_RESENDS = 3;
const RESEND_GAP_MS = 30 * 1000;

const cookieOpts = (ctx, maxAgeSec) => ({ maxAgeSec, secure: ctx.cfg.cookieSecure, sameSite: 'Strict' });
const safeEqual = (a, b) => {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};

// ---------- sessions (separate table and cookie from customers) ----------
function getAdminSession(ctx, req) {
  const token = parseCookies(req.headers.cookie)[ctx.cfg.adminCookieName];
  if (!token || token.length > 100) return null;
  const row = ctx.db
    .prepare(
      `SELECT s.id AS session_id, s.csrf_token, a.id, a.email, a.name, a.role, a.status
         FROM admin_sessions s JOIN admins a ON a.id = s.admin_id
        WHERE s.token_hash = ? AND s.expires_at > ?`
    )
    .get(sha256(token), Date.now());
  return row && row.status === 'active' ? row : null;
}

function createAdminSession(ctx, req, adminId, ip) {
  const hours = getSettings(ctx.db).adminSessionHours;
  const token = crypto.randomBytes(32).toString('base64url');
  const csrfToken = crypto.randomBytes(24).toString('base64url');
  ctx.db
    .prepare('DELETE FROM admin_sessions WHERE expires_at <= ?')
    .run(Date.now());
  ctx.db
    .prepare('INSERT INTO admin_sessions (admin_id, token_hash, csrf_token, expires_at, ip, user_agent) VALUES (?,?,?,?,?,?)')
    .run(adminId, sha256(token), csrfToken, Date.now() + hours * 3600 * 1000, ip ?? null, String(req.headers['user-agent'] || '').slice(0, 255));
  return { cookie: serializeCookie(ctx.cfg.adminCookieName, token, cookieOpts(ctx, hours * 3600)), csrfToken };
}

function clearAdminSessionCookie(ctx) {
  return serializeCookie(ctx.cfg.adminCookieName, '', cookieOpts(ctx, 0));
}

function destroyAdminSession(ctx, req) {
  const token = parseCookies(req.headers.cookie)[ctx.cfg.adminCookieName];
  if (token && token.length <= 100) ctx.db.prepare('DELETE FROM admin_sessions WHERE token_hash = ?').run(sha256(token));
}

function requireCsrf(session, req) {
  const sent = req.headers['x-csrf-token'];
  if (typeof sent !== 'string' || !safeEqual(sent, session.csrf_token)) {
    throw new ApiError(403, 'Security check failed. Please refresh the page and try again.');
  }
}

// ---------- one-time email code ----------
function newCode() {
  return String(crypto.randomInt(0, 1000000)).padStart(6, '0');
}
const codeHash = (token, code) => sha256(`${token}:${code}`);

function createChallenge(ctx, adminId, ip) {
  const { otpTtlMinutes } = getSettings(ctx.db);
  const token = crypto.randomBytes(32).toString('base64url');
  const code = newCode();
  ctx.db.prepare('DELETE FROM admin_login_challenges WHERE admin_id = ? OR expires_at <= ?').run(adminId, Date.now());
  ctx.db
    .prepare('INSERT INTO admin_login_challenges (admin_id, token_hash, code_hash, last_sent_at, expires_at, ip) VALUES (?,?,?,?,?,?)')
    .run(adminId, sha256(token), codeHash(token, code), Date.now(), Date.now() + otpTtlMinutes * 60000, ip ?? null);
  return { token, code, ttlMinutes: otpTtlMinutes, cookie: serializeCookie(ctx.cfg.adminChallengeCookieName, token, cookieOpts(ctx, otpTtlMinutes * 60)) };
}

function readChallengeToken(ctx, req) {
  const token = parseCookies(req.headers.cookie)[ctx.cfg.adminChallengeCookieName];
  return token && token.length <= 100 ? token : null;
}

function findChallenge(ctx, req) {
  const token = readChallengeToken(ctx, req);
  if (!token) throw new ApiError(401, 'Please sign in again.');
  const row = ctx.db
    .prepare(
      `SELECT c.*, a.email, a.name, a.status AS admin_status
         FROM admin_login_challenges c JOIN admins a ON a.id = c.admin_id WHERE c.token_hash = ?`
    )
    .get(sha256(token));
  if (!row || row.expires_at <= Date.now() || row.admin_status !== 'active') {
    if (row) ctx.db.prepare('DELETE FROM admin_login_challenges WHERE id = ?').run(row.id);
    throw new ApiError(401, 'This code has expired. Please sign in again.');
  }
  return { row, token };
}

function verifyChallenge(ctx, req, code) {
  const { row, token } = findChallenge(ctx, req);
  if (row.attempts >= MAX_OTP_ATTEMPTS) {
    ctx.db.prepare('DELETE FROM admin_login_challenges WHERE id = ?').run(row.id);
    throw new ApiError(429, 'Too many wrong codes. Please sign in again.');
  }
  if (!safeEqual(codeHash(token, code), row.code_hash)) {
    const attempts = row.attempts + 1;
    if (attempts >= MAX_OTP_ATTEMPTS) ctx.db.prepare('DELETE FROM admin_login_challenges WHERE id = ?').run(row.id);
    else ctx.db.prepare('UPDATE admin_login_challenges SET attempts = ? WHERE id = ?').run(attempts, row.id);
    throw new ApiError(401, 'Incorrect code.');
  }
  ctx.db.prepare('DELETE FROM admin_login_challenges WHERE id = ?').run(row.id);
  return { id: row.admin_id, email: row.email, name: row.name };
}

function refreshChallenge(ctx, req) {
  const { row, token } = findChallenge(ctx, req);
  if (row.resends >= MAX_OTP_RESENDS) throw new ApiError(429, 'Too many resend requests. Please sign in again.');
  const wait = row.last_sent_at + RESEND_GAP_MS - Date.now();
  if (wait > 0) throw new ApiError(429, `Please wait ${Math.ceil(wait / 1000)} seconds before requesting another code.`, { headers: { 'Retry-After': String(Math.ceil(wait / 1000)) } });
  const code = newCode();
  const { otpTtlMinutes } = getSettings(ctx.db);
  ctx.db
    .prepare('UPDATE admin_login_challenges SET code_hash = ?, attempts = 0, resends = resends + 1, last_sent_at = ?, expires_at = ? WHERE id = ?')
    .run(codeHash(token, code), Date.now(), Date.now() + otpTtlMinutes * 60000, row.id);
  return { code, ttlMinutes: otpTtlMinutes, email: row.email };
}

const maskEmail = (email) => {
  const [user, domain] = String(email).split('@');
  return `${user.slice(0, 1)}${'*'.repeat(Math.max(2, Math.min(6, user.length - 1)))}@${domain}`;
};

module.exports = {
  getAdminSession, createAdminSession, clearAdminSessionCookie, destroyAdminSession, requireCsrf,
  createChallenge, verifyChallenge, refreshChallenge, maskEmail,
  clearChallengeCookie: (ctx) => serializeCookie(ctx.cfg.adminChallengeCookieName, '', cookieOpts(ctx, 0)),
};
