'use strict';
const { ApiError } = require('../errors');
const { readJson } = require('../http');
const { writeAudit } = require('../audit');
const { getRow, maskLast4, withEffectiveKora, withEffectiveProvider, saveCredential } = require('../credentials');
const { getBalance, ProviderError } = require('../provider/client');
const { queryCharge, KoraError } = require('../kora/client');
const { requireReauth } = require('./aiRoutes');
const H = require('./helpers');

const NAMES = { provider: 'NigeriaSMM', kora: 'KoraPay' };

function buildIntegrationsRoutes(ctx) {
  const { cfg, db, limiter } = ctx;
  const lastTest = {}; // in-memory, per process: name -> { ok, at }

  // What the browser may see: state and the LAST FOUR characters. Never the key.
  function describe(name) {
    const eff = name === 'provider' ? withEffectiveProvider(cfg, db).provider : withEffectiveKora(cfg, db).kora;
    const key = name === 'provider' ? eff.apiKey : eff.secretKey;
    const row = getRow(db, name);
    const configured = Boolean(key);
    const t = lastTest[name];
    const status = !configured ? 'not_configured' : t ? (t.ok ? 'connected' : 'error') : 'configured';
    return {
      id: name,
      name: NAMES[name],
      status,
      source: row ? 'admin' : configured ? 'environment' : null,
      keyMasked: configured ? maskLast4(key.slice(-4)) : null,
      url: name === 'provider' ? eff.apiUrl : eff.baseUrl,
      lastTestAt: t ? t.at : null,
    };
  }

  function groq() {
    const row = db.prepare('SELECT * FROM ai_settings WHERE id = 1').get();
    return {
      id: 'groq',
      name: 'Groq / EL Assistant',
      status: row.api_key_ciphertext ? 'configured' : 'not_configured',
      source: row.api_key_ciphertext ? 'admin' : null,
      keyMasked: row.api_key_last4 ? maskLast4(row.api_key_last4) : null,
      url: null,
      model: row.model,
      lastTestAt: null,
    };
  }

  const limit = (ip, key) => {
    const l = cfg.limits.adminAiSettingsPerIp;
    const rl = limiter.hit(`${key}:${ip}`, l.max, l.windowMs);
    if (!rl.allowed) throw new ApiError(429, 'Too many attempts. Please slow down.', { headers: { 'Retry-After': String(rl.retryAfterSec) } });
  };
  const nameOf = (match) => {
    if (!NAMES[match[1]]) throw new ApiError(404, 'Unknown integration.');
    return match[1];
  };

  return [
    { method: 'GET', re: /^\/api\/admin\/integrations$/, auth: 'admin', handler: () => ({ body: { integrations: [describe('provider'), describe('kora'), groq()] } }) },

    {
      method: 'PUT',
      re: /^\/api\/admin\/integrations\/(provider|kora)\/key$/,
      auth: 'admin',
      handler: async ({ req, admin, ip, match }) => {
        limit(ip, 'integration-key');
        const name = nameOf(match);
        const body = await readJson(req);
        await requireReauth(db, admin, body.currentPassword, `${NAMES[name]} credentials`); // server-enforced, every time
        const apiKey = H.text(body.apiKey, 'apiKey', 'API key', { min: 8, max: 300 });
        if (/\s/.test(apiKey)) throw H.bad('An API key cannot contain spaces.', 'apiKey');
        saveCredential(ctx, { name, apiKey, admin, ip });
        delete lastTest[name]; // a new key has not been tested yet
        return { body: { integration: describe(name) } };
      },
    },

    {
      method: 'POST',
      re: /^\/api\/admin\/integrations\/(provider|kora)\/test$/,
      auth: 'admin',
      handler: async ({ admin, ip, match }) => {
        limit(ip, 'integration-test');
        const name = nameOf(match);
        let ok = false;
        let message;
        try {
          if (name === 'provider') {
            const pcfg = withEffectiveProvider(cfg, db);
            if (!pcfg.provider.configured) throw new ApiError(400, 'No API key is set yet.');
            // "balance" is a read-only call: it proves the key works without placing any order.
            await getBalance(pcfg, ctx.providerFetch);
            ok = true; message = 'Connected. NigeriaSMM accepted the API key.';
          } else {
            const kcfg = withEffectiveKora(cfg, db);
            if (!kcfg.kora.configured) throw new ApiError(400, 'No secret key is set yet.');
            // Looks up a reference that cannot exist. Kora answers "not found" ONLY if the key was
            // accepted, and 401/403 if not — no payment or charge is ever created.
            try {
              await queryCharge(kcfg, 'hb-connection-test-does-not-exist', ctx.koraFetch);
              ok = true;
            } catch (e) {
              if (e instanceof KoraError && e.message === 'api_error' && ![401, 403].includes(e.httpStatus)) ok = true;
              else throw e;
            }
            message = ok ? 'Connected. Kora accepted the secret key.' : '';
          }
        } catch (e) {
          if (e instanceof ApiError) throw e;
          ok = false;
          const auth = (e instanceof KoraError && [401, 403].includes(e.httpStatus)) || (e instanceof ProviderError && e.message === 'rejected');
          message = auth ? 'The key was rejected. Check it and use Update Key.' : 'Could not reach the provider. Try again shortly.';
        }
        lastTest[name] = { ok, at: new Date().toISOString() };
        writeAudit(db, { admin, action: 'INTEGRATION_TESTED', resourceType: 'integration', resourceId: name, ip, details: { integration: name, ok } });
        return { body: { ok, message, integration: describe(name) } };
      },
    },
  ];
}

module.exports = { buildIntegrationsRoutes };
