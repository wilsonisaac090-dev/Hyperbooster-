'use strict';
const { ApiError } = require('../errors');
const { readJson } = require('../http');
const { transaction } = require('../db');
const { applyLedger } = require('../wallet');
const { writeAudit } = require('../audit');
const H = require('./helpers');

function buildCustomersRoutes(ctx) {
  const { db } = ctx;

  const SPENT = "COALESCE((SELECT -SUM(l.amount_kobo) FROM wallet_ledger l WHERE l.user_id = u.id AND l.entry_type IN ('order_charge','order_refund')), 0)";

  const shape = (r) => ({
    id: r.id,
    fullName: r.full_name,
    email: r.email,
    status: r.status,
    balanceKobo: r.balance_kobo,
    orderCount: r.order_count,
    totalSpentKobo: r.total_spent_kobo,
    createdAt: r.created_at,
    lastActivityAt: [r.last_login_at, r.last_order_at].filter(Boolean).sort().pop() || null,
  });

  const SELECT = `SELECT u.id, u.email, u.full_name, u.status, u.balance_kobo, u.created_at, u.last_login_at,
      (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.id) AS order_count,
      ${SPENT} AS total_spent_kobo,
      (SELECT MAX(o.created_at) FROM orders o WHERE o.user_id = u.id) AS last_order_at
    FROM users u`;

  function detail(id) {
    const row = db.prepare(`${SELECT} WHERE u.id = ?`).get(id);
    if (!row) throw new ApiError(404, 'Customer not found.');
    const orders = db.prepare('SELECT id, service_name, platform, quantity, charge_kobo, status, link, created_at FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 50').all(id)
      .map((o) => ({ id: o.id, serviceName: o.service_name, platform: o.platform, quantity: o.quantity, amountKobo: o.charge_kobo, status: o.status, link: o.link, createdAt: o.created_at }));
    const ledger = db.prepare(`SELECT l.id, l.entry_type, l.amount_kobo, l.balance_after_kobo, l.description, l.reference_type, l.reference_id, l.created_at, a.email AS admin_email FROM wallet_ledger l LEFT JOIN admins a ON a.id = l.admin_id WHERE l.user_id = ? ORDER BY l.id DESC LIMIT 100`).all(id)
      .map((l) => ({ id: l.id, type: l.entry_type, amountKobo: l.amount_kobo, balanceAfterKobo: l.balance_after_kobo, description: l.description, referenceType: l.reference_type, referenceId: l.reference_id, adminEmail: l.admin_email, createdAt: l.created_at }));
    const deposits = db.prepare('SELECT id, reference, amount_kobo, verified_amount_kobo, status, gateway, failure_reason, created_at, paid_at FROM deposits WHERE user_id = ? ORDER BY id DESC LIMIT 20').all(id)
      .map((d) => ({ id: d.id, reference: d.reference, amountKobo: d.amount_kobo, verifiedAmountKobo: d.verified_amount_kobo, status: d.status, gateway: d.gateway, failureReason: d.failure_reason, createdAt: d.created_at, paidAt: d.paid_at }));
    return { customer: shape(row), orders, ledger, deposits };
  }

  return [
    {
      method: 'GET',
      re: /^\/api\/admin\/customers$/,
      auth: 'admin',
      handler: ({ url }) => {
        const q = url.searchParams;
        const where = [];
        const params = [];
        const term = (q.get('q') || '').trim().slice(0, 80);
        if (term) {
          const like = `%${H.likeEscape(term)}%`;
          where.push("(u.email LIKE ? ESCAPE '\\' OR u.full_name LIKE ? ESCAPE '\\')");
          params.push(like, like);
        }
        if (q.get('status') === 'active' || q.get('status') === 'suspended') { where.push('u.status = ?'); params.push(q.get('status')); }
        const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
        const { limit, offset } = H.paging(q, 20);
        const total = db.prepare(`SELECT COUNT(*) AS n FROM users u ${clause}`).get(...params).n;
        const rows = db.prepare(`${SELECT} ${clause} ORDER BY u.id DESC LIMIT ? OFFSET ?`).all(...params, limit, offset);
        return { body: { total, customers: rows.map(shape) } };
      },
    },
    { method: 'GET', re: /^\/api\/admin\/customers\/(\d{1,12})$/, auth: 'admin', handler: ({ match }) => ({ body: detail(H.parseId(match)) }) },

    // Manual wallet credit/debit: always a ledger entry with the admin's identity and a reason.
    {
      method: 'POST',
      re: /^\/api\/admin\/customers\/(\d{1,12})\/wallet$/,
      auth: 'admin',
      handler: async ({ req, match, admin, ip }) => {
        const id = H.parseId(match);
        const body = await readJson(req);
        if (body.type !== 'credit' && body.type !== 'debit') throw H.bad('Choose credit or debit.', 'type');
        const amountKobo = H.int(body.amountKobo, 'amountKobo', 'Amount', { min: 1, max: 1000000000 });
        const reason = H.text(body.reason, 'reason', 'Reason', { min: 3, max: 200 });

        transaction(db, () => {
          const user = db.prepare('SELECT id FROM users WHERE id = ?').get(id);
          if (!user) throw new ApiError(404, 'Customer not found.');
          let result;
          try {
            result = applyLedger(db, {
              userId: id,
              deltaKobo: body.type === 'credit' ? amountKobo : -amountKobo,
              type: 'adjustment',
              referenceType: 'admin',
              description: `Manual ${body.type}: ${reason}`,
              adminId: admin.id,
            });
          } catch (err) {
            if (err instanceof ApiError && err.status === 402) throw new ApiError(400, "The customer's wallet does not have enough balance for this debit.", { field: 'amountKobo' });
            throw err;
          }
          writeAudit(db, { admin, action: body.type === 'credit' ? 'wallet.credit' : 'wallet.debit', resourceType: 'customer', resourceId: id, ip, details: { amountKobo, reason, balanceAfterKobo: result.balanceKobo, ledgerEntryId: result.entryId } });
        });
        return { body: detail(id) };
      },
    },

    {
      method: 'POST',
      re: /^\/api\/admin\/customers\/(\d{1,12})\/status$/,
      auth: 'admin',
      handler: async ({ req, match, admin, ip }) => {
        const id = H.parseId(match);
        const body = await readJson(req);
        if (body.status !== 'active' && body.status !== 'suspended') throw H.bad('Status must be active or suspended.', 'status');
        transaction(db, () => {
          const user = db.prepare('SELECT status FROM users WHERE id = ?').get(id);
          if (!user) throw new ApiError(404, 'Customer not found.');
          if (user.status === body.status) return;
          db.prepare("UPDATE users SET status = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?").run(body.status, id);
          if (body.status === 'suspended') db.prepare('DELETE FROM sessions WHERE user_id = ?').run(id);
          writeAudit(db, { admin, action: 'customer.status_change', resourceType: 'customer', resourceId: id, ip, details: { from: user.status, to: body.status } });
        });
        return { body: detail(id) };
      },
    },
  ];
}

module.exports = { buildCustomersRoutes };
