'use strict';
const { buildAuthRoutes } = require('./authRoutes');
const { buildServicesRoutes } = require('./servicesRoutes');
const { buildOrdersRoutes } = require('./ordersRoutes');
const { buildCustomersRoutes } = require('./customersRoutes');
const { buildSettingsRoutes } = require('./settingsRoutes');
const { buildAiRoutes } = require('./aiRoutes');
const { buildIntegrationsRoutes } = require('./integrationsRoutes');

function buildAdminRoutes(ctx) {
  return [
    ...buildAuthRoutes(ctx),
    ...buildSettingsRoutes(ctx),
    ...buildServicesRoutes(ctx),
    ...buildOrdersRoutes(ctx),
    ...buildCustomersRoutes(ctx),
    ...buildAiRoutes(ctx),
    ...buildIntegrationsRoutes(ctx),
  ];
}

module.exports = { buildAdminRoutes };
