'use strict';
const { ApiError } = require('../errors');
const { readJson } = require('../http');
const { hashPassword, verifyPassword, verifyDummy } = require('../security');
const { writeAudit } = require('../audit');
const { getSettings } = require('../settings');
const A = require('./auth');

const tooMany = (rl, msg = 'Too many attempts. Please try again later.') =>
  new ApiError(429, msg, { headers: { 'Retry-After': String(rl.retryAfterSec) } });

const otpMail = (code, ttl, siteName) => ({
  subject: `${siteName} admin sign-in code`,
  text: `Your ${siteName} admin sign-in code is ${code}\n\nIt expires in ${ttl} minutes. If you did not try to sign in, change your admin password now.`,
});

function buildAuthRoutes(ctx) {
  const { cfg, db, limiter } = ctx;
  const L = cfg.limits;

  return [
    // Step 1: email + password. On success a one-time code is emailed (nothing is signed in yet).
    {
      method: 'POST',
      re: /^\/api\/admin\/login$/,
      auth: 'none',
      handler: async ({ req, ip }) => {
        const rlIp = limiter.hit(`adm-login:ip:${ip}`, L.adminLoginPerIp.max, L.adminLoginPerIp.windowMs);
        if (!rlIp.allowed) throw tooMany(rlIp);

        const body = await readJson(req);
        if (typeof body.email !== 'string' || typeof body.password !== 'string' || !body.email || !body.password) {
          throw new ApiError(400, 'Email and password are required.');
        }
        const email = body.email.trim().toLowerCase().slice(0, 254);
        const password = body.password.slice(0, 200);

        const acctKey = `adm-login:acct:${ip}|${email}`;
        const blocked = limiter.isBlocked(acctKey, L.adminLoginPerAccount.max);
        if (blocked.blocked) throw tooMany(blocked);

        const admin = db.prepare('SELECT * FROM admins WHERE email = ?').get(email);
        let ok = false;
        if (admin && admin.status === 'active') ok = await verifyPassword(password, admin.password_hash);
        else await verifyDummy(password);

        if (!ok) {
          limiter.hit(acctKey, L.adminLoginPerAccount.max, L.adminLoginPerAccount.windowMs);
          writeAudit(db, { adminEmail: email, action: 'admin.login_failed', ip });
          throw new ApiError(401, 'Invalid email or password.');
        }
        limiter.clear(acctKey);

        if (cfg.mailTransport === 'none') {
          throw new ApiError(503, 'Email delivery is not configured on the server, so admin sign-in is unavailable.');
        }
        const challenge = A.createChallenge(ctx, admin.id, ip);
        const mail = otpMail(challenge.code, challenge.ttlMinutes, getSettings(db).siteName);
        try {
          await ctx.mailer.send({ to: admin.email, ...mail });
        } catch (err) {
          db.prepare('DELETE FROM admin_login_challenges WHERE admin_id = ?').run(admin.id);
          console.error('Admin code email failed:', err.message);
          throw new ApiError(503, 'Could not send the verification email. Please try again.');
        }
        return { headers: { 'Set-Cookie': challenge.cookie }, body: { step: 'otp', maskedEmail: A.maskEmail(admin.email), ttlMinutes: challenge.ttlMinutes } };
      },
    },

    // Step 2: the emailed code. Only now is a session created.
    {
      method: 'POST',
      re: /^\/api\/admin\/verify-otp$/,
      auth: 'none',
      handler: async ({ req, ip }) => {
        const rl = limiter.hit(`adm-otp:ip:${ip}`, L.adminOtpPerIp.max, L.adminOtpPerIp.windowMs);
        if (!rl.allowed) throw tooMany(rl);
        const body = await readJson(req);
        if (typeof body.code !== 'string' || !/^\d{6}$/.test(body.code.trim())) throw new ApiError(400, 'Enter the 6-digit code.', { field: 'code' });

        let admin;
        try {
          admin = A.verifyChallenge(ctx, req, body.code.trim());
        } catch (err) {
          if (err instanceof ApiError && err.status !== 400) writeAudit(db, { action: 'admin.otp_failed', ip, details: { reason: err.message } });
          throw err;
        }
        const session = A.createAdminSession(ctx, req, admin.id, ip);
        db.prepare("UPDATE admins SET last_login_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?").run(admin.id);
        writeAudit(db, { admin, action: 'admin.login', resourceType: 'admin', resourceId: admin.id, ip });
        return {
          headers: { 'Set-Cookie': [session.cookie, A.clearChallengeCookie(ctx)] },
          body: { admin: { id: admin.id, email: admin.email, name: admin.name }, csrfToken: session.csrfToken },
        };
      },
    },

    {
      method: 'POST',
      re: /^\/api\/admin\/resend-otp$/,
      auth: 'none',
      handler: async ({ req, ip }) => {
        const rl = limiter.hit(`adm-otp:ip:${ip}`, L.adminOtpPerIp.max, L.adminOtpPerIp.windowMs);
        if (!rl.allowed) throw tooMany(rl);
        const { code, ttlMinutes, email } = A.refreshChallenge(ctx, req);
        try {
          await ctx.mailer.send({ to: email, ...otpMail(code, ttlMinutes, getSettings(db).siteName) });
        } catch (err) {
          console.error('Admin code email failed:', err.message);
          throw new ApiError(503, 'Could not send the verification email. Please try again.');
        }
        return { body: { ok: true, ttlMinutes } };
      },
    },

    {
      method: 'GET',
      re: /^\/api\/admin\/session$/,
      auth: 'admin',
      handler: ({ admin }) => ({ body: { admin: { id: admin.id, email: admin.email, name: admin.name, role: admin.role }, csrfToken: admin.csrf_token } }),
    },

    {
      method: 'POST',
      re: /^\/api\/admin\/logout$/,
      auth: 'admin',
      handler: ({ req, admin, ip }) => {
        A.destroyAdminSession(ctx, req);
        writeAudit(db, { admin, action: 'admin.logout', resourceType: 'admin', resourceId: admin.id, ip });
        return { headers: { 'Set-Cookie': A.clearAdminSessionCookie(ctx) }, body: { ok: true } };
      },
    },
  ];
}

module.exports = { buildAuthRoutes };
