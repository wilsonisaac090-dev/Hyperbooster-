'use strict';
const { ApiError } = require('../errors');
const { readJson } = require('../http');
const { transaction } = require('../db');
const { applyLedger } = require('../wallet');
const { writeAudit } = require('../audit');
const { syncProviderOrders } = require('../provider/orders');
const H = require('./helpers');

// Statuses an admin may set, and which changes are allowed from each current status.
// Completed / canceled / failed are final. Cancelling or failing an order refunds the customer's wallet.
const SETTABLE = ['pending', 'processing', 'completed', 'canceled', 'failed'];
const TRANSITIONS = {
  pending: ['processing', 'completed', 'canceled', 'failed'],
  processing: ['completed', 'canceled', 'failed'],
  in_progress: ['completed', 'canceled', 'failed'],
  partial: [],
  refunded: [],
  completed: [],
  canceled: [],
  failed: [],
};
const REFUNDING = new Set(['canceled', 'failed']);

function buildOrdersRoutes(ctx) {
  const { db } = ctx;

  const listShape = (r) => ({
    id: r.id,
    customer: { id: r.user_id, name: r.full_name, email: r.email },
    serviceId: r.service_id,
    serviceName: r.service_name,
    platform: r.platform,
    serviceType: r.service_type,
    quantity: r.quantity,
    amountKobo: r.charge_kobo,
    status: r.status,
    link: r.link,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  });

  const JOIN = 'FROM orders o JOIN users u ON u.id = o.user_id';
  const COLS = 'o.*, u.full_name, u.email';

  function detail(id) {
    const r = db.prepare(`SELECT ${COLS} ${JOIN} WHERE o.id = ?`).get(id);
    if (!r) throw new ApiError(404, 'Order not found.');
    const ledger = db
      .prepare(`SELECT l.id, l.entry_type, l.amount_kobo, l.balance_after_kobo, l.description, l.created_at, a.email AS admin_email FROM wallet_ledger l LEFT JOIN admins a ON a.id = l.admin_id WHERE l.reference_type = 'order' AND l.reference_id = ? ORDER BY l.id`)
      .all(id)
      .map((l) => ({ id: l.id, type: l.entry_type, amountKobo: l.amount_kobo, balanceAfterKobo: l.balance_after_kobo, description: l.description, adminEmail: l.admin_email, createdAt: l.created_at }));
    return {
      ...listShape(r),
      pricePer1000Kobo: r.price_per_1000_kobo,
      paymentSource: 'Customer wallet',
      providerOrderId: r.provider_order_id,
      providerStatus: r.provider_status,
      startCount: r.start_count,
      remains: r.remains,
      errorMessage: r.error_message,
      completedAt: r.completed_at,
      allowedStatuses: TRANSITIONS[r.status] || [],
      ledger,
    };
  }

  return [
    {
      method: 'GET',
      re: /^\/api\/admin\/orders$/,
      auth: 'admin',
      handler: ({ url }) => {
        const q = url.searchParams;
        const where = [];
        const params = [];
        const status = q.get('status');
        if (status) {
          if (!Object.keys(TRANSITIONS).includes(status)) throw H.bad('Unknown status.', 'status');
          where.push('o.status = ?');
          params.push(status);
        }
        const term = (q.get('q') || '').trim().slice(0, 80);
        if (term) {
          const like = `%${H.likeEscape(term)}%`;
          const parts = ["u.email LIKE ? ESCAPE '\\'", "u.full_name LIKE ? ESCAPE '\\'", "o.link LIKE ? ESCAPE '\\'", "o.service_name LIKE ? ESCAPE '\\'"];
          const ps = [like, like, like, like];
          if (/^#?\d{1,12}$/.test(term)) { parts.push('o.id = ?'); ps.push(Number(term.replace('#', ''))); }
          where.push(`(${parts.join(' OR ')})`);
          params.push(...ps);
        }
        const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
        const { limit, offset } = H.paging(q, 20);
        const total = db.prepare(`SELECT COUNT(*) AS n ${JOIN} ${clause}`).get(...params).n;
        const rows = db.prepare(`SELECT ${COLS} ${JOIN} ${clause} ORDER BY o.id DESC LIMIT ? OFFSET ?`).all(...params, limit, offset);
        return { body: { total, orders: rows.map(listShape) } };
      },
    },
    { method: 'GET', re: /^\/api\/admin\/orders\/(\d{1,12})$/, auth: 'admin', handler: ({ match }) => ({ body: { order: detail(H.parseId(match)) } }) },

    {
      method: 'POST',
      re: /^\/api\/admin\/orders\/(\d{1,12})\/sync$/,
      auth: 'admin',
      handler: async ({ match }) => {
        const id = H.parseId(match);
        const order = db.prepare('SELECT id FROM orders WHERE id = ?').get(id);
        if (!order) throw new ApiError(404, 'Order not found.');
        // Reuses the exact same batched sync the background job runs, scoped to just this one order,
        // bypassing the "don't recheck too soon" staleness window since an admin explicitly asked.
        db.prepare("UPDATE orders SET updated_at = '1970-01-01T00:00:00.000Z' WHERE id = ? AND status = 'processing'").run(id);
        await syncProviderOrders(ctx, { limit: 1000 });
        return { body: { order: detail(id) } };
      },
    },
    {
      method: 'POST',
      re: /^\/api\/admin\/orders\/(\d{1,12})\/status$/,
      auth: 'admin',
      handler: async ({ req, match, admin, ip }) => {
        const id = H.parseId(match);
        const body = await readJson(req);
        if (!SETTABLE.includes(body.status)) throw H.bad(`Status must be one of: ${SETTABLE.join(', ')}.`, 'status');
        const note = H.text(body.note, 'note', 'Note', { max: 200, required: false });

        transaction(db, () => {
          const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
          if (!order) throw new ApiError(404, 'Order not found.');
          if (!(TRANSITIONS[order.status] || []).includes(body.status)) {
            throw new ApiError(409, `An order that is ${order.status.replace('_', ' ')} cannot be changed to ${body.status}.`, { field: 'status' });
          }
          const finished = body.status === 'completed';
          db.prepare(
            `UPDATE orders SET status = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'),
               completed_at = CASE WHEN ? THEN strftime('%Y-%m-%dT%H:%M:%fZ','now') ELSE completed_at END,
               error_message = CASE WHEN ? THEN ? ELSE error_message END WHERE id = ?`
          ).run(body.status, finished ? 1 : 0, body.status === 'failed' ? 1 : 0, note, id);

          let refundedKobo = 0;
          if (REFUNDING.has(body.status) && order.charge_kobo > 0) {
            const r = applyLedger(db, {
              userId: order.user_id,
              deltaKobo: order.charge_kobo,
              type: 'order_refund',
              referenceType: 'order',
              referenceId: id,
              idempotencyKey: `order_refund:${id}`,
              description: `Refund for order #${id} (${body.status})`,
              adminId: admin.id,
            });
            if (!r.duplicate) refundedKobo = order.charge_kobo;
          }
          writeAudit(db, { admin, action: 'order.status_change', resourceType: 'order', resourceId: id, ip, details: { from: order.status, to: body.status, refundedKobo, note } });
        });
        return { body: { order: detail(id) } };
      },
    },
  ];
}

module.exports = { buildOrdersRoutes, SETTABLE, TRANSITIONS };
