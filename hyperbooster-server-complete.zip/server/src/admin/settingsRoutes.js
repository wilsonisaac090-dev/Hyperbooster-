'use strict';
const { ApiError } = require('../errors');
const { readJson } = require('../http');
const { transaction } = require('../db');
const { hashPassword, verifyPassword } = require('../security');
const { getSettings, validateSettingsPatch, saveSettings } = require('../settings');
const { writeAudit } = require('../audit');
const H = require('./helpers');

function buildSettingsRoutes(ctx) {
  const { cfg, db } = ctx;

  // Only "configured or not" is ever reported. Secret values never leave the server.
  const integrations = () => ({
    kora: { configured: cfg.integrations.koraConfigured, integrationBuilt: true },
    provider: { configured: cfg.integrations.providerConfigured, integrationBuilt: true },
    email: { transport: cfg.mailTransport, configured: cfg.mailTransport !== 'none' },
  });

  const payload = (admin) => {
    const row = db.prepare('SELECT last_login_at, password_changed_at FROM admins WHERE id = ?').get(admin.id);
    return {
      settings: getSettings(db),
      integrations: integrations(),
      security: { adminEmail: admin.email, adminName: admin.name, lastLoginAt: row.last_login_at, passwordChangedAt: row.password_changed_at, otpRequired: true },
    };
  };

  return [
    {
      method: 'GET',
      re: /^\/api\/admin\/overview$/,
      auth: 'admin',
      handler: () => {
        const one = (sql) => db.prepare(sql).get();
        const byStatus = Object.fromEntries(db.prepare('SELECT status, COUNT(*) AS n FROM orders GROUP BY status').all().map((r) => [r.status, r.n]));
        return {
          body: {
            totalCustomers: one('SELECT COUNT(*) AS n FROM users').n,
            totalOrders: one('SELECT COUNT(*) AS n FROM orders').n,
            ordersByStatus: {
              pending: byStatus.pending || 0,
              processing: (byStatus.processing || 0) + (byStatus.in_progress || 0),
              completed: byStatus.completed || 0,
              canceled: byStatus.canceled || 0,
              failed: byStatus.failed || 0,
            },
            totalWalletBalanceKobo: one('SELECT COALESCE(SUM(balance_kobo), 0) AS n FROM users').n,
            // net of refunds: what customers have actually paid for orders
            totalCustomerSpendingKobo: one("SELECT COALESCE(-SUM(amount_kobo), 0) AS n FROM wallet_ledger WHERE entry_type IN ('order_charge','order_refund')").n,
            activeServices: one('SELECT COUNT(*) AS n FROM services WHERE is_active = 1').n,
            totalServices: one('SELECT COUNT(*) AS n FROM services').n,
          },
        };
      },
    },

    { method: 'GET', re: /^\/api\/admin\/settings$/, auth: 'admin', handler: ({ admin }) => ({ body: payload(admin) }) },
    {
      method: 'PATCH',
      re: /^\/api\/admin\/settings$/,
      auth: 'admin',
      handler: async ({ req, admin, ip }) => {
        const { out, view } = validateSettingsPatch(await readJson(req));
        transaction(db, () => {
          const before = getSettings(db);
          saveSettings(db, out, admin.id);
          const changes = {};
          for (const [k, v] of Object.entries(view)) if (before[k] !== v) changes[k] = [before[k], v];
          if (Object.keys(changes).length) writeAudit(db, { admin, action: 'settings.update', resourceType: 'settings', ip, details: { changes } });
        });
        return { body: payload(admin) };
      },
    },

    {
      method: 'POST',
      re: /^\/api\/admin\/password$/,
      auth: 'admin',
      handler: async ({ req, admin, ip }) => {
        const body = await readJson(req);
        if (typeof body.currentPassword !== 'string' || !body.currentPassword) throw H.bad('Enter your current password.', 'currentPassword');
        if (typeof body.newPassword !== 'string' || body.newPassword.length < 12) throw H.bad('Use at least 12 characters.', 'newPassword');
        if (body.newPassword.length > 128) throw H.bad('Use 128 characters or fewer.', 'newPassword');
        if (body.newPassword === body.currentPassword) throw H.bad('Choose a different password.', 'newPassword');

        const row = db.prepare('SELECT password_hash FROM admins WHERE id = ?').get(admin.id);
        if (!(await verifyPassword(body.currentPassword, row.password_hash))) throw new ApiError(400, 'Your current password is incorrect.', { field: 'currentPassword' });
        const hash = await hashPassword(body.newPassword);
        transaction(db, () => {
          db.prepare("UPDATE admins SET password_hash = ?, password_changed_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?").run(hash, admin.id);
          // every other signed-in device is signed out
          db.prepare('DELETE FROM admin_sessions WHERE admin_id = ? AND id != ?').run(admin.id, admin.session_id);
          writeAudit(db, { admin, action: 'admin.password_change', resourceType: 'admin', resourceId: admin.id, ip });
        });
        return { body: { ok: true } };
      },
    },

    {
      method: 'GET',
      re: /^\/api\/admin\/audit$/,
      auth: 'admin',
      handler: ({ url }) => {
        const q = url.searchParams;
        const { limit, offset } = H.paging(q, 30);
        const action = q.get('action');
        const clause = action ? 'WHERE a.action = ?' : '';
        const params = action ? [action] : [];
        const total = db.prepare(`SELECT COUNT(*) AS n FROM audit_logs a ${clause}`).get(...params).n;
        const rows = db.prepare(`SELECT a.* FROM audit_logs a ${clause} ORDER BY a.id DESC LIMIT ? OFFSET ?`).all(...params, limit, offset);
        return {
          body: {
            total,
            entries: rows.map((r) => ({ id: r.id, adminEmail: r.admin_email, action: r.action, resourceType: r.resource_type, resourceId: r.resource_id, details: r.details ? JSON.parse(r.details) : null, ip: r.ip, createdAt: r.created_at })),
          },
        };
      },
    },
  ];
}

module.exports = { buildSettingsRoutes };
