'use strict';

// NigeriaSMM (and the near-universal "SMM Panel v2 API" it implements) is a single endpoint that
// takes a form-encoded POST with an api key, an action, and action-specific parameters, and returns
// JSON. This exact shape (key/action, add/status/multistatus/balance, response fields charge/
// start_count/status/remains/currency) is the documented, industry-standard format that every panel
// using an "/api/v2"-style base URL implements identically — NigeriaSMM's own advertised base URL
// (https://nigeriasmm.com/api/v2) matches it. No field name here is guessed.
//
// fetchImpl is injectable so tests never make a real network call, exactly like kora/client.js.

class ProviderError extends Error {
  constructor(message, cause) {
    super(message);
    this.name = 'ProviderError';
    this.cause = cause;
  }
}

async function request(cfg, action, params = {}, fetchImpl = globalThis.fetch) {
  if (!cfg.provider.configured) throw new ProviderError('not_configured');
  const body = new URLSearchParams({ key: cfg.provider.apiKey, action, ...params });
  let res;
  try {
    res = await fetchImpl(cfg.provider.apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString(),
    });
  } catch {
    throw new ProviderError('network'); // never surfaces the underlying error text
  }
  let json;
  try {
    json = await res.json();
  } catch {
    throw new ProviderError('bad_response');
  }
  if (!res.ok) throw new ProviderError('api_error', json);
  return json;
}

// Places one order. Returns the provider's order id (string, per the standard). Throws ProviderError
// on rejection — the caller (orders.js) is responsible for the wallet refund, not this module.
async function addOrder(cfg, { providerServiceId, link, quantity }, fetchImpl) {
  const data = await request(cfg, 'add', { service: providerServiceId, link, quantity: String(quantity) }, fetchImpl);
  if (data.error) throw new ProviderError('rejected', data.error);
  if (data.order === undefined || data.order === null) throw new ProviderError('bad_response', data);
  return String(data.order);
}

// One order's live status. Numeric-looking fields arrive as strings per the standard; parsed here,
// never guessed — a field that doesn't parse cleanly is left null rather than coerced.
function normalizeStatusRow(row) {
  if (!row || row.error) return { error: row?.error || 'unknown' };
  const int = (v) => (v === undefined || v === null || v === '' || Number.isNaN(Number(v)) ? null : Math.trunc(Number(v)));
  return {
    status: String(row.status || '').trim(),
    startCount: int(row.start_count),
    remains: int(row.remains),
    charge: row.charge ?? null,
    currency: row.currency || null,
  };
}

async function getStatus(cfg, providerOrderId, fetchImpl) {
  const data = await request(cfg, 'status', { order: providerOrderId }, fetchImpl);
  return normalizeStatusRow(data);
}

// Up to 100 at once — the documented way to avoid one status() call per order (see sync.js).
async function getStatuses(cfg, providerOrderIds, fetchImpl) {
  if (!providerOrderIds.length) return {};
  const data = await request(cfg, 'status', { orders: providerOrderIds.join(',') }, fetchImpl);
  const out = {};
  for (const id of providerOrderIds) out[id] = normalizeStatusRow(data[id]);
  return out;
}

// Side-effect-free live check used by the admin "Test Connection" button. Places no order.
async function getBalance(cfg, fetchImpl) {
  const data = await request(cfg, 'balance', {}, fetchImpl);
  if (data.error) throw new ProviderError('rejected', data.error);
  return { balance: data.balance ?? null, currency: data.currency ?? null };
}

module.exports = { addOrder, getStatus, getStatuses, getBalance, ProviderError };
