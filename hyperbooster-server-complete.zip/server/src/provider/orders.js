'use strict';
const { transaction } = require('../db');
const { applyLedger } = require('../wallet');
const { addOrder, getStatuses, ProviderError } = require('./client');
const { mapProviderStatus } = require('./statusMap');
const { writeAudit } = require('../audit');
const { withEffectiveProvider } = require('../credentials');

// Refunding always goes through this ONE idempotency key namespace, shared with the admin's manual
// "mark canceled/failed" refund path (src/admin/ordersRoutes.js). Whichever path gets there first wins;
// the other becomes a safe no-op — this is what makes "exactly once" hold across both paths, not just
// within this file.
const refundKey = (orderId) => `order_refund:${orderId}`;

function refundOrderOnce(db, order, reason) {
  if (order.charge_kobo <= 0) return { refunded: false };
  const result = applyLedger(db, {
    userId: order.user_id,
    deltaKobo: order.charge_kobo,
    type: 'order_refund',
    referenceType: 'order',
    referenceId: order.id,
    idempotencyKey: refundKey(order.id),
    description: `Refund for order #${order.id} (${reason})`,
  });
  return { refunded: !result.duplicate, balanceKobo: result.balanceKobo };
}

// Called once, right after the order row + wallet charge have already been committed (see routes.js).
// This is a SEPARATE step on purpose: a network call has no place inside a database transaction.
async function forwardOrderToProvider(ctx, orderId) {
  const { db } = ctx;
  const cfg = withEffectiveProvider(ctx.cfg, db);
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  const svc = db.prepare('SELECT provider_service_id FROM services WHERE id = ?').get(order.service_id);

  if (!cfg.provider.configured || !svc?.provider_service_id) {
    // Not an error: this service simply isn't provider-backed (or no provider is configured yet).
    // The order stays 'pending' for an admin to handle, exactly as before this feature existed.
    return { forwarded: false };
  }

  // Atomic claim: only ONE caller can ever move an order from "not yet sent" to "sending". A retry,
  // a double call, or a race finds the claim taken and does nothing — so the provider is asked at
  // most once per order.
  const claim = db.prepare("UPDATE orders SET provider_status = 'submitting' WHERE id = ? AND status = 'pending' AND provider_order_id IS NULL AND provider_status IS NULL").run(orderId);
  if (Number(claim.changes) === 0) return { forwarded: false, alreadyHandled: true };

  try {
    const providerOrderId = await addOrder(cfg, { providerServiceId: svc.provider_service_id, link: order.link, quantity: order.quantity }, ctx.providerFetch);
    transaction(db, () => {
      db.prepare("UPDATE orders SET status = 'processing', provider_status = NULL, provider_order_id = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ? AND status = 'pending'").run(providerOrderId, orderId);
      writeAudit(db, { action: 'PROVIDER_ORDER_PLACED', resourceType: 'order', resourceId: orderId, details: { providerOrderId } });
    });
    return { forwarded: true, providerOrderId };
  } catch (err) {
    // Only an EXPLICIT provider rejection is safe to refund. A network failure or unreadable reply is
    // ambiguous (the provider may have received the order), so refunding could cause a free order or a
    // duplicate. Those stay pending, flagged, for an admin to resolve.
    if (!(err instanceof ProviderError) || err.message !== 'rejected') {
      writeAudit(db, { action: 'PROVIDER_ORDER_UNCERTAIN', resourceType: 'order', resourceId: orderId, details: { reason: err instanceof ProviderError ? err.message : 'unexpected' } });
      return { forwarded: false, uncertain: true };
    }
    const message = err instanceof ProviderError && typeof err.cause === 'string' ? err.cause : 'The service provider rejected this order.';
    const { refunded, balanceKobo } = transaction(db, () => {
      const fresh = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
      if (fresh.status !== 'pending') return { refunded: false }; // already handled by something else — no-op
      db.prepare("UPDATE orders SET status = 'failed', provider_status = NULL, error_message = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?").run(message.slice(0, 300), orderId);
      const r = refundOrderOnce(db, fresh, 'provider rejected the order');
      writeAudit(db, { action: 'PROVIDER_ORDER_REJECTED', resourceType: 'order', resourceId: orderId, details: { reason: message, refunded: r.refunded } });
      return r;
    });
    return { forwarded: false, failed: true, refunded, balanceKobo };
  }
}

// Batched status sync — see app.js for the periodic caller, and admin/ordersRoutes.js for the
// admin-triggered single-order version. Never runs two overlapping batches (guarded by the caller).
async function syncProviderOrders(ctx, { limit = 100 } = {}) {
  const { db } = ctx;
  const cfg = withEffectiveProvider(ctx.cfg, db);
  if (!cfg.provider.configured) return { checked: 0 };

  const staleBefore = new Date(Date.now() - cfg.providerSyncStaleMs).toISOString();
  const rows = db
    .prepare("SELECT * FROM orders WHERE status = 'processing' AND provider_order_id IS NOT NULL AND updated_at < ? ORDER BY id LIMIT ?")
    .all(staleBefore, limit);
  if (!rows.length) return { checked: 0 };

  let results;
  try {
    results = await getStatuses(cfg, rows.map((r) => r.provider_order_id), ctx.providerFetch);
  } catch {
    return { checked: 0, error: true }; // transient failure: next scheduled run tries again
  }

  let updated = 0;
  for (const order of rows) {
    const status = results[order.provider_order_id];
    if (!status || status.error) {
      db.prepare("UPDATE orders SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?").run(order.id); // bump so we don't hammer a persistently-erroring id
      continue;
    }
    const mapped = mapProviderStatus(status.status);
    transaction(db, () => {
      const fresh = db.prepare('SELECT * FROM orders WHERE id = ?').get(order.id);
      if (fresh.status !== 'processing') return; // already moved on (e.g. an admin already resolved it)
      const finished = mapped === 'completed';
      db.prepare(
        `UPDATE orders SET provider_status = ?, start_count = ?, remains = ?,
           status = COALESCE(?, status), updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'),
           completed_at = CASE WHEN ? THEN strftime('%Y-%m-%dT%H:%M:%fZ','now') ELSE completed_at END
         WHERE id = ?`
      ).run(status.status, status.startCount, status.remains, mapped, finished ? 1 : 0, order.id);
      if (mapped === 'canceled' || mapped === 'refunded') {
        refundOrderOnce(db, fresh, `provider reported ${mapped}`);
      }
      if (mapped) writeAudit(db, { action: 'PROVIDER_STATUS_SYNCED', resourceType: 'order', resourceId: order.id, details: { providerStatus: status.status, mapped } });
    });
    updated += 1;
  }
  return { checked: rows.length, updated };
}

module.exports = { forwardOrderToProvider, syncProviderOrders, refundOrderOnce };
