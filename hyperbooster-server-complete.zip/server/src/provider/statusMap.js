'use strict';

// Maps the provider's documented status strings onto HYPERBOOSTER's EXISTING order status enum
// (nothing added: 'pending','processing','in_progress','completed','partial','canceled','failed','refunded').
// Matching is case-insensitive; an unrecognized string is left unmapped (null) rather than guessed —
// the caller then leaves the order's status untouched and just records the raw provider_status text.
const MAP = {
  pending: 'processing', // the provider has accepted it and is queuing it — not "pending" in our sense anymore
  'in progress': 'processing',
  processing: 'processing',
  completed: 'completed',
  partial: 'partial',
  canceled: 'canceled',
  cancelled: 'canceled',
  refunded: 'refunded',
};

function mapProviderStatus(providerStatus) {
  return MAP[String(providerStatus || '').trim().toLowerCase()] ?? null;
}

module.exports = { mapProviderStatus };
