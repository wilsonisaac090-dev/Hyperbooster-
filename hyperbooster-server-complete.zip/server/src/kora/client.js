'use strict';
const { koboToNairaAmount, nairaAmountToKobo } = require('./money');

// Thin wrapper around the two Kora endpoints this integration needs, per Kora's current docs:
//   Initialize Charge : POST {baseUrl}/merchant/api/v1/charges/initialize  (Checkout Redirect)
//     https://developers.korapay.com/docs/checkout-redirect
//   Charge Query       : GET  {baseUrl}/merchant/api/v1/charges/:reference
//     https://developers.korapay.com/docs/virtual-bank-accounts-ngn (and others)
// Both require `Authorization: Bearer {SECRET_KEY}` and MUST be called server-side only — the secret
// key never reaches a browser. fetchImpl is injectable so tests never make a real network call.

class KoraError extends Error {
  constructor(message, cause) {
    super(message);
    this.name = 'KoraError';
    this.cause = cause;
  }
}

async function koraRequest(cfg, path, { method = 'GET', body } = {}, fetchImpl = globalThis.fetch) {
  if (!cfg.kora.configured) throw new KoraError('not_configured');
  let res;
  try {
    res = await fetchImpl(`${cfg.kora.baseUrl}${path}`, {
      method,
      headers: { Authorization: `Bearer ${cfg.kora.secretKey}`, 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new KoraError('network'); // never surfaces the underlying error text
  }
  let json;
  try {
    json = await res.json();
  } catch {
    throw new KoraError('bad_response');
  }
  if (!res.ok || json.status !== true) {
    const err = new KoraError('api_error', json);
    err.httpStatus = res.status; // lets the admin "Test Connection" tell a bad key (401/403) from "not found"
    throw err;
  }
  return json.data;
}

// amountKobo is ours (integer). Kora receives it converted to naira — see money.js.
async function initializeCharge(cfg, { reference, amountKobo, currency = 'NGN', customerEmail, customerName, redirectUrl, notificationUrl }, fetchImpl) {
  const data = await koraRequest(
    cfg,
    '/merchant/api/v1/charges/initialize',
    {
      method: 'POST',
      body: {
        reference,
        amount: koboToNairaAmount(amountKobo),
        currency,
        customer: { email: customerEmail, name: customerName },
        redirect_url: redirectUrl,
        notification_url: notificationUrl,
      },
    },
    fetchImpl
  );
  if (!data?.checkout_url) throw new KoraError('bad_response');
  return { checkoutUrl: data.checkout_url, reference: data.reference || reference };
}

// Returns a normalized, ALREADY-CONVERTED-TO-KOBO view. `amountPaidKobo` is null if Kora's response
// doesn't let us determine it safely (never guessed) — callers must treat null as "not verifiable".
async function queryCharge(cfg, reference, fetchImpl) {
  const data = await koraRequest(cfg, `/merchant/api/v1/charges/${encodeURIComponent(reference)}`, {}, fetchImpl);
  const paidRaw = data.amount_paid ?? data.amount;
  return {
    status: String(data.status || '').toLowerCase(), // 'success' | 'failed' | 'pending' | 'processing' | ...
    amountPaidKobo: paidRaw === undefined || paidRaw === null ? null : nairaAmountToKobo(paidRaw),
    currency: data.currency || null,
    raw: data,
  };
}

module.exports = { initializeCharge, queryCharge, KoraError };
