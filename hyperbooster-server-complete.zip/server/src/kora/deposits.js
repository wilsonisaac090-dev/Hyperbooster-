'use strict';
const crypto = require('node:crypto');
const { ApiError } = require('../errors');
const { transaction } = require('../db');
const { applyLedger } = require('../wallet');
const { getSettings } = require('../settings');
const { writeAudit } = require('../audit');
const { initializeCharge, queryCharge, KoraError } = require('./client');
const { withEffectiveKora } = require('../credentials');

// Kora just echoes back whatever reference we send at Initialize Charge time, so our own reference IS
// the Kora reference — there is no second, provider-issued id to reconcile.
function newReference() {
  return `HB-DEP-${Date.now().toString(36)}${crypto.randomBytes(6).toString('hex')}`.toUpperCase();
}

function buildUrls(cfg, req) {
  const host = cfg.trustProxy ? String(req.headers['x-forwarded-host'] || '').split(',')[0].trim() || req.headers.host : req.headers.host;
  const proto = cfg.trustProxy ? String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim() || (cfg.cookieSecure ? 'https' : 'http') : (cfg.cookieSecure ? 'https' : 'http');
  const base = `${proto}://${host}`;
  return { redirectUrl: `${base}/`, notificationUrl: `${base}/api/webhooks/kora` };
}

// Step 3-6 of the flow: validate, reserve a pending row, then ask Kora for a checkout link.
async function createDeposit(ctx, { req, user, amountKobo, ip }) {
  const { db } = ctx;
  const cfg = withEffectiveKora(ctx.cfg, db); // admin-saved key if any, else the env var
  if (!cfg.kora.configured) throw new ApiError(503, 'Deposits are not available right now. Please try again later.');
  if (!Number.isSafeInteger(amountKobo) || amountKobo <= 0) throw new ApiError(400, 'Enter a valid deposit amount.', { field: 'amountKobo' });
  const { minDepositKobo, currency } = getSettings(db);
  if (amountKobo < minDepositKobo) {
    throw new ApiError(400, `The minimum deposit is ${(minDepositKobo / 100).toLocaleString('en-NG', { minimumFractionDigits: 2 })} ${currency}.`, { field: 'amountKobo' });
  }

  const reference = newReference();
  db.prepare("INSERT INTO deposits (user_id, reference, amount_kobo, currency, status, gateway) VALUES (?,?,?,?,'pending','kora')").run(user.id, reference, amountKobo, currency);

  const { redirectUrl, notificationUrl } = buildUrls(cfg, req);
  try {
    const charge = await initializeCharge(cfg, { reference, amountKobo, currency, customerEmail: user.email, customerName: user.full_name, redirectUrl, notificationUrl }, ctx.koraFetch);
    db.prepare("UPDATE deposits SET gateway_reference = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE reference = ?").run(charge.reference, reference);
    return { reference, checkoutUrl: charge.checkoutUrl };
  } catch (err) {
    db.prepare("UPDATE deposits SET status = 'failed', failure_reason = 'Could not start the Kora checkout.', updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE reference = ?").run(reference);
    throw new ApiError(503, 'Could not start the payment. Please try again.');
  }
}

// The single place a deposit is ever resolved into success/failure — called from BOTH the webhook and
// the customer status-check endpoint, so "exactly once" holds no matter which one gets there first.
// `queryResult` is Kora's server-to-server, already-verified view (never the browser, never the raw
// webhook payload's amount alone — see kora/webhookRoute.js and the /status endpoint).
function resolveDeposit(ctx, deposit, queryResult, { source, ip } = {}) {
  const { db } = ctx;
  if (deposit.status !== 'pending') return { changed: false, deposit }; // already terminal: nothing to do (idempotent no-op)

  return transaction(db, () => {
    const fresh = db.prepare('SELECT * FROM deposits WHERE id = ?').get(deposit.id);
    if (fresh.status !== 'pending') return { changed: false, deposit: fresh };

    if (queryResult.status === 'success') {
      if (!Number.isSafeInteger(queryResult.amountPaidKobo) || queryResult.amountPaidKobo <= 0) {
        // Kora says success but gave us no amount we can safely parse — refuse to credit a guess.
        db.prepare("UPDATE deposits SET status = 'failed', failure_reason = 'Payment reported successful but the paid amount could not be verified.', gateway_payload = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?")
          .run(JSON.stringify(queryResult.raw || {}), fresh.id);
        writeAudit(db, { action: 'KORA_DEPOSIT_UNVERIFIABLE', resourceType: 'deposit', resourceId: fresh.id, ip, details: { reference: fresh.reference, source } });
        return { changed: true, deposit: { ...fresh, status: 'failed' } };
      }
      const ledger = applyLedger(db, {
        userId: fresh.user_id,
        deltaKobo: queryResult.amountPaidKobo,
        type: 'deposit',
        referenceType: 'deposit',
        referenceId: fresh.id,
        idempotencyKey: `deposit:${fresh.reference}`, // guarantees exactly-once even if this runs twice
        description: `Wallet deposit via Kora (${fresh.reference})`,
      });
      db.prepare("UPDATE deposits SET status = 'successful', verified_amount_kobo = ?, gateway_payload = ?, paid_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?")
        .run(queryResult.amountPaidKobo, JSON.stringify(queryResult.raw || {}), fresh.id);
      writeAudit(db, { action: 'KORA_DEPOSIT_SUCCESS', resourceType: 'deposit', resourceId: fresh.id, ip, details: { reference: fresh.reference, amountKobo: queryResult.amountPaidKobo, duplicate: ledger.duplicate, source } });
      return { changed: true, deposit: { ...fresh, status: 'successful', verified_amount_kobo: queryResult.amountPaidKobo } };
    }

    // NOTE: the deposits table's CHECK constraint uses 'cancelled' (matching its original schema),
    // so a Kora status of 'canceled' (US spelling) is normalized to it here.
    const terminal = ['failed', 'expired', 'cancelled', 'canceled'].includes(queryResult.status);
    if (terminal) {
      const status = queryResult.status === 'canceled' ? 'cancelled' : queryResult.status;
      db.prepare("UPDATE deposits SET status = ?, failure_reason = ?, gateway_payload = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?")
        .run(status, `Payment ${status} at Kora.`, JSON.stringify(queryResult.raw || {}), fresh.id);
      writeAudit(db, { action: 'KORA_DEPOSIT_FAILED', resourceType: 'deposit', resourceId: fresh.id, ip, details: { reference: fresh.reference, status, source } });
      return { changed: true, deposit: { ...fresh, status } };
    }
    return { changed: false, deposit: fresh }; // still pending/processing at Kora — leave as is
  });
}

async function resolveByQuery(ctx, deposit, { source, ip } = {}) {
  try {
    const result = await queryCharge(withEffectiveKora(ctx.cfg, ctx.db), deposit.reference, ctx.koraFetch);
    return resolveDeposit(ctx, deposit, result, { source, ip });
  } catch (err) {
    if (err instanceof KoraError) return { changed: false, deposit, queryFailed: true };
    throw err;
  }
}

function depositPayload(d) {
  return {
    reference: d.reference,
    amountKobo: d.amount_kobo,
    verifiedAmountKobo: d.verified_amount_kobo ?? null,
    currency: d.currency,
    status: d.status,
    createdAt: d.created_at,
    paidAt: d.paid_at,
  };
}

module.exports = { createDeposit, resolveDeposit, resolveByQuery, depositPayload, buildUrls };
