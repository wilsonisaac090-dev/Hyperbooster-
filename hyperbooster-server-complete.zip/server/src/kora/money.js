'use strict';

// Kora's API works in the payment currency's MAJOR unit (naira, e.g. "1000.00" = NGN 1,000), NOT
// kobo. HYPERBOOSTER stores money as integer kobo everywhere else. These two functions are the only
// place that conversion happens, and both are integer/string based — no float is ever used to
// compute a kobo value that could end up in the wallet ledger.

// integer kobo -> a naira amount for the OUTBOUND request only (e.g. 150050 -> 1500.5). Safe because
// kobo is always a whole number, so this division cannot introduce a wallet-affecting rounding error;
// it only formats a number that gets JSON-stringified into the request Kora receives.
function koboToNairaAmount(kobo) {
  return Math.round(kobo) / 100;
}

// The authoritative direction: a naira amount Kora reports back (may arrive as a number or a string,
// e.g. 1000, "1000", "22000.00") -> integer kobo, using string/integer arithmetic only.
function nairaAmountToKobo(value) {
  const text = String(value).trim();
  if (!/^\d+(\.\d{1,2})?$/.test(text)) return null;
  const [whole, frac = ''] = text.split('.');
  return Number(whole) * 100 + Number(frac.padEnd(2, '0'));
}

module.exports = { koboToNairaAmount, nairaAmountToKobo };
