'use strict';
const crypto = require('node:crypto');

// Per Kora's webhook documentation: the x-korapay-signature header is an HMAC-SHA256 hex digest of
// ONLY the JSON-stringified `data` object in the payload, signed with the merchant secret key.
// https://developers.korapay.com/docs/webhooks
function verifyKoraSignature(secretKey, dataObject, signatureHeader) {
  if (typeof signatureHeader !== 'string' || !signatureHeader) return false;
  const expected = crypto.createHmac('sha256', secretKey).update(JSON.stringify(dataObject)).digest('hex');
  const a = Buffer.from(expected, 'hex');
  const b = Buffer.from(signatureHeader, 'hex');
  return a.length === b.length && a.length > 0 && crypto.timingSafeEqual(a, b);
}

module.exports = { verifyKoraSignature };
