#!/usr/bin/env node
'use strict';
// (This checks Groq's built-in browser search, the alternative search service. For the default, Exa, use live-verify-exa.js.)
// LIVE verification of EL web search against the REAL Groq API.
//
//   cd <your server folder>
//   GROQ_API_KEY=gsk_...  node /path/to/live-verify-web-search.js
//
// What it does: runs the real HYPERBOOSTER code (no changes to it) with an IN-MEMORY database, so none of your
// data is read or written. It uses your key only in the Authorization header, via the real code path, and never
// prints it. It makes about 4 Groq calls in total, exactly ONE of which is a web search:
//   1. main chat call (EL decides to call web_search)   2. the web search itself (browser_search)
//   3. main chat call (EL writes its answer)            4. one more main call with search switched OFF.
// Run  node live-verify-web-search.js --selftest  to test this script against fake Groq servers (no key needed).

process.env.NODE_ENV = 'development';
const path = require('node:path');
// Run from anywhere: if this file sits in <server>/scripts, the server folder is its parent; otherwise the current folder.
const SERVER = path.resolve(process.env.HB_SERVER_DIR || (path.basename(__dirname) === 'scripts' ? path.join(__dirname, '..') : process.cwd()));
const load = (p) => require(path.join(SERVER, 'src', p));

const fs = require('node:fs');
const crypto = require('node:crypto');

// Refuses to run in the wrong folder, so the test always exercises the real server code in THIS folder.
function preflight() {
  const [maj, min] = process.versions.node.split('.').map(Number);
  if (maj < 22 || (maj === 22 && min < 13)) throw new Error(`Node ${process.versions.node} is too old: the server needs Node >= 22.13 (node:sqlite).`);
  let pkg;
  try { pkg = JSON.parse(fs.readFileSync(path.join(SERVER, 'package.json'), 'utf8')); } catch { /* handled below */ }
  const need = ['src/ai/webSearch.js', 'src/ai/assistant.js', 'src/app.js'].filter((f) => !fs.existsSync(path.join(SERVER, f)));
  if (!pkg || pkg.name !== 'hyperbooster-server' || need.length) {
    throw new Error(`"${SERVER}" is not the HYPERBOOSTER server folder with the Step 3 code (looked for package.json "hyperbooster-server"${need.length ? ' and ' + need.join(', ') : ''}). cd into the folder that contains package.json and src/, or set HB_SERVER_DIR.`);
  }
  const sha = (f) => crypto.createHash('sha256').update(fs.readFileSync(path.join(SERVER, f))).digest('hex').slice(0, 12);
  return { dir: SERVER, name: pkg.name, version: pkg.version, node: process.versions.node, webSearchSha: sha('src/ai/webSearch.js'), assistantSha: sha('src/ai/assistant.js') };
}

// Name + size + modified time of everything under <server>/data, to prove the run did not touch persistent data.
function statLine(f) { try { const st = fs.statSync(f); return `${f}|${st.size}|${st.mtimeMs}`; } catch { return `${f}|absent`; } }
// If DATABASE_PATH points your real database somewhere other than <server>/data, that file (+ its -wal/-shm) is snapshotted too.
function prodDbSnapshot() {
  const v = process.env.DATABASE_PATH;
  if (!v || v === ':memory:') return '(DATABASE_PATH not set: default location under <server>/data)';
  const f = path.resolve(SERVER, v);
  return [f, `${f}-wal`, `${f}-shm`].map(statLine).join('\n');
}
function dataSnapshot() {
  return `${dataFolderSnapshot()}\n--\n${prodDbSnapshot()}`;
}
function dataFolderSnapshot() {
  const dir = path.join(SERVER, 'data');
  if (!fs.existsSync(dir)) return '(no data/ folder)';
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : [`${path.relative(dir, path.join(d, e.name))}|${fs.statSync(path.join(d, e.name)).size}|${fs.statSync(path.join(d, e.name)).mtimeMs}`]));
  return walk(dir).sort().join('\n') || '(data/ is empty)';
}

const ADMIN_PW = 'a-strong-admin-passphrase';
const MODEL = 'openai/gpt-oss-120b';
const BIG = { max: 1e6, windowMs: 6e4 };
const LIMITS = { apiPerIp: BIG, loginPerIp: BIG, loginPerAccount: BIG, registerPerIp: BIG, orderPerUser: BIG, adminLoginPerIp: BIG, adminLoginPerAccount: BIG, adminOtpPerIp: BIG, adminApiPerIp: BIG, adminAiChatPerAdmin: BIG, adminAiChatPerIp: BIG, adminAiSettingsPerIp: BIG };
const PROMPT = 'Use the web_search tool to find the current stable LTS version of Node.js, then tell me what you found in two sentences.';

class Client {
  constructor(base) { this.base = base; this.jar = {}; this.csrf = null; }
  async call(method, url, body) {
    const cookie = Object.entries(this.jar).map(([k, v]) => `${k}=${v}`).join('; ');
    const res = await fetch(this.base + url, {
      method, redirect: 'manual',
      headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(cookie ? { Cookie: cookie } : {}), ...(this.csrf && method !== 'GET' ? { 'X-CSRF-Token': this.csrf } : {}) },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    const text = await res.text(); let json = null; try { json = JSON.parse(text); } catch { /* not json */ }
    for (const c of res.headers.getSetCookie?.() ?? []) { const [pair] = c.split(';'); const i = pair.indexOf('='); const k = pair.slice(0, i); const v = pair.slice(i + 1); if (v === '') delete this.jar[k]; else this.jar[k] = v; }
    return { status: res.status, json, text };
  }
  get(u) { return this.call('GET', u); }
  post(u, b) { return this.call('POST', u, b); }
  patch(u, b) { return this.call('PATCH', u, b); }
}

// A request that never got an answer is either a timeout (Groq was reachable but slow) or unreachable (DNS/firewall/offline).
function classifyNetError(e) {
  const name = (e && e.name) || ''; const code = (e && (e.code || (e.cause && e.cause.code))) || '';
  return { kind: name === 'TimeoutError' || name === 'AbortError' ? 'timeout' : 'unreachable', code: String(code || name || 'error').slice(0, 40) };
}

// Wraps fetch: passes every call straight through and records what it carried (never the key itself).
function recorder(realFetch, key, log) {
  return async (url, opts) => {
    const body = JSON.parse(opts.body);
    const toolTypes = (body.tools || []).map((t) => t.type);
    const rec = {
      kind: toolTypes.includes('browser_search') ? 'search' : 'main', url, method: opts.method,
      authBearer: opts.headers && opts.headers.Authorization === `Bearer ${key}`, keyInBody: opts.body.includes(key),
      model: body.model, toolTypes, toolNames: (body.tools || []).map((t) => t.function && t.function.name).filter(Boolean),
      toolChoice: body.tool_choice, effort: body.reasoning_effort, roles: body.messages.map((m) => m.role),
      toolMessages: body.messages.filter((m) => m.role === 'tool').map((m) => m.content), bodyKeys: Object.keys(body).sort(),
    };
    const t0 = Date.now();
    let res;
    try { res = await realFetch(url, opts); } catch (e) { rec.networkError = String((e && e.message) || e).split(key).join('[key]').slice(0, 200); Object.assign(rec, { netKind: classifyNetError(e).kind, netCode: classifyNetError(e).code }); rec.ms = Date.now() - t0; log.push(rec); throw e; }
    rec.status = res.status; rec.ms = Date.now() - t0;
    try {
      const c = typeof res.clone === 'function' ? res.clone() : res;
      if (!res.ok) rec.errorBody = (await c.text()).split(key).join('[key]').slice(0, 400);
      else if (rec.kind === 'search') {
        const m = ((await c.json()).choices || [])[0]?.message || {};
        rec.searchTextChars = typeof m.content === 'string' ? m.content.length : 0; rec.responseFields = Object.keys(m);
      }
    } catch { /* diagnostics only */ }
    log.push(rec);
    return res;
  };
}

async function run({ fetchImpl, apiKey, quiet = false, allowHosts = ['127.0.0.1'] }) {
  const { loadConfig } = load('config'); const { createApp } = load('app'); const { hashPassword } = load('security');
  const results = []; const log = [];
  const out = (...a) => { if (!quiet) console.log(...a); };
  const check = (name, ok, detail = '') => { results.push({ name, ok: !!ok, detail }); out(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? `  [${detail}]` : ''}`); };

  // Setup step that must succeed: records a check AND stops with a readable message instead of a TypeError later.
  const must = (name, ok, detail = '') => { check(name, ok, detail); if (!ok) throw new Error(`setup step failed: ${name}${detail ? ` [${detail}]` : ''}`); };

  // Network tripwire: every fetch in this process is checked. Only this machine (and, live, api.groq.com) is allowed, so
  // Kora, the provider, Resend or anything else can never be contacted by this script, even by accident.
  const origFetch = globalThis.fetch; const hosts = new Set(); const blockedHosts = new Set();
  globalThis.fetch = async (url, opts) => {
    let h = '?'; try { h = new URL(typeof url === 'string' ? url : (url && url.url) || String(url)).hostname; } catch { /* leave ? */ }
    hosts.add(h); if (!allowHosts.includes(h)) { blockedHosts.add(h); throw new Error(`blocked by the script's network tripwire: ${h}`); }
    return origFetch(url, opts);
  };

  const cfg = loadConfig({}, { databasePath: ':memory:', logRequests: false, mailTransport: 'memory', limits: LIMITS, staticDir: '/nonexistent' });
  if (cfg.databasePath !== ':memory:') throw new Error('refusing to run: the config for this run is not in-memory');
  const dataBefore = dataSnapshot();
  let app;
  try {
  app = createApp(cfg, { aiFetch: recorder(fetchImpl, apiKey, log) });
  const dbList = app.db.prepare('PRAGMA database_list').all();
  check('the database that was actually opened is IN MEMORY (no file behind it: your real database is never opened)', dbList.length > 0 && dbList.every((d) => !d.file), JSON.stringify(dbList.map((d) => ({ name: d.name, file: d.file || '(none)' }))));
  {
    await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
    const boss = new Client(`http://127.0.0.1:${app.server.address().port}`);
    app.db.prepare('INSERT INTO admins (email, name, password_hash) VALUES (?,?,?)').run('boss@example.com', 'The Boss', await hashPassword(ADMIN_PW));
    const login = await boss.post('/api/admin/login', { email: 'boss@example.com', password: ADMIN_PW });
    const mail = app.mailer.outbox.at(-1); const code = mail && /code is (\d{6})/.exec(mail.text);
    must('admin login step 1 accepted and a one-time code was emailed (in-memory mailer)', login.status === 200 && !!code, `HTTP ${login.status}`);
    const otp = await boss.post('/api/admin/verify-otp', { code: code[1] });
    must('admin one-time code accepted and a CSRF token issued', otp.status === 200 && !!(otp.json && otp.json.csrfToken), `HTTP ${otp.status}`);
    boss.csrf = otp.json.csrfToken;
    const READ = { read_dashboard: true, read_orders: true, read_services: true, read_customers: true, read_wallet: true, read_audit: true };
    const save = (web) => boss.patch('/api/admin/ai/settings', { enabled: true, apiKey, model: MODEL, searchProvider: 'groq', toolPermissions: { ...READ, web_search: web }, currentPassword: ADMIN_PW });

    const s = await save(true);
    check('settings saved: EL enabled, web search ON, model ' + MODEL, s.status === 200 && s.json.model === MODEL && s.json.toolPermissions.web_search === true, `HTTP ${s.status}`);

    out('\n-- asking EL to search the web (the one real search) --');
    const r = await boss.post('/api/admin/ai/chat', { message: PROMPT });
    const mains = log.filter((x) => x.kind === 'main'); const searches = log.filter((x) => x.kind === 'search');
    check('chat request succeeded', r.status === 200, `HTTP ${r.status}${r.status !== 200 ? ' ' + r.text.slice(0, 160) : ''}`);
    check('EL offered web_search (13 original tools + web_search)', mains[0] && mains[0].toolNames.includes('web_search') && mains[0].toolNames.length === 14);
    const toolAudits = () => app.db.prepare("SELECT details FROM audit_logs WHERE action = 'AI_TOOL_CALLED' AND resource_id = 'web_search' ORDER BY id").all().map((x) => JSON.parse(x.details));
    const searchAudits = () => app.db.prepare("SELECT action, details FROM audit_logs WHERE action LIKE 'AI_WEB_SEARCH%' ORDER BY id").all().map((x) => ({ action: x.action, d: JSON.parse(x.details || '{}') }));
    const attempts = toolAudits();
    check('EL decided to call the web_search tool', attempts.length >= 1, attempts.length ? `${attempts.length} call(s)` : log.some((x) => x.netKind) ? 'not evaluated: a request to Groq failed before EL could decide (see the network message below)' : 'the MODEL chose not to search at all: run again');
    const failReasons = searchAudits().filter((a) => a.action !== 'AI_WEB_SEARCH').map((a) => `${a.action.replace('AI_WEB_SEARCH_', '').toLowerCase()}:${a.d.reason || '?'}`);
    check('the search call SUCCEEDED (EL lists it as used and audited it as a success)', !!(r.json && Array.isArray(r.json.toolsUsed) && r.json.toolsUsed.includes('web_search')) && attempts.some((a) => a.success === true), failReasons.length ? `search was attempted but failed: ${failReasons.join(', ')}` : '');
    check('exactly ONE real search request was sent to Groq', searches.length === 1, `${searches.length} search request(s)`);

    const sr = searches[0];
    if (sr) {
      check('GROQ ACCEPTED the browser_search request (HTTP 200)', sr.status === 200, `HTTP ${sr.status}${sr.errorBody ? ' | Groq said: ' + sr.errorBody : ''}${sr.networkError ? ' | network: ' + sr.networkError : ''}`);
      check('request shape: URL, model, only browser_search, tool_choice required, low effort, system+user',
        sr.url === 'https://api.groq.com/openai/v1/chat/completions' && sr.method === 'POST' && sr.model === MODEL && JSON.stringify(sr.toolTypes) === '["browser_search"]' && sr.toolNames.length === 0 && sr.toolChoice === 'required' && sr.effort === 'low' && JSON.stringify(sr.roles) === '["system","user"]',
        JSON.stringify({ model: sr.model, tools: sr.toolTypes, tool_choice: sr.toolChoice, effort: sr.effort }));
      check('request carries no parameters beyond the documented ones (Groq: Browser Search is not compatible with structured outputs)', JSON.stringify(sr.bodyKeys) === '["messages","model","reasoning_effort","tool_choice","tools"]', (sr.bodyKeys || []).join(','));
      check('Groq returned usable text for the search', sr.status === 200 && sr.searchTextChars > 50, `${sr.searchTextChars} characters; reply fields: ${(sr.responseFields || []).join(', ')}; ${sr.ms} ms`);
    }

    const lastMain = mains.at(-1);
    const toolRaw = lastMain && lastMain.toolMessages.at(-1);
    let tool = null; try { tool = JSON.parse(toolRaw); } catch { /* checked below */ }
    check('EL received a normal tool result with passages', !!tool && Array.isArray(tool.passages) && tool.passages.length >= 1, tool ? `${(tool.passages || []).length} passage(s), truncated=${tool.truncated}${tool.error ? ', error: ' + tool.error : ''}` : 'no tool result');
    check('the search text fits EL\'s 6000-character cap, so the answer is not cut off (Groq documents the final answer at the END of message.content)', !!tool && tool.truncated === false,
      `Groq sent ${sr ? sr.searchTextChars : '?'} characters${tool && tool.truncated ? ': TRUNCATED, the end of the text (the answer) was cut. Send me this output: the fix is to keep the END of the text' : ''}`);
    check('result is labelled unverified / untrusted and carries the data-only notice', !!tool && /Unverified/.test(tool.source || '') && /Untrusted/.test(tool.source || '') && typeof tool._untrusted_data_notice === 'string');
    check('EL produced a real final answer from it (not the "temporarily unavailable" fallback)', !!tool && !!tool.passages && r.json && typeof r.json.content === 'string' && r.json.content.trim().length > 0 && !/temporarily unavailable/i.test(r.json.content), `${(r.json && r.json.content || '').length} characters`);

    out('\n-- key exposure --');
    check('API key sent in the Authorization header of every Groq request', log.length > 0 && log.every((x) => x.authBearer), `${log.length} request(s)`);
    check('API key is in NO request body (so never in any history or tool data shown to the model)', !log.some((x) => x.keyInBody));
    const settings = await boss.get('/api/admin/ai/settings');
    const audit = JSON.stringify(app.db.prepare('SELECT * FROM audit_logs').all()); const msgs = JSON.stringify(app.db.prepare('SELECT * FROM ai_messages').all());
    const stored = JSON.stringify([app.db.prepare('SELECT * FROM ai_settings').all(), app.db.prepare('SELECT * FROM ai_conversations').all()]);
    check('API key is not in the chat response, settings API, audit log, saved conversation or settings tables (stored only as ciphertext), or tool data',
      ![r.text, settings.text, audit, msgs, stored, JSON.stringify(log.map((x) => x.toolMessages))].some((t) => t.includes(apiKey)));
    const sa = searchAudits();
    check('audit log has exactly one search entry for the search that ran, no failed/blocked entries, and no secrets',
      sa.filter((a) => a.action === 'AI_WEB_SEARCH').length === 1 && sa.every((a) => a.action === 'AI_WEB_SEARCH') && !audit.includes(ADMIN_PW), sa.map((a) => a.action).join(', ') || '(none)');

    out('\n-- switching web search OFF --');
    await save(false);
    const before = log.filter((x) => x.kind === 'search').length;
    const r2 = await boss.post('/api/admin/ai/chat', { message: PROMPT });
    const mains2 = log.filter((x) => x.kind === 'main');
    check('OFF: web_search is no longer offered to the model', r2.status === 200 && !mains2.at(-1).toolNames.includes('web_search') && mains2.at(-1).toolNames.length === 13);
    check('OFF: no search request was sent', log.filter((x) => x.kind === 'search').length === before);

    if (!quiet) {
      out('\n-- what came back (public web content, for your eyes) --');
      out('first passage :', tool && tool.passages && tool.passages[0] ? tool.passages[0].slice(0, 240) : '(none)');
      out("EL's answer   :", ((r.json && r.json.content) || '').slice(0, 500));
      out('timings (ms)  :', log.map((x) => `${x.kind}:${x.ms}`).join('  '));
    }
  }
  } finally { if (app) await app.close(); globalThis.fetch = origFetch; }
  check(`no network request went anywhere except: ${allowHosts.join(', ')}`, blockedHosts.size === 0, `hosts contacted: ${[...hosts].join(', ') || '(none)'}${blockedHosts.size ? ` | BLOCKED: ${[...blockedHosts].join(', ')}` : ''}`);
  check('persistent data untouched: <server>/data (and any DATABASE_PATH database) identical before and after the run', dataSnapshot() === dataBefore);
  results.net = log.filter((x) => x.netKind).map((x) => ({ kind: x.netKind, code: x.netCode }));
  return results;
}

// ---------------------------------------------------------------------------------------------- self-test
function fakeGroq({ searchStatus = 200, searchThrow = null } = {}) {
  const res = (message, status = 200) => ({ ok: status === 200, status, clone() { return this; }, json: async () => ({ choices: [{ message }] }), text: async () => (status === 200 ? '' : '{"error":{"message":"tools are not supported for this model"}}') });
  return async (url, opts) => {
    const body = JSON.parse(opts.body);
    if ((body.tools || []).some((t) => t.type === 'browser_search') && searchThrow) throw searchThrow();
    if ((body.tools || []).some((t) => t.type === 'browser_search')) return searchStatus === 200 ? res({ content: 'The current Node.js LTS line is 22.x (fake search answer).\nSource: nodejs.org (fake).' }) : res({}, searchStatus);
    const last = body.messages.map((m) => m.role).lastIndexOf('user');
    const toolAfter = body.messages.slice(last + 1).some((m) => m.role === 'tool');
    const offered = (body.tools || []).some((t) => t.function && t.function.name === 'web_search');
    if (offered && !toolAfter) return res({ content: '', tool_calls: [{ id: 'c1', function: { name: 'web_search', arguments: JSON.stringify({ query: 'current Node.js LTS version' }) } }] });
    return res({ content: toolAfter ? 'Node.js 22 is the current LTS line (from the web search).' : 'I have no web search available.' });
  };
}

async function main() {
  if (process.argv.includes('--selftest')) {
    preflight();
    delete process.env.GROQ_API_KEY; // the self-test must not depend on a real key, and the tripwire proves it uses no internet
    const KEY = 'gsk_selftest_key_0000000000';
    const timeoutErr = () => { const e = new Error('The operation was aborted due to timeout'); e.name = 'TimeoutError'; return e; };
    const dnsErr = () => { const e = new TypeError('fetch failed'); e.cause = { code: 'ENOTFOUND' }; return e; };
    const orig = globalThis.fetch;
    const good = await run({ fetchImpl: fakeGroq(), apiKey: KEY, quiet: true });
    const bad = await run({ fetchImpl: fakeGroq({ searchStatus: 400 }), apiKey: KEY, quiet: true });
    const slow = await run({ fetchImpl: fakeGroq({ searchThrow: timeoutErr }), apiKey: KEY, quiet: true });
    const down = await run({ fetchImpl: fakeGroq({ searchThrow: dnsErr }), apiKey: KEY, quiet: true });
    const names = (r) => r.filter((x) => !x.ok).map((x) => x.name);
    const has = (r, re) => names(r).some((n) => re.test(n));
    const passes = (r, re) => r.some((x) => x.ok && re.test(x.name));
    const goodFails = names(good);
    console.log(`selftest 1, healthy fake Groq          : ${good.length - goodFails.length}/${good.length} checks pass`, goodFails);
    console.log(`selftest 2, Groq rejects the search 400: FAILS ${names(bad).length} check(s) as it should:`, names(bad).map((n) => n.slice(0, 48)));
    console.log(`selftest 3, search times out           : net errors seen = ${JSON.stringify(slow.net)}`);
    console.log(`selftest 4, Groq unreachable (DNS)     : net errors seen = ${JSON.stringify(down.net)}`);
    const checks = {
      'healthy run: every check passes': goodFails.length === 0,
      'rejected search: GROQ ACCEPTED fails': has(bad, /GROQ ACCEPTED/),
      'rejected search: usable text fails': has(bad, /usable text/),
      'rejected search: search SUCCEEDED fails': has(bad, /search call SUCCEEDED/),
      'rejected search: audit check FAILS (was a false PASS before the audit)': has(bad, /audit log has exactly one search entry/),
      'rejected search: still reported as "EL decided to call" (not blamed on the model)': passes(bad, /EL decided to call/),
      'timeout is classified as timeout, never as unreachable': slow.net.some((x) => x.kind === 'timeout') && !slow.net.some((x) => x.kind === 'unreachable'),
      'DNS failure is classified as unreachable, never as timeout': down.net.some((x) => x.kind === 'unreachable') && !down.net.some((x) => x.kind === 'timeout'),
      'tripwire passed in every run (only 127.0.0.1 was contacted)': [good, bad, slow, down].every((r) => passes(r, /no network request went anywhere/)),
      'in-memory database proof passed in every run': [good, bad, slow, down].every((r) => passes(r, /actually opened is IN MEMORY/)),
      'global fetch restored after every run': globalThis.fetch === orig,
    };
    for (const [k, v] of Object.entries(checks)) console.log(`${v ? 'ok  ' : 'BAD '} ${k}`);
    const ok = Object.values(checks).every(Boolean);
    console.log(ok ? 'SELFTEST OK' : 'SELFTEST FAILED'); process.exit(ok ? 0 : 1);
  }
  const info = preflight();
  console.log(`server folder : ${info.dir}\npackage       : ${info.name} ${info.version}   (node ${info.node})\ncode checked  : src/ai/webSearch.js sha256:${info.webSearchSha}   src/ai/assistant.js sha256:${info.assistantSha}\n`);
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey || !/^gsk_/.test(apiKey)) { console.error('Set GROQ_API_KEY=gsk_... in the environment (it is never printed or stored).'); process.exit(2); }
  const probing = (url, opts) => globalThis.fetch(url, opts);
  const results = await run({ fetchImpl: probing, apiKey, allowHosts: ['127.0.0.1', 'api.groq.com'] });
  const unreachable = results.net.filter((x) => x.kind === 'unreachable'); const timedOut = results.net.filter((x) => x.kind === 'timeout');
  if (unreachable.length) console.log(`\nGROQ COULD NOT BE REACHED from this machine (${[...new Set(unreachable.map((x) => x.code))].join(', ')}): network/DNS/firewall. This is not a code failure: run it where api.groq.com is reachable.`);
  else if (timedOut.length) console.log(`\nA REQUEST TO GROQ TIMED OUT (Groq was reachable but too slow). The web search limit is 30 s. If this repeats, it is a Step 3 timeout question to fix, not a connectivity problem.`);
  const pass = results.filter((x) => x.ok).length;
  console.log(`\nSUMMARY: ${pass}/${results.length} checks passed${pass === results.length ? '' : '  <-- see FAIL lines above'}`);
  process.exit(unreachable.length ? 4 : pass === results.length ? 0 : 1);
}

if (require.main === module) main().catch((e) => { console.error('script error:', String((e && e.message) || e).split(process.env.GROQ_API_KEY || '\u0000').join('[key]')); process.exit(3); });
module.exports = { run };
