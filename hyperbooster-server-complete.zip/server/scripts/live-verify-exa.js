#!/usr/bin/env node
'use strict';
// LIVE verification of EL's web search through EXA against the REAL Exa and Groq APIs.
//
//   cd <your server folder>
//   EXA_API_KEY=...                       node scripts/live-verify-exa.js     # Stage A only: needs just your Exa key
//   EXA_API_KEY=... GROQ_API_KEY=gsk_...  node scripts/live-verify-exa.js     # Stage A + Stage B: the whole flow
//   node scripts/live-verify-exa.js --selftest                                # tests this script against FAKE servers; no keys needed
//
// Stage A: ONE real Exa search through the real provider code: proves Exa accepts the request and answers in the
//          documented shape. Costs about one search (the Exa docs example shows roughly $0.007).
// Stage B: the full flow with an in-memory copy of the real server code: EL (Groq) decides to search -> the backend calls
//          Exa -> the results arrive as untrusted data -> EL explains them and cites links. Checks that every link in the
//          answer is one Exa really returned. About 2 Groq calls plus 1 Exa search.
// Safety: an IN-MEMORY database (none of your data is read or written), a network tripwire that only allows this
// machine, api.groq.com and api.exa.ai, and neither key is ever printed. Your .env file is never read.

process.env.NODE_ENV = 'development';
const path = require('node:path');
// Run from anywhere: if this file sits in <server>/scripts, the server folder is its parent; otherwise the current folder.
const SERVER = path.resolve(process.env.HB_SERVER_DIR || (path.basename(__dirname) === 'scripts' ? path.join(__dirname, '..') : process.cwd()));
const load = (p) => require(path.join(SERVER, 'src', p));

const fs = require('node:fs');
const crypto = require('node:crypto');

// Refuses to run in the wrong folder, so the test always exercises the real server code in THIS folder.
function preflight() {
  const [maj, min] = process.versions.node.split('.').map(Number);
  if (maj < 22 || (maj === 22 && min < 13)) throw new Error(`Node ${process.versions.node} is too old: the server needs Node >= 22.13 (node:sqlite).`);
  let pkg;
  try { pkg = JSON.parse(fs.readFileSync(path.join(SERVER, 'package.json'), 'utf8')); } catch { /* handled below */ }
  const need = ['src/ai/providers/exa.js', 'src/ai/citations.js', 'src/ai/assistant.js', 'src/app.js'].filter((f) => !fs.existsSync(path.join(SERVER, f)));
  if (!pkg || pkg.name !== 'hyperbooster-server' || need.length) {
    throw new Error(`"${SERVER}" is not the HYPERBOOSTER server folder with the Step 5 (Exa search) code (looked for package.json "hyperbooster-server"${need.length ? ' and ' + need.join(', ') : ''}). cd into the folder that contains package.json and src/, or set HB_SERVER_DIR.`);
  }
  const sha = (f) => crypto.createHash('sha256').update(fs.readFileSync(path.join(SERVER, f))).digest('hex').slice(0, 12);
  return { dir: SERVER, name: pkg.name, version: pkg.version, node: process.versions.node, exaSha: sha('src/ai/providers/exa.js'), assistantSha: sha('src/ai/assistant.js') };
}

// Name + size + modified time of everything under <server>/data, to prove the run did not touch persistent data.
function statLine(f) { try { const st = fs.statSync(f); return `${f}|${st.size}|${st.mtimeMs}`; } catch { return `${f}|absent`; } }
// If DATABASE_PATH points your real database somewhere other than <server>/data, that file (+ its -wal/-shm) is snapshotted too.
function prodDbSnapshot() {
  const v = process.env.DATABASE_PATH;
  if (!v || v === ':memory:') return '(DATABASE_PATH not set: default location under <server>/data)';
  const f = path.resolve(SERVER, v);
  return [f, `${f}-wal`, `${f}-shm`].map(statLine).join('\n');
}
function dataSnapshot() {
  return `${dataFolderSnapshot()}\n--\n${prodDbSnapshot()}`;
}
function dataFolderSnapshot() {
  const dir = path.join(SERVER, 'data');
  if (!fs.existsSync(dir)) return '(no data/ folder)';
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : [`${path.relative(dir, path.join(d, e.name))}|${fs.statSync(path.join(d, e.name)).size}|${fs.statSync(path.join(d, e.name)).mtimeMs}`]));
  return walk(dir).sort().join('\n') || '(data/ is empty)';
}

const ADMIN_PW = 'a-strong-admin-passphrase';
const MAIN_MODEL = 'openai/gpt-oss-120b';
const EXA_ENDPOINT = 'https://api.exa.ai/search';
const STAGE_A_QUERY = 'current Node.js LTS release';
const QUESTION = 'Use the web_search tool to find out which Node.js version is the current LTS release. Explain it in two or three plain sentences and list the sources you relied on with their titles and URLs.';
const BIG = { max: 1e6, windowMs: 6e4 };
const LIMITS = { apiPerIp: BIG, loginPerIp: BIG, loginPerAccount: BIG, registerPerIp: BIG, orderPerUser: BIG, adminLoginPerIp: BIG, adminLoginPerAccount: BIG, adminOtpPerIp: BIG, adminApiPerIp: BIG, adminAiChatPerAdmin: BIG, adminAiChatPerIp: BIG, adminAiSettingsPerIp: BIG };


class Client {
  constructor(base) { this.base = base; this.jar = {}; this.csrf = null; }
  async call(method, url, body) {
    const cookie = Object.entries(this.jar).map(([k, v]) => `${k}=${v}`).join('; ');
    const res = await fetch(this.base + url, {
      method, redirect: 'manual',
      headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(cookie ? { Cookie: cookie } : {}), ...(this.csrf && method !== 'GET' ? { 'X-CSRF-Token': this.csrf } : {}) },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    const text = await res.text(); let json = null; try { json = JSON.parse(text); } catch { /* not json */ }
    for (const c of res.headers.getSetCookie?.() ?? []) { const [pair] = c.split(';'); const i = pair.indexOf('='); const k = pair.slice(0, i); const v = pair.slice(i + 1); if (v === '') delete this.jar[k]; else this.jar[k] = v; }
    return { status: res.status, json, text };
  }
  get(u) { return this.call('GET', u); }
  post(u, b) { return this.call('POST', u, b); }
  patch(u, b) { return this.call('PATCH', u, b); }
}

// A request that never got an answer is either a timeout (Groq was reachable but slow) or unreachable (DNS/firewall/offline).
function classifyNetError(e) {
  const name = (e && e.name) || ''; const code = (e && (e.code || (e.cause && e.cause.code))) || '';
  return { kind: name === 'TimeoutError' || name === 'AbortError' ? 'timeout' : 'unreachable', code: String(code || name || 'error').slice(0, 40) };
}

// Wraps fetch: passes every call straight through, records what was sent and what came back (never a key), so the checks
// can say what really happened. Works for both Groq and Exa calls.
function recorder(realFetch, keys, log) {
  return async (url, opts) => {
    const isExa = url === EXA_ENDPOINT;
    const body = JSON.parse(opts.body);
    const key = isExa ? keys.exa : keys.groq;
    const rec = {
      kind: isExa ? 'exa' : 'groq', url, method: opts.method,
      authBearer: !!key && opts.headers && opts.headers.Authorization === `Bearer ${key}`,
      keyInBody: Object.values(keys).filter(Boolean).some((k) => opts.body.includes(k)),
      bodyKeys: Object.keys(body).sort(), bodyBytes: opts.body.length, model: body.model,
      query: body.query, numResults: body.numResults, type: body.type, hasHighlights: !!(body.contents && body.contents.highlights && body.contents.highlights.maxCharacters),
      toolMessages: (body.messages || []).filter((m) => m.role === 'tool').map((m) => m.content),
    };
    const t0 = Date.now();
    const allKeys = Object.values(keys).filter(Boolean);
    const scrub = (t) => allKeys.reduce((acc, k) => acc.split(k).join('[key]'), String(t));
    let res;
    try { res = await realFetch(url, opts); } catch (e) { rec.networkError = scrub((e && e.message) || e).slice(0, 200); Object.assign(rec, { netKind: classifyNetError(e).kind, netCode: classifyNetError(e).code }); rec.ms = Date.now() - t0; log.push(rec); throw e; }
    rec.status = res.status; rec.ms = Date.now() - t0;
    try {
      const c = typeof res.clone === 'function' ? res.clone() : res;
      if (!res.ok) rec.errorBody = scrub(await c.text()).slice(0, 400);
      else if (isExa) { const j = await c.json(); rec.topKeys = Object.keys(j || {}).join(','); rec.rawResults = Array.isArray(j && j.results) ? j.results.length : null; rec.cost = j && j.costDollars && j.costDollars.total; rec.searchTime = j && j.searchTime; }
    } catch { /* diagnostics only */ }
    log.push(rec);
    return res;
  };
}

async function run({ fetchImpl, groqKey, exaKey, quiet = false, allowHosts = ['127.0.0.1'] }) {
  const { loadConfig } = load('config'); const { createApp } = load('app'); const { hashPassword } = load('security');
  const results = []; const log = [];
  const out = (...a) => { if (!quiet) console.log(...a); };
  const check = (name, ok, detail = '') => { results.push({ name, ok: !!ok, detail }); out(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? `  [${detail}]` : ''}`); };

  // Setup step that must succeed: records a check AND stops with a readable message instead of a TypeError later.
  const must = (name, ok, detail = '') => { check(name, ok, detail); if (!ok) throw new Error(`setup step failed: ${name}${detail ? ` [${detail}]` : ''}`); };

  // Network tripwire: every fetch in this process is checked. Only this machine (and, live, api.groq.com) is allowed, so
  // Kora, the provider, Resend or anything else can never be contacted by this script, even by accident.
  const origFetch = globalThis.fetch; const hosts = new Set(); const blockedHosts = new Set();
  globalThis.fetch = async (url, opts) => {
    let h = '?'; try { h = new URL(typeof url === 'string' ? url : (url && url.url) || String(url)).hostname; } catch { /* leave ? */ }
    hosts.add(h); if (!allowHosts.includes(h)) { blockedHosts.add(h); throw new Error(`blocked by the script's network tripwire: ${h}`); }
    return origFetch(url, opts);
  };

  const cfg = loadConfig({}, { databasePath: ':memory:', logRequests: false, mailTransport: 'memory', limits: LIMITS, staticDir: '/nonexistent' });
  if (cfg.databasePath !== ':memory:') throw new Error('refusing to run: the config for this run is not in-memory');
  const dataBefore = dataSnapshot();
  let app;
  try {
  app = createApp(cfg, { aiFetch: recorder(fetchImpl, { groq: groqKey, exa: exaKey }, log) });
  const dbList = app.db.prepare('PRAGMA database_list').all();
  check('the database that was actually opened is IN MEMORY (no file behind it: your real database is never opened)', dbList.length > 0 && dbList.every((d) => !d.file), JSON.stringify(dbList.map((d) => ({ name: d.name, file: d.file || '(none)' }))));
  {
    await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
    const boss = new Client(`http://127.0.0.1:${app.server.address().port}`);
    app.db.prepare('INSERT INTO admins (email, name, password_hash) VALUES (?,?,?)').run('boss@example.com', 'The Boss', await hashPassword(ADMIN_PW));
    const login = await boss.post('/api/admin/login', { email: 'boss@example.com', password: ADMIN_PW });
    const mail = app.mailer.outbox.at(-1); const code = mail && /code is (\d{6})/.exec(mail.text);
    must('admin login step 1 accepted and a one-time code was emailed (in-memory mailer)', login.status === 200 && !!code, `HTTP ${login.status}`);
    const otp = await boss.post('/api/admin/verify-otp', { code: code[1] });
    must('admin one-time code accepted and a CSRF token issued', otp.status === 200 && !!(otp.json && otp.json.csrfToken), `HTTP ${otp.status}`);
    boss.csrf = otp.json.csrfToken;
    const keys = { groq: groqKey, exa: exaKey };
    const exaMod = load('ai/providers/exa'); const citations = load('ai/citations');
    const READ = { read_dashboard: true, read_orders: true, read_services: true, read_customers: true, read_wallet: true, read_audit: true };
    const dump = () => app.db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all().map((t) => JSON.stringify(app.db.prepare(`SELECT * FROM "${t.name}"`).all())).join('\n');

    out('\n-- Stage A: ONE real Exa search through the real provider code --');
    const rfetch = recorder(fetchImpl, keys, log);
    let found = null; let aErr = null;
    try { found = await exaMod.search({ apiKey: exaKey, query: STAGE_A_QUERY, maxResults: 5, maxChars: 4000 }, rfetch); } catch (e) { aErr = e && e.message; }
    const ex = log.find((x) => x.kind === 'exa');
    check('EXA ACCEPTED the search request (HTTP 200)', !!ex && ex.status === 200, ex ? `HTTP ${ex.status}${ex.errorBody ? ' | Exa said: ' + ex.errorBody : ''}${ex.networkError ? ' | network: ' + ex.networkError : ''}${aErr ? ' | code: ' + aErr : ''}` : 'no request was made');
    check('request shape: POST /search, bearer key, query, type auto, numResults 5, highlights only', !!ex && ex.url === EXA_ENDPOINT && ex.method === 'POST' && ex.authBearer && JSON.stringify(ex.bodyKeys) === '["contents","numResults","query","type"]' && ex.numResults === 5 && ex.type === 'auto' && ex.hasHighlights, ex ? ex.bodyKeys.join(',') : '');
    check('the Exa key is only in the Authorization header, never in a body', !log.some((x) => x.keyInBody));
    check('the response has the documented shape (a results list)', !!ex && ex.status === 200 && ex.rawResults !== null, `top-level fields: ${ex && ex.topKeys}`);
    check('at least one result came back', !!found && found.results.length >= 1, `${found ? found.results.length : 0} kept of ${ex && ex.rawResults} returned`);
    check('every result has a safe http(s) link and a title', !!found && found.results.length > 0 && found.results.every((r) => /^https?:\/\//.test(r.url) && r.title));
    check('results carry excerpt text (highlights)', !!found && found.results.some((r) => r.highlights.join('').length > 20));
    check('nothing was dropped as malformed or unsafe', !!ex && !!found && ex.rawResults === found.results.length, `returned ${ex && ex.rawResults}, kept ${found && found.results.length}`);
    if (found && found.results.length) out('   sample:', found.results.slice(0, 3).map((r) => `${r.title.slice(0, 60)} <${r.url}>`).join('\n          '));
    if (ex && ex.status === 200) out(`   Exa answered in ${ex.ms} ms (its own timer: ${ex.searchTime} ms); reported cost: $${ex.cost}`);

    if (!groqKey) {
      out('\n-- Stage B skipped: set GROQ_API_KEY as well to test the whole flow (Groq decides -> Exa -> answer with links) --');
    } else {
      out('\n-- Stage B: the whole flow --');
      const save = (patch) => boss.patch('/api/admin/ai/settings', { ...patch, currentPassword: ADMIN_PW });
      const s = await save({ enabled: true, apiKey: groqKey, exaApiKey: exaKey, searchProvider: 'exa', model: MAIN_MODEL, toolPermissions: { ...READ, web_search: true } });
      check('settings saved: EL enabled, Exa key stored, live search ON, provider Exa', s.status === 200 && s.json.search.exaConfigured === true && s.json.search.provider === 'exa' && s.json.toolPermissions.web_search === true, `HTTP ${s.status}`);
      const mark = log.length;
      const r = await boss.post('/api/admin/ai/chat', { message: QUESTION });
      const mine = log.slice(mark); const exaCalls = mine.filter((x) => x.kind === 'exa'); const groqCalls = mine.filter((x) => x.kind === 'groq');
      const searchAudits = () => app.db.prepare("SELECT action, details FROM audit_logs WHERE action LIKE 'AI_WEB_SEARCH%' ORDER BY id").all().map((x) => ({ action: x.action, d: JSON.parse(x.details || '{}') }));
      check('chat request accepted (HTTP 200)', r.status === 200, `HTTP ${r.status}`);
      check('GROQ ACCEPTED every request EL made (HTTP 200)', groqCalls.length > 0 && groqCalls.every((x) => x.status === 200), groqCalls.map((x) => `${x.status}${x.errorBody ? ' ' + x.errorBody.slice(0, 120) : ''}`).join(' | '));
      check('EL (Groq) decided to search the web', exaCalls.length >= 1 || searchAudits().length >= 1, 'the MODEL chose not to search at all: run again, or check the model name');
      check('exactly one Exa search was made for this question', exaCalls.length === 1, `${exaCalls.length}`);
      check('Exa accepted it (HTTP 200)', exaCalls.length === 1 && exaCalls[0].status === 200, exaCalls[0] ? `HTTP ${exaCalls[0].status}${exaCalls[0].errorBody ? ' | ' + exaCalls[0].errorBody : ''}` : '');
      const lastGroq = groqCalls.at(-1); let tool = null;
      try { tool = JSON.parse(lastGroq && lastGroq.toolMessages.at(-1)); } catch { /* checked below */ }
      check('EL received real results (titles + links), labelled as untrusted external data', !!tool && Array.isArray(tool.results) && tool.results.length >= 1 && tool.results.every((x) => /^https?:\/\//.test(x.url)) && /Untrusted/.test(tool._untrusted_data_notice || '') && /Cite only these URLs/.test(tool.source || ''), tool ? `${(tool.results || []).length} result(s)${tool.error ? ' | ' + tool.error : ''}` : 'no tool result');
      const answer = (r.json && r.json.content) || '';
      const urls = (answer.match(/https?:\/\/[^\s<>"'`()[\]{}]+/gi) || []).map((u) => u.replace(/[.,;:!?*_]+$/, ''));
      const allowed = new Set(((tool && tool.results) || []).map((x) => citations.normUrl(x.url)));
      check('EL produced a real answer (not the "temporarily unavailable" fallback)', answer.trim().length > 40 && !/temporarily unavailable|not configured correctly/i.test(answer), `${answer.length} characters`);
      check('the answer includes at least one source link', urls.length >= 1, `${urls.length} link(s)`);
      check('every link in the answer is one Exa really returned', urls.length >= 1 && urls.every((u) => allowed.has(citations.normUrl(u))), urls.filter((u) => !allowed.has(citations.normUrl(u))).join(', '));
      check('the server guard had to remove nothing (EL did not try to cite anything else)', !answer.includes(citations.REMOVED), answer.includes(citations.REMOVED) ? 'EL tried to cite a link that was not a result; the guard removed it' : '');
      check('the "Checked:" note would read: web search', !!r.json && Array.isArray(r.json.toolsUsed) && r.json.toolsUsed.includes('web_search'), JSON.stringify(r.json && r.json.toolsUsed));

      out('\n-- key exposure, storage, audit --');
      check('each key is sent only to its own service, in the Authorization header', mine.length > 0 && mine.every((x) => x.authBearer));
      check('neither key is in any request body', !log.some((x) => x.keyInBody));
      const settings = await boss.get('/api/admin/ai/settings'); const audit = JSON.stringify(app.db.prepare('SELECT * FROM audit_logs').all()); const everything = dump();
      check('neither key is in the chat response, the settings API, the audit log, or any table (stored only as ciphertext)', ![r.text, settings.text, audit, everything].some((t) => t.includes(groqKey) || t.includes(exaKey)));
      check('the settings API reports only whether an Exa key is saved, nothing about the key', settings.json.search.exaConfigured === true && !/last4|exaApiKey/i.test(JSON.stringify(settings.json.search)));
      const sa = searchAudits();
      check('audit log: exactly one search entry (provider exa), no failures, no secrets', sa.length === 1 && sa[0].action === 'AI_WEB_SEARCH' && sa[0].d.provider === 'exa' && !audit.includes(ADMIN_PW), sa.map((x) => x.action).join(', '));
      const excerpt = ((tool && tool.results) || []).flatMap((x) => x.excerpts || []).find((t) => t.length > 20);
      check('the search results (excerpt text, tool messages) were NOT stored; only your question and EL\'s answer are', !!excerpt && !everything.includes(excerpt.slice(0, 30)), 'EL\'s saved answer may contain the links it cited: that is intended');

      if (!quiet) {
        out('\n-- what came back (for your eyes) --');
        out("EL's answer :", answer.slice(0, 900) || '(none)');
        out('timings (ms):', mine.map((x) => `${x.kind}:${x.ms}`).join('  '));
      }
    }

  }
  } finally { if (app) await app.close(); globalThis.fetch = origFetch; }
  check(`no network request went anywhere except: ${allowHosts.join(', ')}`, blockedHosts.size === 0, `hosts contacted: ${[...hosts].join(', ') || '(none)'}${blockedHosts.size ? ` | BLOCKED: ${[...blockedHosts].join(', ')}` : ''}`);
  check('persistent data untouched: <server>/data (and any DATABASE_PATH database) identical before and after the run', dataSnapshot() === dataBefore);
  results.net = log.filter((x) => x.netKind).map((x) => ({ kind: x.netKind, code: x.netCode }));
  return results;
}

// ---------------------------------------------------------------------------------------------- self-test
function fakeServices({ exaStatus = 200, exaThrow = null, brain = 'good' } = {}) {
  const exaResults = [
    { id: 'a', title: 'Node.js Releases', url: 'https://nodejs.org/en/about/previous-releases', publishedDate: '2026-09-01T00:00:00.000Z', highlights: ['Node.js 24 is the current Long Term Support (LTS) release line.'] },
    { id: 'b', title: 'Node.js release schedule', url: 'https://github.com/nodejs/release', highlights: ['Even-numbered releases become LTS in October.'] },
    { id: 'c', title: 'endoflife.date Node.js', url: 'https://endoflife.date/nodejs', highlights: ['Support status of each Node.js release line.'] },
  ];
  const res = (data, status = 200) => ({ ok: status === 200, status, clone() { return this; }, json: async () => data, text: async () => (status === 200 ? '' : '{"error":"fake rejection"}') });
  return async (url, opts) => {
    const body = JSON.parse(opts.body);
    if (url === EXA_ENDPOINT) {
      if (exaThrow) throw exaThrow();
      return exaStatus === 200 ? res({ requestId: 'fake', resolvedSearchType: 'neural', results: exaResults, searchTime: 850, costDollars: { total: 0.007 } }) : res({}, exaStatus);
    }
    const chat = (message) => res({ choices: [{ message }] });
    const toolMsg = body.messages.filter((m) => m.role === 'tool').at(-1);
    if (!toolMsg) {
      return brain === 'nosearch' ? chat({ content: 'I think Node.js 24 is the current LTS, from memory.' })
        : chat({ content: '', tool_calls: [{ id: 'c1', function: { name: 'web_search', arguments: JSON.stringify({ query: 'current Node.js LTS release' }) } }] });
    }
    let t = {}; try { t = JSON.parse(toolMsg.content); } catch { /* none */ }
    const list = (t.results || []).map((x, i) => `${i + 1}. ${x.title}: ${x.url}`).join('\n');
    if (t.error) return chat({ content: 'The search could not be done, so I cannot confirm this from the web right now.' });
    return chat({ content: `Node.js 24 is the current LTS release line, according to the search results.\n\nSources:\n${list}${brain === 'fabricate' ? '\n4. Invented source: https://made-up.example/node-lts' : ''}` });
  };
}

async function main() {
  if (process.argv.includes('--selftest')) {
    preflight();
    delete process.env.GROQ_API_KEY; delete process.env.EXA_API_KEY; // the self-test must not depend on real keys, and the tripwire proves it uses no internet
    const GK = 'gsk_selftest_key_0000000000'; const EK = 'a1b2c3d4-e5f6-4789-8abc-def012345678';
    const timeoutErr = () => { const e = new Error('The operation was aborted due to timeout'); e.name = 'TimeoutError'; return e; };
    const dnsErr = () => { const e = new TypeError('fetch failed'); e.cause = { code: 'ENOTFOUND' }; return e; };
    const orig = globalThis.fetch;
    const go = (opts, extra = {}) => run({ fetchImpl: fakeServices(opts), groqKey: GK, exaKey: EK, quiet: true, allowHosts: ['127.0.0.1'], ...extra });
    const good = await go({});
    const stageAOnly = await go({}, { groqKey: undefined });
    const bad = await go({ exaStatus: 401 });
    const nosearch = await go({ brain: 'nosearch' });
    const fabricate = await go({ brain: 'fabricate' });
    const slow = await go({ exaThrow: timeoutErr });
    const down = await go({ exaThrow: dnsErr });
    const names = (r) => r.filter((x) => !x.ok).map((x) => x.name);
    const has = (r, re) => names(r).some((n) => re.test(n));
    const passes = (r, re) => r.some((x) => x.ok && re.test(x.name));
    const all = [good, stageAOnly, bad, nosearch, fabricate, slow, down];
    const goodFails = names(good);
    console.log(`selftest 1, healthy fakes (A + B)        : ${good.length - goodFails.length}/${good.length} checks pass`, goodFails);
    console.log(`selftest 2, Stage A only (no Groq key)   : ${stageAOnly.length - names(stageAOnly).length}/${stageAOnly.length} checks pass`, names(stageAOnly));
    console.log(`selftest 3, Exa rejects the key (401)    : FAILS ${names(bad).length} check(s):`, names(bad).map((n) => n.slice(0, 40)));
    console.log(`selftest 4, EL answers without searching : FAILS ${names(nosearch).length} check(s):`, names(nosearch).map((n) => n.slice(0, 40)));
    console.log(`selftest 5, EL invents a source link     : FAILS ${names(fabricate).length} check(s):`, names(fabricate).map((n) => n.slice(0, 40)));
    console.log(`selftest 6, Exa times out                : net errors seen = ${JSON.stringify(slow.net)}`);
    console.log(`selftest 7, Exa unreachable (DNS)        : net errors seen = ${JSON.stringify(down.net)}`);
    const checks = {
      'healthy run: every check passes': goodFails.length === 0,
      'Stage A alone passes without a Groq key and skips Stage B': names(stageAOnly).length === 0 && !stageAOnly.some((x) => /EL \(Groq\) decided/.test(x.name)),
      'rejected Exa key: EXA ACCEPTED fails': has(bad, /EXA ACCEPTED/),
      'rejected Exa key: EL is reported as receiving no results': has(bad, /EL received real results/),
      'no search: "decided to search" fails (the model, not the code)': has(nosearch, /decided to search/) && !has(nosearch, /EXA ACCEPTED/),
      'invented link: the SERVER GUARD check fails while the removed link means no foreign link is shown': has(fabricate, /server guard had to remove nothing/) && passes(fabricate, /every link in the answer is one Exa really returned/),
      'timeout is classified as timeout, never as unreachable': slow.net.some((x) => x.kind === 'timeout') && !slow.net.some((x) => x.kind === 'unreachable'),
      'DNS failure is classified as unreachable, never as timeout': down.net.some((x) => x.kind === 'unreachable') && !down.net.some((x) => x.kind === 'timeout'),
      'tripwire passed in every run (only 127.0.0.1 was contacted)': all.every((r) => passes(r, /no network request went anywhere/)),
      'in-memory database proof passed in every run': all.every((r) => passes(r, /actually opened is IN MEMORY/)),
      'persistent data untouched in every run': all.every((r) => passes(r, /persistent data untouched/)),
      'global fetch restored after every run': globalThis.fetch === orig,
    };
    for (const [k, v] of Object.entries(checks)) console.log(`${v ? 'ok  ' : 'BAD '} ${k}`);
    const ok = Object.values(checks).every(Boolean);
    console.log(ok ? 'SELFTEST OK' : 'SELFTEST FAILED'); process.exit(ok ? 0 : 1);
  }
  const info = preflight();
  console.log(`server folder : ${info.dir}\npackage       : ${info.name} ${info.version}   (node ${info.node})\ncode checked  : src/ai/providers/exa.js sha256:${info.exaSha}   src/ai/assistant.js sha256:${info.assistantSha}\n`);
  const exaKey = process.env.EXA_API_KEY; const groqKey = process.env.GROQ_API_KEY;
  if (!exaKey || !load('ai/limits').AI_LIMITS.EXA_KEY_PATTERN.test(exaKey)) { console.error('Set EXA_API_KEY in the environment (it is never printed or stored). Add GROQ_API_KEY too to also test the whole flow.'); process.exit(2); }
  if (groqKey && !/^gsk_/.test(groqKey)) { console.error('GROQ_API_KEY does not look like a Groq key (it should start with gsk_).'); process.exit(2); }
  const probing = (url, opts) => globalThis.fetch(url, opts);
  const results = await run({ fetchImpl: probing, groqKey, exaKey, allowHosts: ['127.0.0.1', 'api.exa.ai', 'api.groq.com'] });
  const unreachable = results.net.filter((x) => x.kind === 'unreachable'); const timedOut = results.net.filter((x) => x.kind === 'timeout');
  if (unreachable.length) console.log(`\nA SERVICE COULD NOT BE REACHED from this machine (${[...new Set(unreachable.map((x) => x.code))].join(', ')}): network/DNS/firewall. This is not a code failure: run it where api.exa.ai and api.groq.com are reachable.`);
  else if (timedOut.length) console.log('\nA REQUEST TIMED OUT (the service was reachable but too slow). Exa has a 15 s limit here; Groq calls have their own. If it repeats, tell me which one.');
  const pass = results.filter((x) => x.ok).length;
  console.log(`\nSUMMARY: ${pass}/${results.length} checks passed${pass === results.length ? '' : '  <-- see FAIL lines above'}${groqKey ? '' : '   (Stage B skipped: no GROQ_API_KEY)'}`);
  process.exit(unreachable.length ? 4 : pass === results.length ? 0 : 1);
}

if (require.main === module) main().catch((e) => { console.error('script error:', [process.env.GROQ_API_KEY, process.env.EXA_API_KEY].filter(Boolean).reduce((acc, k) => acc.split(k).join('[key]'), String((e && e.message) || e))); process.exit(3); });
module.exports = { run };
