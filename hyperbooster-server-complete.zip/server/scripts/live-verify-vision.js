#!/usr/bin/env node
'use strict';
// LIVE verification of EL IMAGE ANALYSIS (Step 4) against the REAL Groq API.
//
//   cd <your server folder>
//   GROQ_API_KEY=gsk_...  node /path/to/live-verify-vision.js
//
// What it does: runs the real HYPERBOOSTER code (no changes to it) with an IN-MEMORY database, so none of your data is
// read or written, and a network tripwire that only allows this machine and api.groq.com. It builds two tiny PNG images
// itself (no files needed): image 1 is a blue left half and a red right half, image 2 is green with a yellow square.
// It uses your key only in the Authorization header, via the real code path, and never prints it. It makes 2 Groq
// calls in total: ONE real vision call (the vision model describes the two images), then EL's normal answer call.
// (Before that it tries the image route with vision OFF, which must be refused without contacting Groq at all.)
// Run  node live-verify-vision.js --selftest  to test this script against fake Groq servers (no key needed).
// Cost of the one vision call: about 4 thousand input tokens (each image costs 2,048), a few cents at most.

process.env.NODE_ENV = 'development';
const path = require('node:path');
// Run from anywhere: if this file sits in <server>/scripts, the server folder is its parent; otherwise the current folder.
const SERVER = path.resolve(process.env.HB_SERVER_DIR || (path.basename(__dirname) === 'scripts' ? path.join(__dirname, '..') : process.cwd()));
const load = (p) => require(path.join(SERVER, 'src', p));

const fs = require('node:fs');
const crypto = require('node:crypto');

// Refuses to run in the wrong folder, so the test always exercises the real server code in THIS folder.
function preflight() {
  const [maj, min] = process.versions.node.split('.').map(Number);
  if (maj < 22 || (maj === 22 && min < 13)) throw new Error(`Node ${process.versions.node} is too old: the server needs Node >= 22.13 (node:sqlite).`);
  let pkg;
  try { pkg = JSON.parse(fs.readFileSync(path.join(SERVER, 'package.json'), 'utf8')); } catch { /* handled below */ }
  const need = ['src/ai/vision.js', 'src/ai/assistant.js', 'src/app.js'].filter((f) => !fs.existsSync(path.join(SERVER, f)));
  if (!pkg || pkg.name !== 'hyperbooster-server' || need.length) {
    throw new Error(`"${SERVER}" is not the HYPERBOOSTER server folder with the Step 4 (image analysis) code (looked for package.json "hyperbooster-server"${need.length ? ' and ' + need.join(', ') : ''}). cd into the folder that contains package.json and src/, or set HB_SERVER_DIR.`);
  }
  const sha = (f) => crypto.createHash('sha256').update(fs.readFileSync(path.join(SERVER, f))).digest('hex').slice(0, 12);
  return { dir: SERVER, name: pkg.name, version: pkg.version, node: process.versions.node, visionSha: sha('src/ai/vision.js'), assistantSha: sha('src/ai/assistant.js') };
}

// Name + size + modified time of everything under <server>/data, to prove the run did not touch persistent data.
function statLine(f) { try { const st = fs.statSync(f); return `${f}|${st.size}|${st.mtimeMs}`; } catch { return `${f}|absent`; } }
// If DATABASE_PATH points your real database somewhere other than <server>/data, that file (+ its -wal/-shm) is snapshotted too.
function prodDbSnapshot() {
  const v = process.env.DATABASE_PATH;
  if (!v || v === ':memory:') return '(DATABASE_PATH not set: default location under <server>/data)';
  const f = path.resolve(SERVER, v);
  return [f, `${f}-wal`, `${f}-shm`].map(statLine).join('\n');
}
function dataSnapshot() {
  return `${dataFolderSnapshot()}\n--\n${prodDbSnapshot()}`;
}
function dataFolderSnapshot() {
  const dir = path.join(SERVER, 'data');
  if (!fs.existsSync(dir)) return '(no data/ folder)';
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : [`${path.relative(dir, path.join(d, e.name))}|${fs.statSync(path.join(d, e.name)).size}|${fs.statSync(path.join(d, e.name)).mtimeMs}`]));
  return walk(dir).sort().join('\n') || '(data/ is empty)';
}

const ADMIN_PW = 'a-strong-admin-passphrase';
const MAIN_MODEL = 'openai/gpt-oss-120b';
const DEFAULT_VISION_MODEL = 'qwen/qwen3.8-27b';
const IMG_ROUTE = '/api/admin/ai/chat/images';
const QUESTION = 'These are two small test images. Describe the colours you see in each one.';
const BIG = { max: 1e6, windowMs: 6e4 };
const LIMITS = { apiPerIp: BIG, loginPerIp: BIG, loginPerAccount: BIG, registerPerIp: BIG, orderPerUser: BIG, adminLoginPerIp: BIG, adminLoginPerAccount: BIG, adminOtpPerIp: BIG, adminApiPerIp: BIG, adminAiChatPerAdmin: BIG, adminAiChatPerIp: BIG, adminAiSettingsPerIp: BIG };

// ---- two small valid PNGs, built here so no image files are needed ----
const zlib = require('node:zlib');
function makePng(w, h, colorAt) {
  const stride = w * 3 + 1; const raw = Buffer.alloc(stride * h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const [r, g, b] = colorAt(x, y); const o = y * stride + 1 + x * 3; raw[o] = r; raw[o + 1] = g; raw[o + 2] = b; }
  const chunk = (type, data) => { const t = Buffer.from(type); const len = Buffer.alloc(4); len.writeUInt32BE(data.length); const crc = Buffer.alloc(4); crc.writeUInt32BE(zlib.crc32(Buffer.concat([t, data])) >>> 0); return Buffer.concat([len, t, data, crc]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2; // 8-bit RGB
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}
const IMAGE_1 = makePng(256, 256, (x) => (x < 128 ? [0, 60, 255] : [230, 20, 20]));
const IMAGE_2 = makePng(256, 256, (x, y) => (x > 88 && x < 168 && y > 88 && y < 168 ? [250, 220, 0] : [20, 170, 60]));
const IMAGES = [IMAGE_1, IMAGE_2].map((b) => ({ mediaType: 'image/png', data: b.toString('base64') }));

class Client {
  constructor(base) { this.base = base; this.jar = {}; this.csrf = null; }
  async call(method, url, body) {
    const cookie = Object.entries(this.jar).map(([k, v]) => `${k}=${v}`).join('; ');
    const res = await fetch(this.base + url, {
      method, redirect: 'manual',
      headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(cookie ? { Cookie: cookie } : {}), ...(this.csrf && method !== 'GET' ? { 'X-CSRF-Token': this.csrf } : {}) },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    const text = await res.text(); let json = null; try { json = JSON.parse(text); } catch { /* not json */ }
    for (const c of res.headers.getSetCookie?.() ?? []) { const [pair] = c.split(';'); const i = pair.indexOf('='); const k = pair.slice(0, i); const v = pair.slice(i + 1); if (v === '') delete this.jar[k]; else this.jar[k] = v; }
    return { status: res.status, json, text };
  }
  get(u) { return this.call('GET', u); }
  post(u, b) { return this.call('POST', u, b); }
  patch(u, b) { return this.call('PATCH', u, b); }
}

// A request that never got an answer is either a timeout (Groq was reachable but slow) or unreachable (DNS/firewall/offline).
function classifyNetError(e) {
  const name = (e && e.name) || ''; const code = (e && (e.code || (e.cause && e.cause.code))) || '';
  return { kind: name === 'TimeoutError' || name === 'AbortError' ? 'timeout' : 'unreachable', code: String(code || name || 'error').slice(0, 40) };
}

// Wraps fetch: passes every call straight through to the real fetch, but records what was sent and what came back
// (never the key, never image data), so the checks below can say what really happened.
function recorder(realFetch, key, log) {
  return async (url, opts) => {
    const body = JSON.parse(opts.body);
    const first = body.messages[0];
    const isVision = Array.isArray(first && first.content) && first.content.some((p) => p.type === 'image_url');
    const rec = {
      kind: isVision ? 'vision' : 'main', url, method: opts.method,
      authBearer: opts.headers && opts.headers.Authorization === `Bearer ${key}`, keyInBody: opts.body.includes(key),
      model: body.model, toolTypes: (body.tools || []).map((t) => t.type), toolNames: (body.tools || []).map((t) => t.function && t.function.name).filter(Boolean),
      effort: body.reasoning_effort, maxTokens: body.max_completion_tokens, roles: body.messages.map((m) => m.role),
      partTypes: isVision ? first.content.map((p) => p.type) : undefined, bodyKeys: Object.keys(body).sort(), bodyBytes: opts.body.length,
      toolMessages: body.messages.filter((m) => m.role === 'tool').map((m) => m.content),
    };
    const t0 = Date.now();
    let res;
    try { res = await realFetch(url, opts); } catch (e) { rec.networkError = String((e && e.message) || e).split(key).join('[key]').slice(0, 200); Object.assign(rec, { netKind: classifyNetError(e).kind, netCode: classifyNetError(e).code }); rec.ms = Date.now() - t0; log.push(rec); throw e; }
    rec.status = res.status; rec.ms = Date.now() - t0;
    try {
      const c = typeof res.clone === 'function' ? res.clone() : res;
      if (!res.ok) rec.errorBody = (await c.text()).split(key).join('[key]').slice(0, 400);
      else if (isVision) {
        const j = await c.json(); const ch = (j.choices || [])[0] || {}; const m = ch.message || {};
        rec.visionTextChars = typeof m.content === 'string' ? m.content.length : 0; rec.responseFields = Object.keys(m); rec.finish = ch.finish_reason;
        rec.usage = j.usage ? { prompt: j.usage.prompt_tokens, completion: j.usage.completion_tokens } : undefined;
      }
    } catch { /* diagnostics only */ }
    log.push(rec);
    return res;
  };
}

async function run({ fetchImpl, apiKey, quiet = false, allowHosts = ['127.0.0.1'] }) {
  const { loadConfig } = load('config'); const { createApp } = load('app'); const { hashPassword } = load('security');
  const results = []; const log = [];
  const out = (...a) => { if (!quiet) console.log(...a); };
  const check = (name, ok, detail = '') => { results.push({ name, ok: !!ok, detail }); out(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? `  [${detail}]` : ''}`); };

  // Setup step that must succeed: records a check AND stops with a readable message instead of a TypeError later.
  const must = (name, ok, detail = '') => { check(name, ok, detail); if (!ok) throw new Error(`setup step failed: ${name}${detail ? ` [${detail}]` : ''}`); };

  // Network tripwire: every fetch in this process is checked. Only this machine (and, live, api.groq.com) is allowed, so
  // Kora, the provider, Resend or anything else can never be contacted by this script, even by accident.
  const origFetch = globalThis.fetch; const hosts = new Set(); const blockedHosts = new Set();
  globalThis.fetch = async (url, opts) => {
    let h = '?'; try { h = new URL(typeof url === 'string' ? url : (url && url.url) || String(url)).hostname; } catch { /* leave ? */ }
    hosts.add(h); if (!allowHosts.includes(h)) { blockedHosts.add(h); throw new Error(`blocked by the script's network tripwire: ${h}`); }
    return origFetch(url, opts);
  };

  const cfg = loadConfig({}, { databasePath: ':memory:', logRequests: false, mailTransport: 'memory', limits: LIMITS, staticDir: '/nonexistent' });
  if (cfg.databasePath !== ':memory:') throw new Error('refusing to run: the config for this run is not in-memory');
  const dataBefore = dataSnapshot();
  let app;
  try {
  app = createApp(cfg, { aiFetch: recorder(fetchImpl, apiKey, log) });
  const dbList = app.db.prepare('PRAGMA database_list').all();
  check('the database that was actually opened is IN MEMORY (no file behind it: your real database is never opened)', dbList.length > 0 && dbList.every((d) => !d.file), JSON.stringify(dbList.map((d) => ({ name: d.name, file: d.file || '(none)' }))));
  {
    await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
    const boss = new Client(`http://127.0.0.1:${app.server.address().port}`);
    app.db.prepare('INSERT INTO admins (email, name, password_hash) VALUES (?,?,?)').run('boss@example.com', 'The Boss', await hashPassword(ADMIN_PW));
    const login = await boss.post('/api/admin/login', { email: 'boss@example.com', password: ADMIN_PW });
    const mail = app.mailer.outbox.at(-1); const code = mail && /code is (\d{6})/.exec(mail.text);
    must('admin login step 1 accepted and a one-time code was emailed (in-memory mailer)', login.status === 200 && !!code, `HTTP ${login.status}`);
    const otp = await boss.post('/api/admin/verify-otp', { code: code[1] });
    must('admin one-time code accepted and a CSRF token issued', otp.status === 200 && !!(otp.json && otp.json.csrfToken), `HTTP ${otp.status}`);
    boss.csrf = otp.json.csrfToken;
    const READ = { read_dashboard: true, read_orders: true, read_services: true, read_customers: true, read_wallet: true, read_audit: true };
    const save = (vision) => boss.patch('/api/admin/ai/settings', { enabled: true, apiKey, model: MAIN_MODEL, toolPermissions: { ...READ, vision }, currentPassword: ADMIN_PW });
    const visionAudits = () => app.db.prepare("SELECT action, details FROM audit_logs WHERE action LIKE 'AI_VISION%' ORDER BY id").all().map((x) => ({ action: x.action, d: JSON.parse(x.details || '{}') }));
    const dump = () => app.db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all().map((t) => JSON.stringify(app.db.prepare(`SELECT * FROM "${t.name}"`).all())).join('\n');

    out('\n-- 1. image analysis is OFF by default: the image route must refuse, without contacting Groq at all --');
    const s0 = await save(false);
    check('settings saved with image analysis OFF', s0.status === 200 && s0.json.toolPermissions.vision === false, `HTTP ${s0.status}`);
    const off = await boss.post(IMG_ROUTE, { message: QUESTION, images: IMAGES });
    check('OFF: the image route is refused (HTTP 403) and nothing at all was sent to Groq', off.status === 403 && log.length === 0, `HTTP ${off.status}, ${log.length} Groq request(s)`);

    out('\n-- 2. switching it ON, then the one real vision call --');
    const s = await save(true);
    check('settings saved: EL enabled, image analysis ON, vision model = the default ' + DEFAULT_VISION_MODEL, s.status === 200 && s.json.toolPermissions.vision === true && s.json.visionModel === DEFAULT_VISION_MODEL, `HTTP ${s.status}`);
    const r = await boss.post(IMG_ROUTE, { message: QUESTION, images: IMAGES });
    const visions = log.filter((x) => x.kind === 'vision'); const mains = log.filter((x) => x.kind === 'main');
    check('image request accepted by the server (HTTP 200)', r.status === 200, `HTTP ${r.status}${r.status !== 200 ? ' ' + r.text.slice(0, 160) : ''}`);
    check('exactly ONE vision request was sent to Groq', visions.length === 1, `${visions.length} vision request(s)`);

    const vr = visions[0];
    if (vr) {
      check('GROQ ACCEPTED the vision request (HTTP 200)', vr.status === 200, `HTTP ${vr.status}${vr.errorBody ? ' | Groq said: ' + vr.errorBody : ''}${vr.networkError ? ' | network: ' + vr.networkError : ''}`);
      check('request shape: URL, default vision model, one user message = text + 2 image parts, reasoning none, 1024 max tokens, no tools',
        vr.url === 'https://api.groq.com/openai/v1/chat/completions' && vr.method === 'POST' && vr.model === DEFAULT_VISION_MODEL && JSON.stringify(vr.roles) === '["user"]' &&
        JSON.stringify(vr.partTypes) === '["text","image_url","image_url"]' && vr.effort === 'none' && vr.maxTokens === 1024 && vr.toolTypes.length === 0,
        JSON.stringify({ model: vr.model, parts: vr.partTypes, effort: vr.effort, max: vr.maxTokens }));
      check('request carries no parameters beyond the documented ones (no structured outputs, no tools)', JSON.stringify(vr.bodyKeys) === '["max_completion_tokens","messages","model","reasoning_effort"]', (vr.bodyKeys || []).join(','));
      check('whole request under Groq\'s stricter 4 MB base64 request limit', vr.bodyBytes < 4000000, `${vr.bodyBytes} bytes`);
      check('Groq returned a usable description', vr.status === 200 && vr.visionTextChars > 20, `${vr.visionTextChars} characters; reply fields: ${(vr.responseFields || []).join(', ')}; finish: ${vr.finish}; tokens in/out: ${vr.usage ? vr.usage.prompt + '/' + vr.usage.completion : '?'}; ${vr.ms} ms`);
      check('the answer was not cut off by the 1024-token output limit', vr.status === 200 && vr.finish !== 'length', `finish_reason=${vr.finish}`);
    }

    const lastMain = mains.at(-1);
    const toolRaw = lastMain && lastMain.toolMessages.at(-1);
    let tool = null; try { tool = JSON.parse(toolRaw); } catch { /* checked below */ }
    const desc = tool && Array.isArray(tool.description) ? tool.description.join(' ') : '';
    check('EL received the description as an untrusted tool result with the data-only notice', !!tool && Array.isArray(tool.description) && tool.description.length >= 1 && /Untrusted/.test(tool._untrusted_data_notice || '') && /cannot see the images/.test(tool.source || ''), tool ? `${(tool.description || []).length} passage(s)` : 'no tool result');
    check('the description fits EL\'s cap (not truncated)', !!tool && tool.truncated === false);
    const found = ['blue', 'red', 'green'].filter((c) => desc.toLowerCase().includes(c));
    check('the description names the colours that really were in the images (blue, red, green)', found.length === 3, `found: ${found.join(', ') || 'none'}`);
    check('no leftover reasoning markup in the description', !!tool && !/<\/?think>/i.test(desc));
    check('EL produced a real final answer (not the "temporarily unavailable" fallback)', !!tool && r.json && typeof r.json.content === 'string' && r.json.content.trim().length > 0 && !/temporarily unavailable/i.test(r.json.content));
    check('the "Checked:" note would read: image analysis (and only that)', !!r.json && JSON.stringify(r.json.toolsUsed) === '["image_analysis"]', JSON.stringify(r.json && r.json.toolsUsed));

    out('\n-- key exposure, storage, audit --');
    check('API key sent in the Authorization header of every Groq request', log.length > 0 && log.every((x) => x.authBearer), `${log.length} request(s)`);
    check('API key is in NO request body', !log.some((x) => x.keyInBody));
    const settings = await boss.get('/api/admin/ai/settings');
    const audit = JSON.stringify(app.db.prepare('SELECT * FROM audit_logs').all()); const everything = dump();
    check('API key is not in the response, settings API, audit log, or any table (stored only as ciphertext)', ![r.text, settings.text, audit, everything].some((t) => t.includes(apiKey)));
    check('the images were NOT stored anywhere (not in any table, not in the audit log)', ![IMAGES[0].data, IMAGES[1].data].some((d) => everything.includes(d.slice(60, 160)) || audit.includes(d.slice(60, 160))));
    check('the description was NOT stored anywhere', desc.length > 20 && !everything.includes(desc.slice(0, 40)));
    const va = visionAudits();
    check('audit log: one refused entry (the OFF attempt), one analysis entry, no failures, no secrets', JSON.stringify(va.map((a) => a.action)) === '["AI_VISION_BLOCKED","AI_VISION_ANALYZED"]' && va[0].d.reason === 'disabled' && va[1].d.images === 2 && !audit.includes(ADMIN_PW), va.map((a) => a.action).join(', '));
    const msgs = app.db.prepare('SELECT role, content FROM ai_messages ORDER BY id').all();
    check('saved conversation holds only your question plus an "attached" note', msgs[0] && msgs[0].content === `${QUESTION}\n\n[2 images attached: analysed once, never saved]`);

    out('\n-- 3. switching image analysis OFF again --');
    await save(false);
    const before = log.filter((x) => x.kind === 'vision').length;
    const off2 = await boss.post(IMG_ROUTE, { message: QUESTION, images: IMAGES });
    check('OFF again: refused (HTTP 403) and no further vision request was sent', off2.status === 403 && log.filter((x) => x.kind === 'vision').length === before);

    if (!quiet) {
      out('\n-- what came back (for your eyes) --');
      out('description   :', desc.slice(0, 500) || '(none)');
      out("EL's answer   :", ((r.json && r.json.content) || '').slice(0, 500));
      out('timings (ms)  :', log.map((x) => `${x.kind}:${x.ms}`).join('  '));
    }

  }
  } finally { if (app) await app.close(); globalThis.fetch = origFetch; }
  check(`no network request went anywhere except: ${allowHosts.join(', ')}`, blockedHosts.size === 0, `hosts contacted: ${[...hosts].join(', ') || '(none)'}${blockedHosts.size ? ` | BLOCKED: ${[...blockedHosts].join(', ')}` : ''}`);
  check('persistent data untouched: <server>/data (and any DATABASE_PATH database) identical before and after the run', dataSnapshot() === dataBefore);
  results.net = log.filter((x) => x.netKind).map((x) => ({ kind: x.netKind, code: x.netCode }));
  return results;
}

// ---------------------------------------------------------------------------------------------- self-test
function fakeGroq({ visionStatus = 200, visionThrow = null, visionText = 'The first image is split down the middle: a blue left half and a red right half. The second image is mostly green with a small yellow square in the centre.' } = {}) {
  const res = (message, status = 200) => ({ ok: status === 200, status, clone() { return this; }, json: async () => ({ choices: [{ message, finish_reason: 'stop' }], usage: { prompt_tokens: 4200, completion_tokens: 45 } }), text: async () => (status === 200 ? '' : '{"error":{"message":"fake rejection"}}') });
  return async (url, opts) => {
    const body = JSON.parse(opts.body); const first = body.messages[0];
    if (Array.isArray(first.content) && first.content.some((p) => p.type === 'image_url')) {
      if (visionThrow) throw visionThrow();
      return visionStatus === 200 ? res({ content: visionText }) : res({}, visionStatus);
    }
    return res({ content: body.messages.some((m) => m.role === 'tool') ? 'Image 1 is half blue and half red; image 2 is green with a yellow square.' : 'No image was provided.' });
  };
}

async function main() {
  if (process.argv.includes('--selftest')) {
    preflight();
    delete process.env.GROQ_API_KEY; // the self-test must not depend on a real key, and the tripwire proves it uses no internet
    const KEY = 'gsk_selftest_key_0000000000';
    const timeoutErr = () => { const e = new Error('The operation was aborted due to timeout'); e.name = 'TimeoutError'; return e; };
    const dnsErr = () => { const e = new TypeError('fetch failed'); e.cause = { code: 'ENOTFOUND' }; return e; };
    const orig = globalThis.fetch;
    const good = await run({ fetchImpl: fakeGroq(), apiKey: KEY, quiet: true });
    const bad = await run({ fetchImpl: fakeGroq({ visionStatus: 400 }), apiKey: KEY, quiet: true });
    const vague = await run({ fetchImpl: fakeGroq({ visionText: 'A picture with some shapes in it.' }), apiKey: KEY, quiet: true });
    const empty = await run({ fetchImpl: fakeGroq({ visionText: '' }), apiKey: KEY, quiet: true });
    const slow = await run({ fetchImpl: fakeGroq({ visionThrow: timeoutErr }), apiKey: KEY, quiet: true });
    const down = await run({ fetchImpl: fakeGroq({ visionThrow: dnsErr }), apiKey: KEY, quiet: true });
    const names = (r) => r.filter((x) => !x.ok).map((x) => x.name);
    const has = (r, re) => names(r).some((n) => re.test(n));
    const passes = (r, re) => r.some((x) => x.ok && re.test(x.name));
    const all = [good, bad, vague, empty, slow, down];
    const goodFails = names(good);
    console.log(`selftest 1, healthy fake Groq           : ${good.length - goodFails.length}/${good.length} checks pass`, goodFails);
    console.log(`selftest 2, Groq rejects the images 400 : FAILS ${names(bad).length} check(s) as it should:`, names(bad).map((n) => n.slice(0, 44)));
    console.log(`selftest 3, vague description           : FAILS ${names(vague).length} check(s):`, names(vague).map((n) => n.slice(0, 44)));
    console.log(`selftest 4, empty description           : FAILS ${names(empty).length} check(s):`, names(empty).map((n) => n.slice(0, 44)));
    console.log(`selftest 5, vision times out            : net errors seen = ${JSON.stringify(slow.net)}`);
    console.log(`selftest 6, Groq unreachable (DNS)      : net errors seen = ${JSON.stringify(down.net)}`);
    const checks = {
      'healthy run: every check passes': goodFails.length === 0,
      'OFF-by-default refusal checked, and passes, in the healthy run': passes(good, /OFF: the image route is refused/),
      'rejected images: GROQ ACCEPTED fails': has(bad, /GROQ ACCEPTED/),
      'rejected images: usable description fails': has(bad, /usable description/),
      'rejected images: audit check FAILS (no false pass)': has(bad, /audit log: one refused entry/),
      'vague description: ONLY the colour check catches it (the structure is fine)': has(vague, /names the colours/) && !has(vague, /GROQ ACCEPTED/) && !has(vague, /request shape/),
      'empty description: reported as failed, never as a pass': has(empty, /usable description/) && has(empty, /real final answer|received the description/),
      'timeout is classified as timeout, never as unreachable': slow.net.some((x) => x.kind === 'timeout') && !slow.net.some((x) => x.kind === 'unreachable'),
      'DNS failure is classified as unreachable, never as timeout': down.net.some((x) => x.kind === 'unreachable') && !down.net.some((x) => x.kind === 'timeout'),
      'tripwire passed in every run (only 127.0.0.1 was contacted)': all.every((r) => passes(r, /no network request went anywhere/)),
      'in-memory database proof passed in every run': all.every((r) => passes(r, /actually opened is IN MEMORY/)),
      'persistent data untouched in every run': all.every((r) => passes(r, /persistent data untouched/)),
      'global fetch restored after every run': globalThis.fetch === orig,
    };
    for (const [k, v] of Object.entries(checks)) console.log(`${v ? 'ok  ' : 'BAD '} ${k}`);
    const ok = Object.values(checks).every(Boolean);
    console.log(ok ? 'SELFTEST OK' : 'SELFTEST FAILED'); process.exit(ok ? 0 : 1);
  }
  const info = preflight();
  console.log(`server folder : ${info.dir}\npackage       : ${info.name} ${info.version}   (node ${info.node})\ncode checked  : src/ai/vision.js sha256:${info.visionSha}   src/ai/assistant.js sha256:${info.assistantSha}\n`);
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey || !/^gsk_/.test(apiKey)) { console.error('Set GROQ_API_KEY=gsk_... in the environment (it is never printed or stored).'); process.exit(2); }
  const probing = (url, opts) => globalThis.fetch(url, opts);
  const results = await run({ fetchImpl: probing, apiKey, allowHosts: ['127.0.0.1', 'api.groq.com'] });
  const unreachable = results.net.filter((x) => x.kind === 'unreachable'); const timedOut = results.net.filter((x) => x.kind === 'timeout');
  if (unreachable.length) console.log(`\nGROQ COULD NOT BE REACHED from this machine (${[...new Set(unreachable.map((x) => x.code))].join(', ')}): network/DNS/firewall. This is not a code failure: run it where api.groq.com is reachable.`);
  else if (timedOut.length) console.log('\nA REQUEST TO GROQ TIMED OUT (Groq was reachable but too slow). The vision limit is 45 s. If this repeats, it is a Step 4 timeout question to fix, not a connectivity problem.');
  const pass = results.filter((x) => x.ok).length;
  console.log(`\nSUMMARY: ${pass}/${results.length} checks passed${pass === results.length ? '' : '  <-- see FAIL lines above'}`);
  process.exit(unreachable.length ? 4 : pass === results.length ? 0 : 1);
}

if (require.main === module) main().catch((e) => { console.error('script error:', String((e && e.message) || e).split(process.env.GROQ_API_KEY || '\u0000').join('[key]')); process.exit(3); });
module.exports = { run };
