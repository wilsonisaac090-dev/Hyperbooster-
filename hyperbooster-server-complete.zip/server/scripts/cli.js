'use strict';
// Maintenance commands (run on the server, not exposed over HTTP):
//   node scripts/cli.js seed
//   node scripts/cli.js credit <email> <amount-in-naira>     (testing / manual top-up)
//   node scripts/cli.js make-admin <email>
//   node scripts/cli.js create-admin <email> [name]          (Admin Panel account; asks for a password)
//   node scripts/cli.js reset-admin-password <email>
//   (non-interactive: set ADMIN_PASSWORD in the environment instead of being prompted)
const path = require('node:path');
try {
  process.loadEnvFile(path.join(__dirname, '..', '.env'));
} catch {
  /* optional */
}
const { loadConfig } = require('../src/config');
const { openDatabase, transaction } = require('../src/db');
const { applyLedger } = require('../src/wallet');
const { seedServices } = require('../src/seed');
const { hashPassword } = require('../src/security');

function promptHidden(question) {
  return new Promise((resolve, reject) => {
    if (process.env.ADMIN_PASSWORD) return resolve(process.env.ADMIN_PASSWORD);
    if (!process.stdin.isTTY) return reject(new Error('No terminal available. Set ADMIN_PASSWORD in the environment.'));
    process.stdout.write(question);
    let value = '';
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.setEncoding('utf8');
    const onData = (ch) => {
      for (const c of ch) {
        if (c === '\r' || c === '\n' || c === '\u0004') {
          process.stdin.setRawMode(false);
          process.stdin.pause();
          process.stdin.off('data', onData);
          process.stdout.write('\n');
          return resolve(value);
        }
        if (c === '\u0003') process.exit(130);
        if (c === '\u007f' || c === '\b') value = value.slice(0, -1);
        else value += c;
      }
    };
    process.stdin.on('data', onData);
  });
}

function checkAdminPassword(pw) {
  if (typeof pw !== 'string' || pw.length < 12) throw new Error('Admin password must be at least 12 characters.');
  if (pw.length > 128) throw new Error('Admin password must be 128 characters or fewer.');
}

function nairaToKobo(text) {
  if (!/^\d{1,9}(\.\d{1,2})?$/.test(String(text))) throw new Error('Amount must be a positive number like 5000 or 2500.50');
  const [whole, frac = ''] = String(text).split('.');
  const kobo = Number(whole) * 100 + Number(frac.padEnd(2, '0'));
  if (kobo <= 0) throw new Error('Amount must be greater than zero');
  return kobo;
}

function findUser(db, email) {
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(String(email || '').trim().toLowerCase());
  if (!user) throw new Error(`No user with email ${email}`);
  return user;
}

const [cmd, ...args] = process.argv.slice(2);
const db = openDatabase(loadConfig().databasePath);

(async () => {
try {
  if (cmd === 'seed') {
    console.log(`Inserted ${seedServices(db)} new placeholder services.`);
  } else if (cmd === 'credit') {
    const user = findUser(db, args[0]);
    const kobo = nairaToKobo(args[1]);
    const result = transaction(db, () =>
      applyLedger(db, {
        userId: user.id,
        deltaKobo: kobo,
        type: 'adjustment',
        referenceType: 'manual',
        description: 'Manual credit (CLI)',
      })
    );
    console.log(`Credited ${user.email}. New balance: NGN ${(result.balanceKobo / 100).toFixed(2)}`);
  } else if (cmd === 'make-admin') {
    const user = findUser(db, args[0]);
    db.prepare("UPDATE users SET role = 'admin' WHERE id = ?").run(user.id);
    console.log(`${user.email} is now an admin.`);
  } else if (cmd === 'create-admin') {
    const email = String(args[0] || '').trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw new Error('Usage: create-admin <email> [name]');
    if (db.prepare('SELECT 1 FROM admins WHERE email = ?').get(email)) throw new Error('An admin with that email already exists.');
    const password = await promptHidden('New admin password (min 12 characters): ');
    checkAdminPassword(password);
    db.prepare('INSERT INTO admins (email, name, password_hash) VALUES (?,?,?)').run(email, args[1] || null, await hashPassword(password));
    console.log(`Admin created: ${email}. Sign in at /admin/login (a code will be emailed).`);
  } else if (cmd === 'reset-admin-password') {
    const email = String(args[0] || '').trim().toLowerCase();
    const admin = db.prepare('SELECT id FROM admins WHERE email = ?').get(email);
    if (!admin) throw new Error(`No admin with email ${email}`);
    const password = await promptHidden('New admin password (min 12 characters): ');
    checkAdminPassword(password);
    db.prepare("UPDATE admins SET password_hash = ?, password_changed_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?").run(await hashPassword(password), admin.id);
    db.prepare('DELETE FROM admin_sessions WHERE admin_id = ?').run(admin.id);
    console.log('Password updated and all admin sessions signed out.');
  } else {
    console.log('Usage:\n  node scripts/cli.js seed\n  node scripts/cli.js credit <email> <naira>\n  node scripts/cli.js make-admin <email>');
    process.exitCode = 1;
  }
} catch (err) {
  console.error(`Error: ${err.message}`);
  process.exitCode = 1;
} finally {
  db.close();
}
})();
