# EL Assistant: setup guide (image analysis + Exa live web search)

This ZIP is the **complete HYPERBOOSTER server project**. Nothing else is needed: no `npm install` (zero dependencies),
no files to move one by one. It contains your original project plus the EL Assistant work (Steps 1 to 5), all tests,
and the live-verification scripts. It contains **no keys, no passwords and no database**.

## 1. Put it on Replit
1. Create (or open) your Repl and make sure it runs **Node 22.13 or newer** (`node -v`). Older Node cannot run the server.
2. Upload `hyperbooster-server-complete.zip`, unzip it, and keep the folder named `server/` exactly where your
   current `server/` folder is. If you already have a `server/` folder with a `data/` folder in it, **copy
   `server/data` somewhere safe first** (that is your database), then let the new files replace the old ones and put `data/` back.
3. Run `npm test` inside `server/`. You should see **217 tests passing** (see the report for exact totals).

## 2. The one secret you MUST set first: `AI_ENCRYPTION_KEY`
EL stores its API keys (Groq and Exa) **encrypted** in the database. The encryption key comes from the `AI_ENCRYPTION_KEY`
secret. If it is missing, a new random key is made on every start, so **saved keys stop working after each restart**
(Replit restarts often).

1. In the Replit Shell run:
   `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
2. Copy the 64-character result into **Replit > Secrets** as `AI_ENCRYPTION_KEY`. Keep a private copy: if you lose it,
   the saved AI keys cannot be recovered and must be typed in again.

Your Groq and Exa keys are **not** environment variables. You type them into the admin page (below) and they are stored encrypted.
(Only the verification scripts in section 5 read `GROQ_API_KEY` / `EXA_API_KEY` from Secrets, and only for that test run.)

## 3. Start, and switch things on safely
Start the server (`npm start`), sign in at `/admin/login`, and open **Settings > AI Assistant**. Every change asks for your password again.

**Everything new is OFF by default.** Turn on only what you want:

### Image analysis (vision), optional
1. Save your **Groq API key** and switch **EL Assistant** on.
2. Tick **Image analysis (vision)** and save. The default vision model is `qwen/qwen3.8-27b` (change it here if Groq renames it).
3. In the chat page an **Attach image** button now appears. Up to 3 images (JPEG, PNG, WebP). They are shrunk and stripped of
   camera/GPS data in your browser, sent once to Groq to be described, and never saved.

### Live web search with Exa, optional
1. Create an Exa key at **dashboard.exa.ai/api-keys**.
2. In **Settings > AI Assistant > Live web search**: choose **Exa (recommended)**, paste the **Exa API key**, and save. It is stored
   encrypted and **never shown again**; the page only says "Exa key saved (hidden)". Use "Remove the saved Exa key" to delete it.
3. Tick **Web search** in *Optional capabilities* and save. Until you do, EL cannot search at all.
4. Adjust **Results per search** (1 to 10, default 5) and **Excerpt text limit** (500 to 8000 characters, default 4000) if you want.
5. Ask EL a question that needs the web. Its answer lists the sources with **tappable links**. Any link that was not a real
   search result is removed by the server before you see it.

Groq stays EL's brain for everything. (The older **Groq browser search** is still available in the *Search service* list.)

## 4. What protects you
- Keys: encrypted at rest, never returned by any API, never written to logs, audit records, prompts or saved chats.
- Search queries: at most 200 characters, 10 searches per minute per admin; queries that look like emails, phone numbers or keys are refused.
- Search results and images are **untrusted data**: cleaned, size-limited, labelled, and never treated as instructions.
- EL has **no** tool for SQL, shell, files, free web requests, wallets, payments, orders, prices or providers. It can only search with a text query.
- If Exa fails or has no key, EL is told the search **did not run** and must say so. It never invents results.
- Every search, image analysis and settings change is audited (query text and counts only; never keys, images or results).

## 5. Verify the REAL services (the part tests with fakes cannot prove)
All automated tests use **fake** Groq/Exa servers. To check the real ones, run these in the Replit Shell inside `server/`
(each uses an in-memory database, only contacts the real service hosts, and never prints your keys):

    node scripts/live-verify-exa.js --selftest                 # no keys; checks the script itself
    EXA_API_KEY=... node scripts/live-verify-exa.js            # Stage A: one real Exa search
    # Stage B (the whole flow) also needs GROQ_API_KEY; with both set the same command runs A + B

    node scripts/live-verify-vision.js                         # real Groq image analysis (needs GROQ_API_KEY)
    node scripts/live-verify-web-search.js                     # only for the older Groq browser search option

In Replit, put the keys in **Secrets** and they are available to the Shell as environment variables, so you can run the commands
without typing a key. A pass ends with `SUMMARY: N/N checks passed` and exit code 0 (4 means the service could not be reached).

## 6. Troubleshooting
- *"no Exa API key has been added"*: add the key (section 3) and save.
- *"the Exa API key was not accepted"*: the key is wrong or revoked; paste a new one.
- *"the Exa account has no credits left"*: add credit at Exa.
- Keys "disappear" after a restart: `AI_ENCRYPTION_KEY` is not set (section 2).
- Attach button missing: image analysis is off, or EL is disabled, or no Groq key is saved.
