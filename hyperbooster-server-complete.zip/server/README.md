# HYPERBOOSTER server (backend foundation)

Zero-dependency Node backend: accounts, sessions, wallet ledger, service catalogue, orders.
Includes the Admin Panel, EL Assistant, Kora wallet deposits, and the NigeriaSMM provider connection.

Requires **Node 22.13 or newer** (uses the built-in `node:sqlite`). Nothing to `npm install`.

## Where it goes
Put this whole `server/` folder inside your project, next to your pages:

    your-project/
      index.html  login.html  register.html  styles/  scripts/     <- your existing files, untouched
      server/                                                     <- this folder

Best practice: move your pages into `your-project/public/` and the server will serve that folder
automatically. Otherwise it serves the parent folder (only html/css/js/images/fonts, never `server/`,
never dotfiles, never the database).

## Run
    cd server
    cp .env.example .env         # then edit if needed
    npm run seed                 # inserts 16 PLACEHOLDER services (safe to re-run)
    npm start                    # http://localhost:3000
    npm test                     # 119 integration tests (customer API + Admin Panel + EL Assistant + Kora deposits + NigeriaSMM provider)

Maintenance commands (server-side only, not exposed over HTTP):

    npm run cli -- credit you@example.com 5000     # add NGN 5,000 to a wallet (testing)
    npm run cli -- make-admin you@example.com      # for the future admin panel

Production: set `NODE_ENV=production` and, behind a proxy/load balancer, `TRUST_PROXY=1`.
Serve over HTTPS. Back up `server/data/hyperbooster.db` regularly.

## Money
All money is stored and returned as **integer kobo** (NGN 1,000 = `100000`). The frontend divides by 100
for display. Charge = `ceil(quantity x pricePer1000Kobo / 1000)`, calculated only on the server.

## API (JSON; errors look like `{ "error": "message", "field": "email" }`)
| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | /api/health | no | liveness check |
| POST | /api/register | no | `{fullName,email,password}` -> 201 `{user,wallet}` + session cookie |
| POST | /api/login | no | `{email,password}` -> `{user,wallet}` + session cookie |
| POST | /api/logout | no | ends the session |
| GET | /api/me | yes | `{user:{id,fullName,email,role}, wallet:{balanceKobo,currency}}` |
| GET | /api/wallet | yes | balance + ledger entries (`?limit=&offset=`) |
| GET | /api/services | no | active services (`?platform=instagram`); provider IDs never included |
| POST | /api/orders/quote | optional | `{serviceId,quantity}` -> server-calculated price (+ `canAfford` if signed in) |
| POST | /api/orders | yes | `{serviceId,quantity,link}` -> 201; charges wallet atomically; status `pending` |
| GET | /api/orders | yes | your orders (`?limit=&offset=`) |
| GET | /api/orders/:id | yes | one of your orders |

## Database (SQLite, `server/data/hyperbooster.db`, versioned migrations in `src/migrations.js`)
- **users**: email (unique, case-insensitive), full_name, password_hash (scrypt), role, status, balance_kobo (>= 0), timestamps
- **sessions**: user_id, token_hash (SHA-256; raw token never stored), expires_at, ip, user_agent
- **services**: name, platform, service_type, provider_service_id, price_per_1000_kobo, min/max_quantity, refill_available, drop_rate, average_completion_time, description, notes, is_active, sort_order. UNIQUE(platform, name), so a platform has many services
- **wallet_ledger**: signed amount_kobo, balance_after_kobo, entry_type (deposit / order_charge / order_refund / adjustment), reference, idempotency_key (UNIQUE)
- **deposits**: reference (UNIQUE), amount_kobo, status, gateway ('kora'), gateway_reference, gateway_payload, paid_at
- **orders**: user, service + snapshots of name/platform/type/price, link, quantity, charge_kobo, status, provider_order_id, provider_status, start_count, remains, error_message

## Security built in
scrypt password hashing (timing-equalised login) - random session tokens stored only as hashes - HttpOnly + SameSite=Lax
cookie (`__Host-` prefixed and Secure in production) - Origin check on all POSTs - rate limits (login per IP and per account,
register, orders, general API) - 16 KB JSON body cap - strict input validation (order links reject `javascript:` etc.) -
parameterised SQL only - wallet changes only through one ledger function inside a database transaction - CHECK
constraints (no negative balances) - CSP, nosniff, frame-deny headers - static server with extension allowlist,
dotfile block, traversal and symlink protection.

## Frontend changes still needed (NOT applied)
See the report: login.js, register.js, register.html, the home JS and home HTML.


## Admin Panel (`/admin`)
Setup: `npm run cli -- create-admin you@example.com "Your Name"`, configure email (see `.env.example`), open `/admin/login`.

- **Sign-in:** email + password, then a 6-digit code emailed to the admin. Codes expire (default 10 min), allow 5 tries, and can be re-sent (max 3, 30 s apart).
- **Separate from customers:** own tables (`admins`, `admin_sessions`), own cookie (HttpOnly, SameSite=Strict, `__Host-` + Secure in production). A customer session never opens admin pages or the admin API.
- **Every change** needs a per-session CSRF token and a same-origin request; permissions are checked on the server for every call.
- **Pages:** Overview, Services (tiers, tags, provider ID/cost, customer price, limits, enable/disable/delete), Orders (details, safe status changes), Customers (wallet, ledger, manual credit/debit, suspend), Settings (site, security, password, activity log).
- **Order status rules:** pending -> processing/completed/cancelled/failed; processing -> completed/cancelled/failed; finished orders are locked. Cancelling or failing refunds the customer's wallet once (idempotent ledger key) and is audited.
- **Wallet:** balances change only through the ledger. Manual credit/debit needs an amount and a reason and records the admin and the time.
- **Audit log:** admin login/logout, service create/edit/enable/disable/delete, tag changes, order status, wallet credit/debit, customer suspend, settings and password changes.
- **Secrets:** Kora, provider and email keys are read from server environment variables only. The Admin Panel shows only whether they are set.

## Deployment checklist
1. **Customer Home page:** in `scripts/home.js` set `TEMPORARY_TEST_PRICING = false`. That restores automatic pricing (quantity x the service price from the database). The fixed test amount must not go live.
2. Set real customer prices, provider costs and provider service IDs in Admin > Services (the seeded services are placeholders at NGN 1,000 per 1,000).
3. `NODE_ENV=production`, `TRUST_PROXY=1` behind a proxy, HTTPS only.
4. Email: `MAIL_TRANSPORT=resend` with `RESEND_API_KEY` and `MAIL_FROM` (verified domain). Send yourself a test sign-in code before launch.
5. Keep `server/data/` on persistent storage and back it up.
6. Create the admin account with `create-admin`.
7. Still to build: Kora deposits, sending orders to the provider and syncing their status.


## Wallet deposits (Kora)
Customer flow: **Home menu > Wallet** (`wallet.html`) -> enter an amount -> **Continue to payment** ->
Kora's hosted checkout -> back to `wallet.html`, which shows the result and the updated balance.

- `POST /api/deposits` `{amountKobo}` -> validates against Settings' minimum deposit, creates a
  `pending` row in the existing `deposits` table, calls Kora's Initialize Charge API server-side,
  returns `{reference, checkoutUrl}`. The browser only ever sees the checkout link, never the secret key.
- `POST /api/webhooks/kora` — public, authenticated by the `x-korapay-signature` header (HMAC-SHA256 of
  the payload's `data` object, per Kora's docs), not by a session. On `charge.success` / `charge.failed`
  it re-verifies server-to-server via Kora's Charge Query endpoint before touching the wallet — the
  webhook's own amount is never trusted directly.
- `GET /api/deposits/:reference` — the customer's own deposit only; if still `pending` it does one live
  Kora re-check itself, so the flow still resolves even if the webhook hasn't arrived yet.
- Crediting goes through the existing `applyLedger()` with `idempotencyKey: deposit:<reference>`, so a
  webhook delivered multiple times (or a webhook arriving after the status-check already resolved it,
  or vice versa) credits the wallet exactly once — the same mechanism already used for order refunds.
- Amounts: Kora's API works in naira (major units); HYPERBOOSTER stores kobo. All conversion is in
  `src/kora/money.js`, using integer/string math only — never a float multiply feeding the ledger.
- Admin: no new admin page. The existing customer-profile "Deposits" list (Admin > Customers > a
  customer) now also shows the Kora-verified amount and failure reason where relevant.


## SMM provider (NigeriaSMM)
Only services an admin has explicitly given a **Provider Service ID** (Admin > Services) are ever
forwarded — everything else behaves exactly as before (order stays `pending` for manual handling).

Flow: customer places an order -> wallet is validated and charged server-side -> **only then** is the
order sent to NigeriaSMM -> on acceptance the order becomes `processing` and the provider's order id
is saved; on rejection the customer is refunded once (same ledger idempotency key used by the admin's
own manual refund, so the two paths can never double-refund the same order) and the order is marked
`failed`. An order is never marked `completed` just because the request was sent.

- `src/provider/client.js` — the actual NigeriaSMM API calls (`add`, `status`, batched `status` for
  up to 100 orders at once). This is the real, documented "SMM Panel v2 API" format — see the caveat
  in the report below.
- `src/provider/statusMap.js` — maps the provider's status strings onto HYPERBOOSTER's *existing*
  order status enum (nothing new added: pending/processing/completed/partial/canceled/failed/refunded).
  An unrecognized status is recorded as-is but never guessed into a mapped status.
- `src/provider/orders.js` — `forwardOrderToProvider()` (called once, right after the order+wallet
  charge already committed) and `syncProviderOrders()` (batched status refresh).
- A background job re-checks orders every 5 minutes (only orders stuck `processing` for 3+ minutes,
  batched into one request per up to 100 orders, with an in-process guard so two runs never overlap).
- Admin: `POST /api/admin/orders/:id/sync` refreshes one order on demand from the existing order-detail
  view. No new admin page.
- Customers never see the provider API key, provider service id, or provider cost — confirmed by test.


## Integration credentials (Admin > Settings > Integrations)
NigeriaSMM and Kora secret keys can be entered in the Admin Panel. Groq/EL Assistant keeps using its
existing key store and is listed there too.
- Write-only: after saving, only `••••••••••••1234` (last four characters) is ever returned. There is no
  "show key" — to change a key, enter a new one.
- Encrypted at rest with AES-256-GCM (`src/ai/crypto.js`); the key is `AI_ENCRYPTION_KEY` in the
  environment, never in the database. Decrypted only server-side, at the moment a request is built
  (`src/credentials.js`); never logged, never returned by any API.
- Saving a key requires the admin's password again (server-verified), is rate-limited, and is audit
  logged with the integration name and last four characters only.
- **Test Connection** runs on the server: NigeriaSMM `balance` (read-only), Kora a lookup of a reference
  that cannot exist (401/403 = bad key, "not found" = key accepted). Neither places an order or charge.
- A key saved in the panel takes precedence over the environment variable; env vars remain a fallback.
